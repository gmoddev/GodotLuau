extends Animation
func _init():
    var Tree = Engine.get_main_loop()
    if Tree is SceneTree and Tree.current_scene != null:
        Tree.current_scene.set_meta('UnauthorizedInitializer', 1)
