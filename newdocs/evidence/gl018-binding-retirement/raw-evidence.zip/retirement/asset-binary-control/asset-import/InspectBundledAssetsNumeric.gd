extends "res://BundleCharacterAssets.gd"

func Same(Actual: Dictionary, Expected: Dictionary) -> bool:
    if Actual.Bounds != Expected.Bounds or Actual.Surfaces.size() != Expected.Surfaces.size(): return false
    for Index in Actual.Surfaces.size():
        var A = Actual.Surfaces[Index]
        var E = Expected.Surfaces[Index]
        # JSON parses dimensions as floats; preserve integer dimensions and
        # every geometry/texture hash without requiring identical Variant types.
        if E.Width != float(int(E.Width)) or E.Height != float(int(E.Height)): return false
        if A.Arrays != E.Arrays or A.Texture != E.Texture or A.Width != int(E.Width) or A.Height != int(E.Height): return false
    return true

func _initialize() -> void:
    var TextRecords = JSON.parse_string(FileAccess.get_file_as_string("res://bundled-assets-text.json"))
    var BinaryRecords = JSON.parse_string(FileAccess.get_file_as_string("res://bundled-assets.json"))
    var Results := []
    for Trial in range(3):
        for Variant in (["Text", "Binary"] if Trial % 2 == 0 else ["Binary", "Text"]):
            for Name in TextRecords:
                var Record = TextRecords[Name] if Variant == "Text" else BinaryRecords[Name]
                var Started := Time.get_ticks_usec()
                var Mesh = ResourceLoader.load(Record.Path, "ArrayMesh", ResourceLoader.CACHE_MODE_IGNORE_DEEP)
                var Elapsed := Time.get_ticks_usec() - Started
                assert(Mesh != null and Same(Describe(Mesh), TextRecords[Name].Identity))
                Results.append({"Trial": Trial, "Variant": Variant, "Asset": Name, "Microseconds": Elapsed, "Bytes": FileAccess.get_file_as_bytes(Record.Path).size()})
                print("[Runtime:AssetLoadControl] ", JSON.stringify(Results[-1]))
                Mesh = null
    FileAccess.open("res://load-measurements-numeric.json", FileAccess.WRITE).store_string(JSON.stringify(Results))
    print("[Runtime:AssetLoadControl] PASS original geometry and decoded bytes; no extension loaded")
    quit()
