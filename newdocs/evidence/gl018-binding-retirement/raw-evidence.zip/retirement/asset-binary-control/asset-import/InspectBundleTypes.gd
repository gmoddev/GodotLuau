extends "res://BundleCharacterAssets.gd"

func _initialize() -> void:
    var Expected = JSON.parse_string(FileAccess.get_file_as_string("res://bundled-assets-text.json"))
    var Binary = JSON.parse_string(FileAccess.get_file_as_string("res://bundled-assets.json"))
    var Records := []
    for Name in Expected:
        var TextMesh = ResourceLoader.load(Expected[Name].Path, "ArrayMesh", ResourceLoader.CACHE_MODE_IGNORE_DEEP)
        var BinaryMesh = ResourceLoader.load(Binary[Name].Path, "ArrayMesh", ResourceLoader.CACHE_MODE_IGNORE_DEEP)
        Records.append({"Name": Name, "Expected": Expected[Name].Identity, "Text": Describe(TextMesh) if TextMesh != null else {}, "Binary": Describe(BinaryMesh) if BinaryMesh != null else {}})
        print("[Runtime:AssetTypeControl] ", JSON.stringify(Records[-1]))
    FileAccess.open("res://type-comparison.json", FileAccess.WRITE).store_string(JSON.stringify(Records))
    quit()
