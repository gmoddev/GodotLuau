extends "res://BundleCharacterAssets.gd"

func _initialize() -> void:
    var TextRecords = JSON.parse_string(FileAccess.get_file_as_string("res://bundled-assets-text.json"))
    var BinaryRecords = JSON.parse_string(FileAccess.get_file_as_string("res://bundled-assets.json"))
    var Results := []
    for Trial in range(3):
        for Variant in (["Text", "Binary"] if Trial % 2 == 0 else ["Binary", "Text"]):
            for Name in TextRecords:
                var Record = TextRecords[Name] if Variant == "Text" else BinaryRecords[Name]
                var Started := Time.get_ticks_usec()
                var Mesh = ResourceLoader.load(Record.Path, "ArrayMesh", ResourceLoader.CACHE_MODE_IGNORE_DEEP)
                var Elapsed := Time.get_ticks_usec() - Started
                assert(Mesh != null and Describe(Mesh) == TextRecords[Name].Identity)
                Results.append({"Trial": Trial, "Variant": Variant, "Asset": Name, "Microseconds": Elapsed, "Bytes": FileAccess.get_file_as_bytes(Record.Path).size()})
                print("[Runtime:AssetLoadControl] ", JSON.stringify(Results[-1]))
                Mesh = null
    FileAccess.open("res://load-measurements.json", FileAccess.WRITE).store_string(JSON.stringify(Results))
    print("[Runtime:AssetLoadControl] PASS original geometry and decoded bytes; no extension loaded")
    quit()
