import hashlib,json,subprocess,urllib.request,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
Spec=json.load(urllib.request.urlopen('https://pypi.org/pypi/SCons/4.10.0/json',timeout=30))
Wheel=next(Item for Item in Spec['urls'] if Item['filename'].endswith('.whl'))
assert Wheel['digests']['sha256']=='df6f86828035a5c03abce64d4cf2f9c5cbd0051b58af498016bc58bfc05559b0'
Archive=Root/Wheel['filename']
if not Archive.exists():
 with urllib.request.urlopen(Wheel['url'],timeout=30) as Response: Archive.write_bytes(Response.read())
assert hashlib.sha256(Archive.read_bytes()).hexdigest()==Wheel['digests']['sha256']
with zipfile.ZipFile(Archive) as Zip: Zip.extractall(Root/'scons-4.10.0')
Info=json.loads(subprocess.check_output(['docker','inspect','--size','codex-character-linux'],timeout=30))[0]
print(json.dumps({'SConsSHA256':Wheel['digests']['sha256'],'ContainerImage':Info['Config']['Image'],'ImageID':Info['Image'],'SizeRw':Info['SizeRw']}),flush=True)
(Root/'tooling-identity.json').write_text(json.dumps({'SConsVersion':'4.10.0','SConsWheelSHA256':Wheel['digests']['sha256'],'ExistingContainerImage':Info['Image'],'ExistingContainerSizeRw':Info['SizeRw']},indent=2))
