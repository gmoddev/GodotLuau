import json,subprocess,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
assert (Root/'LinuxWork/linux-cache-preservation.json').is_file()
Records=[]
for Name in ['codex-gl018-ram','codex-gl018-linux']:
 Info=json.loads(subprocess.check_output(['docker','inspect',Name],timeout=15))[0]
 assert Info['Config']['Labels']['codex.task']=='gl018' and Info['Config']['Labels']['codex.project']=='godotluau'
 assert all(Item.get('Name')!='codex-character-qualification-linux-v1' or not Item['RW'] for Item in Info['Mounts'])
 if Info['State']['Running']: subprocess.run(['docker','stop','-t','5',Name],check=True,timeout=20)
 subprocess.run(['docker','rm',Name],check=True,timeout=15)
 Records.append({'Container':Name,'ID':Info['Id'],'StoppedAndRemoved':True,'SharedCacheReadOnly':True})
Old=json.loads(subprocess.check_output(['docker','inspect','codex-character-linux'],timeout=15))[0]
assert not Old['State']['Running']
(Root/'cleanup.json').write_text(json.dumps({'UTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'TaskContainers':Records,'PreexistingCharacterContainerRestoredStopped':True,'SharedVolumeRetained':True,'E_TaskCachesAndEvidenceRetained':True},indent=2))
print('[Runtime:Cleanup] Task containers removed; original container state and shared caches preserved',flush=True)
