import ctypes,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
Source=Root/'source'
Driver=Path('C:/Sandbox/Codex/Workspaces/GodotLuau')
Build=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan')
Logs=Root/'windows-native-current-first'; Logs.mkdir(exist_ok=False)
ctypes.windll.kernel32.SetErrorMode(0x8003)
Compiler=Path(re.search(r'CMAKE_CXX_COMPILER:FILEPATH=(.+)',(Build/'CMakeCache.txt').read_text())[1])
Batch=Root/'NativeEnvironment.cmd'
Batch.write_text('@echo off\ncall "'+str(Compiler.parents[6]/'Auxiliary/Build/vcvars64.bat')+'" >nul\nif errorlevel 1 exit /b 1\nset\n')
for Line in subprocess.check_output(['cmd','/d','/c',str(Batch)],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Name,Value=Line.split('=',1); os.environ[Name]=Value
def Hash(File): return hashlib.sha256(Path(File).read_bytes().replace(b'\r\n',b'\n')).hexdigest()
for Name in ['tests/runtime/CMakeLists.txt','tests/runtime/ExecutionDomainTests.cpp','tests/runtime/DatastoreBackendProbe.cpp','src/persistence/worker_main.cpp']:
 assert Hash(Driver/Name)==Hash(Source/Name),Name
for Name,Expected in [('godot-cpp','d5cc777a89d899665fb61f1650ef0dc0cf6488c4'),('luau','9e2984fd0334414a2ef62ceede0c06dab7574d55')]:
 assert subprocess.check_output(['git','-C',str(Driver/Name),'rev-parse','HEAD'],text=True,timeout=15).strip()==Expected
 assert not subprocess.check_output(['git','-C',str(Driver/Name),'status','--porcelain','--untracked-files=no'],text=True,timeout=15).strip()
sys.path.insert(0,str(Source/'tests/runtime'))
from FixtureProcesses import StartProcess,StopProcess,StopAll
from SourceFingerprint import GetFingerprint
Identity={'Source':GetFingerprint(Source),'DriverInputs':{Name:Hash(Driver/Name) for Name in ['tests/runtime/CMakeLists.txt','tests/runtime/ExecutionDomainTests.cpp','tests/runtime/DatastoreBackendProbe.cpp','src/persistence/worker_main.cpp']},'CompilerSHA256':Hash(Compiler),'Commands':[]}
CMake=Path('C:/Sandbox/Codex/Tools/cmake-3.31.10/cmake-3.31.10-windows-x86_64/bin/cmake.exe')
def Run(Command,Name,Timeout):
 with (Logs/(Name+'.log')).open('w') as Log:
  Child=StartProcess([str(Value) for Value in Command],Log,subprocess.STDOUT,dict(os.environ))
  assert ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(int(Child._handle)),0x4000)
  try: Code=Child.wait(timeout=Timeout)
  finally: StopProcess(Child)
 Identity['Commands'].append({'Command':[str(Value) for Value in Command],'Exit':Code,'LogSHA256':Hash(Logs/(Name+'.log'))})
 (Logs/'identity.json').write_text(json.dumps(Identity,indent=2))
 print('[Runtime:NativeBuild] '+Name+' exit='+str(Code),flush=True)
 if Code: print((Logs/(Name+'.log')).read_text(errors='replace')[-6000:],flush=True)
 assert Code==0
try:
 Run([CMake,'-S',Driver/'tests/runtime','-B',Build,'-DGL_SOURCE_ROOT='+str(Source),'-DGL_BUILD_GODOT_ADAPTER=ON','-DGL_BUILD_CORE_TESTS=ON','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_CXX_FLAGS=/fsanitize=address','-DCMAKE_CXX_FLAGS_DEBUG=/Zi /Od','-DCMAKE_EXE_LINKER_FLAGS=/INCREMENTAL:NO','-DCMAKE_SHARED_LINKER_FLAGS=/INCREMENTAL:NO'],'configure',180)
 Run([CMake,'--build',Build,'--target','GodotLuauAdapter','ExecutionDomainTests','DatastoreBackendProbe','--parallel','2'],'build',3600)
 Products=Root/'products/windows-asan'; Products.mkdir(parents=True)
 for Name in ['godot_luau.dll','godot_luau_store_worker.exe','DatastoreBackendProbe.exe','ExecutionDomainTests.exe']:
  shutil.copy2(Build/Name,Products/Name)
 Identity['Products']={Name:hashlib.sha256((Products/Name).read_bytes()).hexdigest() for Name in ['godot_luau.dll','godot_luau_store_worker.exe','DatastoreBackendProbe.exe','ExecutionDomainTests.exe']}
 (Products/'identity.json').write_text(json.dumps(Identity,indent=2))
finally: StopAll()
