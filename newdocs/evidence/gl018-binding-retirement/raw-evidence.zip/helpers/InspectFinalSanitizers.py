import hashlib,json,sys,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Followup=Root/'followup';sys.path.insert(0,str(Root/'source/tests/runtime'))
from CheckCoreCI import CheckDiscovery,CheckReport
Records=[]
for Item in json.loads((Followup/'sanitizer246-artifacts.json').read_text()):
 File=Followup/('sanitizer246-'+str(Item['id'])+'.zip');Digest=hashlib.sha256(File.read_bytes()).hexdigest();assert 'sha256:'+Digest==Item['digest']
 assert Item['workflow_run']['head_sha']=='246601599e581bd1c34cc403adcafcc404f89ae7'
 with zipfile.ZipFile(File) as Zip:
  Names={Name.replace('\\','/'):Name for Name in Zip.namelist()}
  Name=next(Name for Name in Names if Name.endswith('/sanitizer-summary.json'));Prefix=Name.removesuffix('sanitizer-summary.json')
  Summary=json.loads(Zip.read(Names[Name]));assert not Summary['FullQualification'] and Summary['Result']=='FAIL'
  for Relative,Hash in Summary['Files'].items():assert hashlib.sha256(Zip.read(Names[Prefix+Relative.replace('\\','/')])).hexdigest()==Hash,Relative
  Inputs=json.loads(Zip.read(Names[Prefix+'inputs.json']));assert Inputs['NativeSource']['SHA256']=='2706e1685bdf0207e55eacc2f877e4578a3164603ea5861c183009348c7d1bc8'
  Core=Followup/'final-sanitizer-core'/Item['name'];Core.mkdir(parents=True,exist_ok=False)
  for Suffix in ['discovery.json','core-results.xml']:(Core/Suffix).write_bytes(Zip.read(Names[Prefix+'core/'+Suffix]))
  CheckDiscovery(Core/'discovery.json');CheckReport(Core/'core-results.xml')
  Groups={}
  for Group in ['regression','security','animation','characters','resources','filesystem','http','httpservice','callers','datastore','presentation','performance']:
   Key=Prefix+'native/'+Group+'/results.json'
   if Key in Names:
    Actors=json.loads(Zip.read(Names[Key]));assert all(Actor['Exit']==0 for Actor in Actors);Groups[Group]=len(Actors)
  Authority=[]
  for Key in Names:
   if Key.startswith(Prefix+'native/animation/') and '/animation-authority-' in Key and Key.endswith('.json'):
    Value=json.loads(Zip.read(Names[Key]));Authority.append({'Complete':Value['Complete'],'Result':Value['Result'],'Cases':len(Value['Cases']),'Assertions':len(Value['Assertions'])})
  Failures={}
  for Group in ['presentation','performance','animation','http','httpservice','datastore']:
   Key=Prefix+'suite-'+Group+'/stderr.log'
   if Key in Names:
    Text=Zip.read(Names[Key]).decode(errors='replace')
    if Text.strip():Failures[Group]=Text[-7000:]
  Record={'ArtifactID':Item['id'],'Name':Item['name'],'SHA256':Digest,'Revision':Item['workflow_run']['head_sha'],'Result':'FAIL','FullQualification':False,'CoreCases':80,'VerifiedReportHashes':len(Summary['Files']),'NativeSource':Inputs['NativeSource'],'ControlsPassed':Summary['ControlsPassed'],'CompletedActorGroups':Groups,'RecordedCompletedActors':sum(Groups.values()),'AnimationRecords':Authority,'UnexpectedReports':Summary['UnexpectedReports'],'Results':[{K:Value[K] for K in ['Label','Exit','TimedOut','Passed']} for Value in Summary['Results']],'FailureDetails':Failures}
  Records.append(Record)
  print(json.dumps({K:Record[K] for K in ['Name','ArtifactID','SHA256','CoreCases','VerifiedReportHashes','CompletedActorGroups','RecordedCompletedActors','UnexpectedReports']}),flush=True)
(Followup/'final-sanitizers-verified.json').write_text(json.dumps(Records,indent=2))
for Item in Records:
 print(Item['Name']+' presentation: '+Item['FailureDetails'].get('presentation','')[-1600:],flush=True)
 print(Item['Name']+' performance: '+Item['FailureDetails'].get('performance','')[-1200:],flush=True)
