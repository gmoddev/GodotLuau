import json, shutil
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/followup');Output=Root/'publish-records';Output.mkdir(exist_ok=True)
Files={
 'local-results.json':'final-local-results.json',
 'binding-windows.json':'windows-bindings-get-api/binding-investigation.json',
 'binding-linux.json':'linux-salvage/followup/bindings-get-api/binding-investigation.json',
 'gdb-production.log':'linux-salvage/followup/gdb/production.log',
 'gdb-binding.log':'linux-salvage/followup/gdb/binding.log',
 'url-before.log':'windows-utilities-loaded/stdout.log',
 'core-hosted.json':'fresh-core-verified.json',
 'native-intermediate.json':'interim-native-verified.json',
 'native-windows.json':'native246-verified.json',
 'previous-sanitizer-artifacts.json':'old-hosted-sanitizers-verified.json',
 'linux-cleanup.json':'linux-cleanup.json',
 'capacity-recovery.json':'capacity-recovery.json',
 'bundled-assets.json':'windows-candidate-full/native/presentation/asset-import/bundled-assets.json',
 'asset-inputs.json':'windows-candidate-full/native/presentation/asset-import/asset-inputs.json'}
Files['ci-observation.json']='ci-observation.json'
for Name,Relative in Files.items():
 assert (Root/Relative).is_file(),Relative
 shutil.copy2(Root/Relative,Output/Name)
(Output/'gdb-recovery.json').write_text(json.dumps({'Scope':'Diagnostic child debugging; not sanitizer-clean qualification','Recovered':['gdb-binding.log','gdb-production.log'],'MissingOriginalRecord':'Linux gdb/investigation.json was not recovered after backing-disk failure','CommandsSource':'FollowupGdb.py retained in the raw follow-up archive','SanitizerOptions':'halt_on_error=1:detect_leaks=1:handle_segv=0','LeakQualificationUnderPtrace':False},indent=2))
File=next((Root/'windows-bindings-get-api/binding').glob('asan-report*'));shutil.copy2(File,Output/'windows-binding-asan.log')
Actors=[]
for File in sorted((Root/'windows-idle-followup/animation').glob('*/animation-authority-*.json')):
 Record=json.loads(File.read_text());assert Record['Complete'] and Record['Result']=='PASS' and all(Item['Passed'] for Item in Record['Cases']+Record['Assertions']);Actors.append(Record)
assert len(Actors)==10 and sum(len(Record['Cases']) for Record in Actors)==510
(Output/'idle-animation.json').write_text(json.dumps({'Actors':10,'AuthorityChecks':510,'Assertions':sum(len(Record['Assertions']) for Record in Actors),'AllPassed':True},indent=2))
print('Published record staging '+str(len(list(Output.iterdir())))+' files',flush=True)
