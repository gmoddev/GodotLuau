import json,shutil
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement/windows-o1-2')
for Name in ['build.log','core.log','http.log','httpservice.log','datastore.log']:
 P=Root/Name
 if P.exists():print(Name+'\n'+'\n'.join(P.read_text(errors='replace').splitlines()[-5:]),flush=True)
P=Root/'native/compile_commands.json'
if P.exists():
 Commands=json.loads(P.read_text());print({'TranslationUnits':len(Commands),'AllASan':all('/fsanitize=address' in C['command'] for C in Commands),'AllO1':all('/O1' in C['command'] and '/Od' not in C['command'] for C in Commands),'NoNDEBUG':all('NDEBUG' not in C['command'] for C in Commands),'NoRTC':all('/RTC' not in C['command'] for C in Commands)},flush=True)
print('CFree',shutil.disk_usage('C:/').free,flush=True)
