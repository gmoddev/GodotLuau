import hashlib,json,shutil
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement')
for Name in ['windows-classes/production','linux-classes/production','host-windows-production','host-linux-production']:
 File=Root/Name/'investigation.json'
 if File.exists():
  Data=json.loads(File.read_text())
  print(Name,Data['GodotSHA256'],Data['ExtensionSHA256'])
  for Case in Data['Results']:
   Lines=[Line for Line in Case['BindingDiagnostics'] if 'survivor class=' in Line]
   print(Case['Label'],Case['Exit'],Case['TimedOut'],Case['LifecyclePASS'],sorted(set(Line.split(' class=')[1].split(' id=')[0] for Line in Lines)))
for Name in ['full-windows.log','full-windows/sanitizer-summary.json','verified-host-windows.log']:
 File=Root/Name
 if File.exists():
  if Name.endswith('sanitizer-summary.json'):
   Data=json.loads(File.read_text());print('Full',Data['Result'],Data['UnexpectedReports'],[(R['Label'],R['Passed']) for R in Data['Results']])
  else:print(Name+'\n'+'\n'.join(File.read_text(errors='replace').splitlines()[-8:]))
print('Capacity',[(Drive,shutil.disk_usage(Drive).free) for Drive in ['C:/','E:/']],flush=True)
