import json,subprocess
from pathlib import Path
for Name in ['settings-store.json','settings.json']:
 File=Path('C:/Users/host/AppData/Roaming/Docker')/Name
 if File.is_file():
  Values=json.loads(File.read_text())
  print(json.dumps({'File':str(File),'Storage':{Key:Value for Key,Value in Values.items() if any(Part in Key.lower() for Part in ['datafolder','diskimagelocation','diskimagepath','wsldisk','diskpath'])}}),flush=True)
Result=subprocess.run(['powershell.exe','-NoProfile','-Command',"Get-ChildItem HKCU:/Software/Microsoft/Windows/CurrentVersion/Lxss -ErrorAction SilentlyContinue | Get-ItemProperty | Select-Object DistributionName,BasePath | ConvertTo-Json -Compress"],capture_output=True,text=True,timeout=30)
print(Result.stdout.strip(),flush=True)
