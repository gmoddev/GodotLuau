import json, subprocess
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
for Command in [['docker','ps','-a','--format','{{.Names}} {{.Status}} {{.Image}}'],['powershell.exe','-NoProfile','-Command','Get-PSDrive C,E | Select-Object Name,Free,Used | ConvertTo-Json -Compress']]:
 print(subprocess.check_output(Command,text=True,timeout=20),flush=True)
for Name,Terms in [('godot-host/core/extension/gdextension_manager.cpp',['_unload_extension_internal']),('godot-host/core/extension/gdextension_interface.cpp',['gdextension_object_set_instance_binding','gdextension_object_get_instance_binding']),('source/godot-cpp/src/godot.cpp',['deinitialize_level']),('source/godot-cpp/src/core/object.cpp',['_gde_binding','get_instance_binding'])]:
 File=Root/Name
 if not File.exists(): File=Path('C:/Sandbox/Codex/Workspaces/GodotLuau')/Path(Name).relative_to('source')
 Lines=File.read_text().splitlines()
 for Index,Line in enumerate(Lines):
  if any(Term in Line for Term in Terms): print(Name+':'+str(Index+1)+'\n'+'\n'.join(Lines[max(0,Index-2):Index+40]))
print('LinuxWork '+str([P.name for P in (Root/'LinuxWork').iterdir()]))
