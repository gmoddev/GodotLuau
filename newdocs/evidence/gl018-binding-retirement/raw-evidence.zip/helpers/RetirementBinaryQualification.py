import ctypes,json,os,subprocess,sys
from pathlib import Path
Windows=os.name=='nt'; Root=Path('E:/Sandbox/Codex/NativeSanitizers') if Windows else Path('/retained');Runtime=Root/'source/tests/runtime' if Windows else Path('/work/source/tests/runtime');Output=Root/'retirement' if Windows else Path('/evidence')
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
if Windows:ctypes.windll.kernel32.SetErrorMode(0x8003)
HostRoot=Root/'godot-host' if Windows else Path('/work/godot-host');Host=json.loads((HostRoot/'sanitizer-host.json').read_text())
def Run(Command,Name,Timeout):
 with (Output/(Name+'.log')).open('w') as Log:
  Child=StartProcess([str(X) for X in Command],Log,subprocess.STDOUT,dict(os.environ))
  try:Code=Child.wait(timeout=Timeout)
  finally:StopProcess(Child)
 print(Name,Code,flush=True);print((Output/(Name+'.log')).read_text(errors='replace')[-3000:],flush=True)
 return Code
try:
 if Windows:
  Extension=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/godot_luau.dll');Editor=Root/'asset-editor/Godot_v4.7.1-stable_win64.exe'
  Run([sys.executable,Runtime/'RunCharacterPresentation.py','--godot',Host['Executable'],'--asset-godot',Editor,'--extension',Extension,'--output',Output/'binary-presentation-windows'],'binary-presentation-windows',360)
  Run([sys.executable,Runtime/'RunCharacterPerformance.py','--godot',Host['Executable'],'--asset-godot',Editor,'--extension',Extension,'--output',Output/'binary-performance-windows','--trials','1','--samples','120','--counts','1,16'],'binary-performance-windows',360)
 else:
  Build=Path('/work/fresh-asan');os.environ['GL_QUALIFICATION_PROFILE_ROOT']='/profiles'
  Run([sys.executable,Runtime/'RunNativeSanitizers.py','--godot',Host['Executable'],'--host-manifest',HostRoot/'sanitizer-host.json','--extension',Build/'godot_luau.so','--build',Build,'--build-identity',Output/'linux-candidate-build/build-identity.json','--probe','/work/retirement-probes/NativeSanitizerProbe.so','--loader','/work/retirement-probes/NativeSanitizerLoader','--asset-godot','/cache/godot/Godot_v4.7.1-stable_linux.x86_64','--asset-provenance','/cache/godot/provenance.json','--revision','92659bae6cc5d7b321b075848b905e9d660b47df','--output',Output/'full-linux-binary'],'full-linux-binary',2400)
finally:StopAll()
