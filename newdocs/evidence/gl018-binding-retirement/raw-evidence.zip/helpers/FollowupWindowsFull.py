exec(__import__('pathlib').Path('E:/Sandbox/Codex/NativeSanitizers/helpers/FollowupWindows.py').read_text().split('with (Output/')[0])
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
Command=[sys.executable,str(Root/'source/tests/runtime/RunNativeSanitizers.py'),'--godot',Host['Executable'],'--host-manifest',str(Root/'godot-host/sanitizer-host.json'),'--extension',str(Build/'godot_luau.dll'),'--build',str(Build),'--build-identity',str(Root/'products/windows-asan/current-build-identity.json'),'--probe',str(Output/'windows-probes/NativeSanitizerProbe.dll'),'--loader',str(Output/'windows-probes/NativeSanitizerLoader.exe'),'--asset-godot',str(Root/'asset-editor/Godot_v4.7.1-stable_win64.exe'),'--asset-provenance',str(Root/'asset-editor/provenance.json'),'--revision','66362c737f4185461f2da4de218e9eeb127cb10e+qualification-followup','--output',str(Output/'windows-full')]
with (Output/'windows-full.log').open('w') as Log:
 Result=subprocess.run(Command,stdout=Log,stderr=subprocess.STDOUT,timeout=2400)
print('full exit='+str(Result.returncode),flush=True)
print((Output/'windows-full.log').read_text(errors='replace')[-4000:],flush=True)
