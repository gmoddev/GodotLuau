import ctypes,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); Output=Root/'retirement'; Runtime=Root/'source/tests/runtime'
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
from RunCharacterPresentation import Project
from RunQualification import Port
ctypes.windll.kernel32.SetErrorMode(0x8003)
assert (Output/'full-windows/sanitizer-summary.json').is_file(),'Wait for full profile; avoid overlapping fixtures'
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
Extension=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/godot_luau.dll')
Import=Output/'full-windows/native/presentation/asset-import'
Environment=dict(os.environ,ASAN_OPTIONS='halt_on_error=1',GODOT_SILENCE_ROOT_WARNING='1')
Records=[]
try:
 for Name,Script,Extra in [('presentation-lifetime','TraceCharacterPresentation.gd',['--case','dedicated']),('performance-trace','TraceCharacterPerformance.gd',['--counts','1,16','--samples','120','--warmup-ticks','60','--lifecycle-samples','30'])]:
  Directory=Output/Name;Project(Directory,Extension,Import)
  shutil.copy2(Output/Script,Directory/Script)
  Children=[];Started=time.monotonic();SelectedPort=Port()
  Actors=[('server','0'),('client','1'),('client','2')] if Name=='presentation-lifetime' else [('single','0')]
  for Role,Index in Actors:
   Label=Role+Index;Env=dict(Environment)
   Env['ASAN_OPTIONS']='halt_on_error=1:log_path="'+(Directory/('asan-report-'+Label)).as_posix()+'"'
   for Key in ['APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME']:
    Profile=Directory/('profile-'+Label)/Key;Profile.mkdir(parents=True);Env[Key]=str(Profile)
   Command=[Host['Executable'],'--headless','--disable-crash-handler','--single-threaded-scene','--path',str(Directory),'--script','res://'+Script,'--max-fps','120','--',*Extra]
   if Name=='presentation-lifetime':
    Command+=['--role',Role,'--index',Index,'--port',str(SelectedPort)]
    if Role=='server':Command+=['--glserver',str(SelectedPort)]
   Out=(Directory/(Label+'.stdout.log')).open('w');Err=(Directory/(Label+'.stderr.log')).open('w')
   Child=StartProcess(Command,Out,Err,Env);Out.close();Err.close();Children.append((Child,Label,Command))
  Deadline=Started+(90 if Name=='presentation-lifetime' else 180)
  for Child,Label,Command in Children:
   TimedOut=False
   try:
    try:Code=Child.wait(timeout=max(0.01,Deadline-time.monotonic()))
    except subprocess.TimeoutExpired:Code=None;TimedOut=True
   finally:StopProcess(Child)
   Records.append({'Name':Name,'Actor':Label,'Command':Command,'Exit':Code,'TimedOut':TimedOut,'Seconds':time.monotonic()-Started,'Scope':'Diagnostic wrapper; original fixture assertions/workload/time limits retained'})
  (Output/'remaining-diagnostics.json').write_text(json.dumps(Records,indent=2))
  print(Name,Records[-len(Children):],flush=True)
finally:StopAll()
