import json
from pathlib import Path
for Name in ['godot-host','fresh-asan','source','build-asan','products']:
 Root=Path('/work')/Name
 print(json.dumps({'Directory':str(Root),'MiB':sum(File.stat().st_size for File in Root.rglob('*') if File.is_file())//1024**2}),flush=True)
for File in Path('/work/fresh-asan').rglob('link.txt'):
 if 'godot-cpp' in str(File): print(File.read_text())
print('Native subdirectories '+str([str(File) for File in Path('/work/fresh-asan/godot-cpp').iterdir()]))
