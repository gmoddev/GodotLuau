from pathlib import Path
import json
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
for Name,Terms in [('godot-host/scene/register_scene_types.cpp',['CompressedTexture2D','TextureLoader','texture_2d_loader']),('godot-host/core/io/resource_loader.cpp',['.remap']),('source/src/core/luau_builtin_compat.cpp',['UrlEncode'])]:
 File=Root/Name
 if not File.exists(): continue
 Lines=File.read_text().splitlines()
 for Index,Line in enumerate(Lines):
  if any(Term in Line for Term in Terms): print(Name+':'+str(Index+1)+'\n'+'\n'.join(Lines[max(0,Index-8):Index+12]))
for Folder in ['followup/windows-bindings','windows-full-first/native/httpservice']:
 for File in (Root/Folder).rglob('*.log'):
  if File.stat().st_size < 20000: print(str(File)+'\n'+File.read_text(errors='replace'))
