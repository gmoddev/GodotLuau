import os, sys
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); sys.path.insert(0,str(Root/'source/tests/runtime'))
from RunCharacterPresentation import Assets
from FixtureProcesses import StopAll
Output=Root/'followup/windows-bundling-control';Output.mkdir()
try:
 Assets(Root/'asset-editor/Godot_v4.7.1-stable_win64.exe',Root/'source',Output,dict(os.environ),RuntimeRemaps=True)
 print('bundling preparation done',flush=True)
finally: StopAll()
