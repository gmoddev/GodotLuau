import json, shutil, subprocess
from pathlib import Path
Root=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan').resolve()
Source=(Root/'godot-cpp').resolve()
Task=Path('E:/Sandbox/Codex/NativeSanitizers/followup').resolve()
Target=Task/'relocated-godot-cpp-cache'
assert Source.is_relative_to(Root) and Source != Root
assert Target.resolve().is_relative_to(Task) and not Target.exists()
assert Source.is_dir() and not Source.is_junction()
Size=sum(File.stat().st_size for File in Source.rglob('*') if File.is_file())
Before=shutil.disk_usage('C:/').free
print('Relocating task ASan binding cache, preserving paths through junction: '+str(Size),flush=True)
shutil.move(str(Source),str(Target))
subprocess.run(['cmd','/d','/c','mklink','/J',str(Source),str(Target)],check=True,timeout=15)
Record={'Source':str(Source),'Target':str(Target),'BytesPreserved':Size,'FreeBefore':Before,'FreeAfter':shutil.disk_usage('C:/').free,'Junction':Source.is_junction()}
assert Record['Junction']
(Task/'capacity-recovery.json').write_text(json.dumps(Record,indent=2))
print(json.dumps(Record),flush=True)
