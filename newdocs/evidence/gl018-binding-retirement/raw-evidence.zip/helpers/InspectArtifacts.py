import hashlib,json,sys,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
sys.path.insert(0,str(Root/'source/tests/runtime'))
from CheckCoreCI import CheckDiscovery,CheckReport
Artifacts=json.loads((Root/'artifact-list.json').read_text())
Results=[]
for Item in Artifacts:
 File=Root/(Item['name']+'.zip')
 Digest=hashlib.sha256(File.read_bytes()).hexdigest()
 assert 'sha256:'+Digest==Item['digest']
 Record={'ArtifactID':Item['id'],'Name':Item['name'],'ArchiveSHA256':Digest,'Revision':Item['workflow_run']['head_sha']}
 with zipfile.ZipFile(File) as Zip:
  if 'runtime-core-' in Item['name']:
   Directory=Root/'hosted-extracted-final-2'/Item['name']; Directory.mkdir(parents=True,exist_ok=False)
   for Suffix in ['discovery.json','core-results.xml']:
    Names=[Name for Name in Zip.namelist() if Name.endswith('/'+Suffix) or Name==Suffix]
    assert len(Names)==1
    (Directory/Suffix).write_bytes(Zip.read(Names[0]))
   CheckDiscovery(Directory/'discovery.json'); CheckReport(Directory/'core-results.xml')
   Record.update(Result='PASS',DistinctCoreCases=80,CompleteReportVerified=True)
  else:
   Names=[Name for Name in Zip.namelist() if Name.endswith('native-ci/summary.json')]
   assert len(Names)==1
   Name=Names[0]; Prefix=Name.removesuffix('summary.json')
   Summary=json.loads(Zip.read(Name)); assert Summary['Revision']==Record['Revision']
   assert Summary['NativeSource']['SHA256']=='c651c1ff730bb2de8c16da996c09d2567e26d45865dfa25118df812d1f51d91f'
   assert Summary['Processes']==110 and sum(len(Value) for Value in Summary['Groups'].values())==110
   assert all(Actor['Exit']==0 for Group in Summary['Groups'].values() for Actor in Group)
   for Relative,Digest in Summary['LogHashes'].items(): assert hashlib.sha256(Zip.read(Prefix+Relative.replace('\\','/'))).hexdigest()==Digest
   for FileName,Digest in Summary['HarnessHashes'].items():
    assert hashlib.sha256((Root/'source/tests/runtime'/FileName).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==Digest,FileName
   Records=Summary['AnimationAuthority']; assert len(Records)==10 and all(Actor['Complete'] and Actor['Result']=='PASS' for Actor in Records)
   Cases=sum(len(Actor['Cases']) for Actor in Records); Assertions=sum(len(Actor['Assertions']) for Actor in Records)
   assert Cases==510 and Assertions==1003
   Record.update(Result='PASS',NativeActors=110,AnimationActors=10,AnimationAuthorityChecks=Cases,AnimationAssertions=Assertions,NativeSource=Summary['NativeSource'],ExtensionSHA256=Summary['ExtensionSHA256'],DataStoreWorkerSHA256=Summary['DataStoreWorkerSHA256'],HarnessInputs=len(Summary['HarnessHashes']),VerifiedLogHashes=len(Summary['LogHashes']))
 Results.append(Record)
(Root/'hosted-artifact-check.json').write_text(json.dumps(Results,indent=2))
print(json.dumps(Results,indent=2))
