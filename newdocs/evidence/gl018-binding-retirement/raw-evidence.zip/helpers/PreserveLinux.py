import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
Root=Path('/work'); Evidence=Path('/evidence')
sys.path.insert(0,str(Root/'source/tests/runtime'))
from FixtureProcesses import StartProcess,StopProcess
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
Output=Evidence/'linux-host-product'; Output.mkdir(exist_ok=False)
shutil.copy2(Host['Executable'],Output/Path(Host['Executable']).name)
shutil.copy2(Root/'godot-host/sanitizer-host.json',Output/'sanitizer-host.json')
assert hashlib.sha256((Output/Path(Host['Executable']).name).read_bytes()).hexdigest()==Host['ExecutableSHA256']
Archive=Evidence/'linux-build-cache.tar.gz'
Command=['tar','-czf',str(Archive),'-C',str(Root),'godot-host','fresh-asan','probes','source']
with (Evidence/'linux-cache-preservation.log').open('w') as Log:
 Child=StartProcess(Command,Log,subprocess.STDOUT,dict(os.environ,GZIP='-1'))
 try: Code=Child.wait(timeout=300)
 finally: StopProcess(Child)
assert Code==0
Digest=hashlib.sha256()
with Archive.open('rb') as File:
 while Block:=File.read(1024*1024): Digest.update(Block)
(Evidence/'linux-cache-preservation.json').write_text(json.dumps({'Command':Command,'Exit':Code,'SHA256':Digest.hexdigest(),'Bytes':Archive.stat().st_size,'OriginalHostExecutableSHA256':Host['ExecutableSHA256'],'SourceRevision':'055d8f07440cbe9035937a2e8b22dba476e7356b'},indent=2))
print('[Runtime:Evidence] Preserved Linux host, binaries, pinned source and task build caches',flush=True)
