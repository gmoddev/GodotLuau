import json,subprocess
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement')
for Name in ['historical-leak-symbols-v4','historical-leak-symbols-v3']:
 Folder=Root/Name
 print(Name,[(P.name,P.stat().st_size) for P in Folder.iterdir()] if Folder.exists() else 'absent')
 if (Folder/'verification.json').exists():print((Folder/'verification.json').read_text());print((Folder/'host-symbols.txt').read_text())
print(subprocess.check_output(['docker','top','codex-gl018-retirement','-eo','pid,ppid,etimes,args'],text=True)[-5000:])
