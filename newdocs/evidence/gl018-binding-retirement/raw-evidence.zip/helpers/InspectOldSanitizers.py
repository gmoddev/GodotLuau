import hashlib, json, zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/followup')
Records=[]
for Id,Expected in [(13080425872,'c782a218079a0b09415155fdd777121d804d3dc6b1300c343abd205174f2604e'),(13079900738,'b26ac173de9703fc91f45d52dc56e152e52db21dd750a730876308d5adc83cc1')]:
 File=Root/('old-'+str(Id)+'.zip'); Digest=hashlib.sha256(File.read_bytes()).hexdigest(); assert Digest==Expected
 with zipfile.ZipFile(File) as Archive:
  Names={Name.replace('\\','/'):Name for Name in Archive.namelist()}
  SummaryName=next(Name for Name in Names if Name.endswith('/sanitizer-summary.json'))
  Prefix=SummaryName.removesuffix('sanitizer-summary.json')
  Summary=json.loads(Archive.read(Names[SummaryName]))
  Verified=0
  for Name,Hash in Summary['Files'].items():
   Key=Prefix+Name.replace('\\','/')
   assert hashlib.sha256(Archive.read(Names[Key])).hexdigest()==Hash,Key
   Verified+=1
  Results=[{'Label':X['Label'],'Exit':X['Exit'],'Passed':X['Passed'],'TimedOut':X['TimedOut']} for X in Summary['Results']]
  Record={'Artifact':Id,'SHA256':Digest,'VerifiedReports':Verified,'Result':Summary['Result'],'ControlsPassed':Summary['ControlsPassed'],'FullQualification':Summary['FullQualification'],'Results':Results}
  Records.append(Record); print(json.dumps(Record),flush=True)
(Root/'old-hosted-sanitizers-verified.json').write_text(json.dumps(Records,indent=2))
