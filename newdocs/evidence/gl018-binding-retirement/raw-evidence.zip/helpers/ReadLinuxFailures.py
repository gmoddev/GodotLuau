from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement')
for Name in ['full-linux/suite-datastore/stderr.log','full-linux/suite-presentation/stderr.log','asset-binary-control/load-control.stdout.log','asset-binary-control/load-control.stderr.log']:
 P=Root/Name
 if P.exists(): print(Name+'\n'+'\n'.join(P.read_text(errors='replace').splitlines()[-15:]),flush=True)
