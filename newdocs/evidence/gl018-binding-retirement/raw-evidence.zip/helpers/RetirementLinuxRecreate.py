import hashlib,json,shutil,subprocess,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); Output=Root/'retirement'
def Run(Command,Name,Timeout=60):
 with (Output/(Name+'.log')).open('w') as Log:
  Result=subprocess.run(Command,stdout=Log,stderr=subprocess.STDOUT,timeout=Timeout)
 print(Name,Result.returncode,flush=True)
 if Result.returncode: print((Output/(Name+'.log')).read_text(errors='replace')[-3000:],flush=True)
 return Result.returncode
assert shutil.disk_usage('C:/').free>5*1024**3
Info=json.loads(subprocess.check_output(['docker','inspect','codex-gl018-retirement'],timeout=20))[0]
assert Info['Config']['Labels']['codex.task']=='gl018-retirement'
assert Run(['docker','exec','codex-gl018-retirement','tar','-czf','/evidence/linux-retirement-cache.tar.gz','-C','/work','.'],'cache-archive',300)==0
Archive=Output/'linux-retirement-cache.tar.gz'
Record={'Bytes':Archive.stat().st_size,'SHA256':hashlib.sha256(Archive.read_bytes()).hexdigest(),'CFreeBefore':shutil.disk_usage('C:/').free}
(Output/'linux-retirement-cache.json').write_text(json.dumps(Record,indent=2))
assert Run(['docker','stop','--time','10','codex-gl018-retirement'],'stop-initial')==0
assert Run(['docker','rm','codex-gl018-retirement'],'remove-initial')==0
assert Run(['docker','volume','create','--label','codex.task=gl018-retirement','codex-gl018-retirement-profiles'],'create-profiles')==0
Command=['docker','run','--detach','--name','codex-gl018-retirement','--label','codex.task=gl018-retirement','--cpus','2','--memory','10g','--pids-limit','512','--tmpfs','/work:rw,exec,size=6g','--mount','type=bind,source='+str(Root)+',target=/retained,readonly','--mount','type=bind,source='+str(Output)+',target=/evidence','--mount','type=volume,source=codex-character-qualification-linux-v1,target=/cache,readonly','--mount','type=bind,source='+str(Root/'source/tests/runtime')+',target=/cache/source/tests/runtime,readonly','--mount','type=bind,source='+str(Root/'source/src')+',target=/cache/source/src,readonly','--mount','type=volume,source=codex-gl018-retirement-profiles,target=/profiles','sha256:4eeae307153445eff9e085c872580bc65ee05b43d80c9561ddd3e9a20d269f2d','sleep','14400']
assert Run(Command,'create-qualified-container')==0
assert Run(['docker','exec','codex-gl018-retirement','tar','-xzf','/evidence/linux-retirement-cache.tar.gz','-C','/work'],'restore-cache',300)==0
assert Run(['docker','exec','codex-gl018-retirement','stat','-f','-c','%T %t','/profiles'],'profile-filesystem')==0
(Output/'capacity-recreated.json').write_text(json.dumps({Drive:shutil.disk_usage(Drive)._asdict() for Drive in ['C:/','E:/']},indent=2))
