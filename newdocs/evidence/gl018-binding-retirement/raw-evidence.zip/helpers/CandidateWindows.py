import ctypes, hashlib, json, os, re, shutil, subprocess, sys, time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); Source=Root/'source'; Runtime=Source/'tests/runtime'
Driver=Path('C:/Sandbox/Codex/Workspaces/GodotLuau'); Build=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan')
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess, StopProcess, StopAll
from SourceFingerprint import GetFingerprint
Output=Root/'followup/windows-candidate-build'; Output.mkdir(exist_ok=False)
Deadline=time.monotonic()+600
while not (Root/'followup/windows-full/sanitizer-summary.json').is_file():
 if time.monotonic()>Deadline: raise TimeoutError('Baseline full attempt has not finished; no build inputs changed')
 time.sleep(5)
for Name in ['godot_luau.dll','ExecutionDomainTests.exe','godot_luau_store_worker.exe','DatastoreBackendProbe.exe']:
 shutil.copy2(Build/Name,Output/('baseline-'+Name))
shutil.copy2(Root/'followup/luau_stdlib-current.h',Source/'src/core/luau_stdlib.h')
for Name in ['ExecutionDomainTests.cpp','HttpServiceIntegration.gd','RunNativeSanitizers.py','RunCharacterPresentation.py','BundleCharacterAssets.gd']:
 shutil.copy2(Root/'followup/current-runtime'/Name,Runtime/Name)
Compiler=Path(re.search(r'CMAKE_CXX_COMPILER:FILEPATH=(.+)',(Build/'CMakeCache.txt').read_text())[1])
for Line in subprocess.check_output(['cmd','/d','/c',str(Root/'QualificationEnvironment.cmd')],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Name,Value=Line.split('=',1);os.environ[Name]=Value
CMake=Path('C:/Sandbox/Codex/Tools/cmake-3.31.10/cmake-3.31.10-windows-x86_64/bin/cmake.exe')
def Hash(File): return hashlib.sha256(Path(File).read_bytes()).hexdigest()
Test=Driver/'tests/runtime/ExecutionDomainTests.cpp'; Backup=Output/'prior-ExecutionDomainTests.cpp'
assert Test.read_bytes().replace(b'\r\n',b'\n')==(Root/'followup/prior-ExecutionDomainTests.cpp').read_bytes().replace(b'\r\n',b'\n'), 'Shared driver changed; preserve it'
shutil.copy2(Test,Backup)
Identity={'Revision':'241396b46f193ea48e63294594bce2d7104f6966','Source':GetFingerprint(Source),'CompilerSHA256':Hash(Compiler),'Commands':[],'CoreTestSHA256':Hash(Runtime/'ExecutionDomainTests.cpp')}
try:
 shutil.copy2(Runtime/'ExecutionDomainTests.cpp',Test)
 with (Output/'build.log').open('w') as Log:
  Command=[str(CMake),'--build',str(Build),'--target','GodotLuauAdapter','ExecutionDomainTests','DatastoreBackendProbe','--parallel','2']
  Child=StartProcess(Command,Log,subprocess.STDOUT,dict(os.environ))
  ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(int(Child._handle)),0x4000)
  try: Code=Child.wait(timeout=3600)
  finally: StopProcess(Child)
 Identity['Commands'].append({'Command':Command,'Exit':Code,'LogSHA256':Hash(Output/'build.log')})
 assert Code==0
 Identity['Products']={Name:Hash(Build/Name) for Name in ['godot_luau.dll','ExecutionDomainTests.exe','godot_luau_store_worker.exe','DatastoreBackendProbe.exe']}
 Identity['CompileCommandsSHA256']=Hash(Build/'compile_commands.json')
 (Output/'build-identity.json').write_text(json.dumps(Identity,indent=2))
finally:
 assert Hash(Test)==Hash(Runtime/'ExecutionDomainTests.cpp')
 shutil.copy2(Backup,Test)
 StopAll()
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
Command=[sys.executable,str(Runtime/'RunNativeSanitizers.py'),'--godot',Host['Executable'],'--host-manifest',str(Root/'godot-host/sanitizer-host.json'),'--extension',str(Build/'godot_luau.dll'),'--build',str(Build),'--build-identity',str(Output/'build-identity.json'),'--probe',str(Root/'followup/windows-probes/NativeSanitizerProbe.dll'),'--loader',str(Root/'followup/windows-probes/NativeSanitizerLoader.exe'),'--asset-godot',str(Root/'asset-editor/Godot_v4.7.1-stable_win64.exe'),'--asset-provenance',str(Root/'asset-editor/provenance.json'),'--revision','241396b46f193ea48e63294594bce2d7104f6966+asset-followup','--output',str(Root/'followup/windows-candidate-full')]
with (Output/'qualification.log').open('w') as Log:
 Result=subprocess.run(Command,stdout=Log,stderr=subprocess.STDOUT,timeout=2400)
print('candidate qualification exit='+str(Result.returncode),flush=True)
print((Output/'qualification.log').read_text(errors='replace')[-4000:],flush=True)
