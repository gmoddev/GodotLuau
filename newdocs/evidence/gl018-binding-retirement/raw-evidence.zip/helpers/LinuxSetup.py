import hashlib,json,subprocess
from pathlib import Path
Root=Path('C:/Sandbox/Codex/NativeSanitizers')
Code=r'''
import hashlib,json,shutil,tarfile,subprocess,zipfile
from pathlib import Path
Root=Path('/work/native-sanitizers')
Root.mkdir(exist_ok=False)
Archive=Path('/work/gl018-godot-source.tar.gz')
assert hashlib.sha256(Archive.read_bytes()).hexdigest()=='98c5c1c101d15d43de5e3dca81cfb57ef3698495d67eeaf5e34db739b751bbb9'
with tarfile.open(Archive) as Tar: Tar.extractall(Root,filter='data')
(Root/'godot-a13da4feb8d8aefc283c3763d33a2f170a18d541').rename(Root/'godot-host')
Source=Path('/work/gl018-starting-source.zip')
assert hashlib.sha256(Source.read_bytes()).hexdigest()=='3a83935af350ef51082fcabdc4bf1d74b160810a13f716a785873a8e5fddd2dd'
with zipfile.ZipFile(Source) as Zip: Zip.extractall(Root/'source')
print(json.dumps({'Tools':{Name:shutil.which(Name) for Name in ['clang++-19','clang-19','scons','pkg-config','ld.lld','lld','ld.lld-19','cmake','ninja','gdb','lldb']},'FreeGiB':shutil.disk_usage(Root).free//1024**3}),flush=True)
for Name in ['SConstruct','platform/linuxbsd/detect.py']:
 Text=(Root/'godot-host'/Name).read_text()
 for Line in Text.splitlines():
  if any(Value in Line for Value in ['CXX','CCFLAGS','fno-omit','EnsureSConsVersion']): print(Name+': '+Line)
for File in (Root/'godot-host/platform').rglob('*.cpp'):
 if 'DEEPBIND' in File.read_text(errors='replace'):
  print('DEEPBIND source '+str(File))
  Lines=File.read_text().splitlines()
  for Index,Line in enumerate(Lines):
   if 'DEEPBIND' in Line: print('\n'.join(Lines[max(0,Index-4):Index+4]))
'''
subprocess.run(['docker','cp','C:/Sandbox/Codex/GL018StartingSource.zip','codex-character-linux:/work/gl018-starting-source.zip'],check=True,timeout=60)
subprocess.run(['docker','exec','codex-character-linux','python3','-c',Code],check=True,timeout=180)
subprocess.run(['docker','cp','C:/Sandbox/Codex/Tools/GodotLuauSCons','codex-character-linux:/work/native-sanitizers/scons'],check=True,timeout=90)
subprocess.run(['docker','exec','-e','PYTHONPATH=/work/native-sanitizers/scons','codex-character-linux','python3','-m','SCons','--version'],check=True,timeout=30)
