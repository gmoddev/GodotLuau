import hashlib,json,shutil,time,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Work=Root/'retirement';Evidence=Work/'delivery';Evidence.mkdir(exist_ok=False)
Files=[]
for Directory in [Work,Root/'helpers']:
 for File in Directory.rglob('*'):
  if not File.is_file() or 'delivery' in File.parts:continue
  Relative=File.relative_to(Root).as_posix()
  if '/native/' in Relative and '/windows-o1' in Relative and File.name not in ['compile_commands.json','CMakeCache.txt']:continue
  if File.suffix in ['.py','.gd','.log','.json','.xml','.patch'] or File.name in ['host-symbols.txt','CMakeCache.txt'] or File.name.startswith('asan-report'):
   assert File.stat().st_size<25*1024*1024,Relative
   Files.append(File)
Files.extend([Root/'godot-host/sanitizer-host.json',Root/'asset-editor/provenance.json',Root/'followup/windows-candidate-build/build-identity.json',Root/'LinuxWork/linux-full-fresh/suite-performance/asan-report.5926'])
Files.extend(Work.glob('ci-*.zip'));Files.extend(Work.glob('core011-*.zip'));Files.extend(Work.glob('native011-*.zip'))
Files=sorted(set(Files));Hashes={}
Archive=Evidence/'raw-evidence.zip'
with zipfile.ZipFile(Archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as Zip:
 for File in Files:
  Name=File.relative_to(Root).as_posix();Data=File.read_bytes();Hashes[Name]=hashlib.sha256(Data).hexdigest();Zip.writestr(Name,Data)
 Zip.writestr('raw-files.json',json.dumps(Hashes,indent=2))
with zipfile.ZipFile(Archive) as Zip:
 assert len(Zip.namelist())==len(Hashes)+1
 for Name,Digest in Hashes.items():assert hashlib.sha256(Zip.read(Name)).hexdigest()==Digest
Selected={'latest-ci-verified.json':'latest-ci-verified.json','local-profile-verification.json':'local-profile-verification.json','linux-native-final-verified.json':'linux-native-final-verified.json','final-cache-identities.json':'final-cache-identities.json','production-gdb-final/gdb.log':'linux-production-gdb.log','production-gdb-final/diagnostic.json':'linux-production-diagnostic.json','historical-leak-symbols-v4/verification.json':'historical-symbol-verification.json','historical-leak-symbols-v4/host-symbols.txt':'historical-leak-functions.txt','windows-classes/production/investigation.json':'windows-original-bindings.json','linux-classes/production/investigation.json':'linux-original-bindings.json','host-windows-production/investigation.json':'windows-corrected-bindings.json','host-linux-production/investigation.json':'linux-corrected-bindings.json'}
for Source,Target in Selected.items():
 File=Work/Source
 if File.exists():shutil.copy2(File,Evidence/Target)
Manifest={'Issue':'GL-018','Classification':'PARTIALLY QUALIFIED','Closure':'OPEN','StartingBranch':'dfa700a833f1972b090e645df32e0eee1ccf2f82','Implementation':'92659bae6cc5d7b321b075848b905e9d660b47df','MainUnchanged':'83cd0887968d73d61d050650718d8ada6e124579','NativeSourceSHA256':'2706e1685bdf0207e55eacc2f877e4578a3164603ea5861c183009348c7d1bc8','Scope':'Headless matching-host full-native ASan; Linux LSan enabled; Windows LSan unsupported. Qualification-host patch only; no production runtime source change from starting branch. Windows 110-actor acceptance is still blocked by bounded GL-009 conflicts.','Archive':{'File':Archive.name,'SHA256':hashlib.sha256(Archive.read_bytes()).hexdigest(),'Bytes':Archive.stat().st_size,'VerifiedFiles':len(Hashes),'IndexEntry':'raw-files.json'},'DurableRoot':str(Work),'ReleasesAndUpdater':'disabled','CollectedUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'SelectedFiles':{P.name:hashlib.sha256(P.read_bytes()).hexdigest() for P in Evidence.iterdir() if P.is_file() and P!=Archive}}
(Evidence/'manifest.json').write_text(json.dumps(Manifest,indent=2));print(json.dumps(Manifest,indent=2),flush=True)
