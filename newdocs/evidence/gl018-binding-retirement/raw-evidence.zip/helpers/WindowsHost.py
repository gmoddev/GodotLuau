import ctypes,hashlib,json,os,re,shutil,subprocess,sys,time,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
ctypes.windll.kernel32.SetErrorMode(0x8003)
Archive=Path('C:/Sandbox/Codex/GL018StartingSource.zip')
assert hashlib.sha256(Archive.read_bytes()).hexdigest()=='3a83935af350ef51082fcabdc4bf1d74b160810a13f716a785873a8e5fddd2dd'
Source=Root/'source'
if not Source.exists():
 with zipfile.ZipFile(Archive) as Zip: Zip.extractall(Source)
Cache=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan')
Compiler=Path(re.search(r'CMAKE_CXX_COMPILER:FILEPATH=(.+)',(Cache/'CMakeCache.txt').read_text())[1])
Setup=Compiler.parents[6]/'Auxiliary/Build/vcvars64.bat'
Batch=Root/'CompilerEnvironment.cmd'
Batch.write_text('@echo off\ncall "'+str(Setup)+'" >nul\nif errorlevel 1 exit /b 1\nset\n')
for Line in subprocess.check_output(['cmd','/d','/c',str(Batch)],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Name,Value=Line.split('=',1); os.environ[Name]=Value
os.environ['PYTHONPATH']=str(Root/'scons-4.10.0')
sys.path.insert(0,str(Source/'tests/runtime'))
from FixtureProcesses import StartProcess,StopProcess,StopAll
Engine=Root/'godot-host'
assert json.loads((Root/'engine-source.json').read_text())['ArchiveSHA256']=='98c5c1c101d15d43de5e3dca81cfb57ef3698495d67eeaf5e34db739b751bbb9'
print(json.dumps({'FreeGiB':shutil.disk_usage(Root).free//1024**3,'Compiler':str(Compiler)}),flush=True)
Args=['platform=windows','target=template_debug','arch=x86_64','use_asan=yes','use_static_cpp=no','debug_crt=yes','dev_build=yes','debug_symbols=yes','optimize=none','lto=none','vulkan=no','opengl3=no','d3d12=no','angle=no','modules_enabled_by_default=no',*['module_'+Name+'_enabled=yes' for Name in ['gdscript','multiplayer','enet','mbedtls','godot_physics_2d','godot_physics_3d','freetype','text_server_fb']],'-j2']
Logs=Root/'windows-host-compatible-first'
Logs.mkdir(exist_ok=False)
Command=[sys.executable,'-m','SCons',*Args]
(Logs/'command.json').write_text(json.dumps({'Command':Command,'Cwd':str(Engine),'Timeout':7200,'Priority':'BelowNormal','CompilerSHA256':hashlib.sha256(Compiler.read_bytes()).hexdigest()},indent=2))
os.chdir(Engine)
try:
 with (Logs/'build.log').open('w') as Log:
  Child=StartProcess(Command,Log,subprocess.STDOUT,dict(os.environ))
  assert ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(int(Child._handle)),0x4000)
  try: Code=Child.wait(timeout=7200)
  finally: StopProcess(Child)
 (Logs/'result.json').write_text(json.dumps({'Exit':Code,'LogSHA256':hashlib.sha256((Logs/'build.log').read_bytes()).hexdigest(),'Products':{File.name:hashlib.sha256(File.read_bytes()).hexdigest() for File in (Engine/'bin').glob('*.exe')}},indent=2))
 print('[Qualification:Host] Windows build exit='+str(Code),flush=True)
 if Code: print((Logs/'build.log').read_text(errors='replace')[-6000:],flush=True)
 assert Code==0
finally: StopAll()
