import json, os, shutil, subprocess, sys
from pathlib import Path
Runtime=Path('/work/source/tests/runtime')
for Name in ['InvestigateSanitizerBindings.py','RunCharacterPresentation.py','RunCharacterPerformance.py','BundleCharacterAssets.gd']:
 shutil.copy2(Path('/retained/source/tests/runtime')/Name, Runtime/Name)
shutil.copytree('/retained/source/tests/runtime/sanitizers',Runtime/'sanitizers',dirs_exist_ok=True)
Output=Path('/qualification/followup')
with (Output/'probes-rebuild.log').open('w') as Log:
 subprocess.run(['cmake','--build',str(Output/'probes'),'--parallel','2'],stdout=Log,stderr=subprocess.STDOUT,check=True,timeout=120)
Host=json.loads(Path('/work/godot-host/sanitizer-host.json').read_text())
subprocess.run([sys.executable,str(Runtime/'InvestigateSanitizerBindings.py'),'--godot',Host['Executable'],'--probe',str(Output/'probes/NativeSanitizerProbe.so'),'--output',str(Output/'bindings-get-api')],check=True,timeout=180)
Environment=dict(os.environ, GODOT_SILENCE_ROOT_WARNING='1')
Command=[sys.executable,str(Runtime/'RunNativeSanitizers.py'),'--godot',Host['Executable'],'--host-manifest','/work/godot-host/sanitizer-host.json','--extension','/work/fresh-asan/godot_luau.so','--build','/work/fresh-asan','--build-identity','/retained/LinuxWork/linux-native-products/build-identity.json','--probe',str(Output/'probes/NativeSanitizerProbe.so'),'--loader',str(Output/'probes/NativeSanitizerLoader'),'--asset-godot','/cache/godot/Godot_v4.7.1-stable_linux.x86_64','--asset-provenance','/cache/godot/provenance.json','--revision','66362c737f4185461f2da4de218e9eeb127cb10e+qualification-followup','--output','/qualification/full-followup']
with (Output/'full.log').open('w') as Log:
 Result=subprocess.run(Command,stdout=Log,stderr=subprocess.STDOUT,env=Environment,timeout=2400)
print('full exit='+str(Result.returncode),flush=True)
print((Output/'full.log').read_text(errors='replace')[-4000:],flush=True)
