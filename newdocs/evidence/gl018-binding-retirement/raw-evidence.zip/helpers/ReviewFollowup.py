import hashlib,json,shutil,sys
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Followup=Root/'followup'
sys.path.insert(0,str(Root/'source/tests/runtime'))
from SourceFingerprint import GetFingerprint
Record={'NativeSource':GetFingerprint(Root/'source'),'DiskFreeC':shutil.disk_usage('C:/').free,'Attempts':{}}
for Name in ['windows-full','windows-candidate-full','linux-salvage/full-followup']:
 Directory=Followup/Name;File=Directory/'results.json'
 Results=json.loads(File.read_text()) if File.exists() else []
 Groups={}
 for Group in ['regression','security','animation','characters','resources','filesystem','http','httpservice','callers','datastore','presentation','performance']:
  File=Directory/'native'/Group/'results.json'
  if File.is_file():
   Items=json.loads(File.read_text());Groups[Group]={'RecordedActors':len(Items),'Exits':[Item['Exit'] for Item in Items]}
 Record['Attempts'][Name]={'Complete':(Directory/'sanitizer-summary.json').is_file(),'Results':[{K:Item[K] for K in ['Label','Exit','Passed','TimedOut']} for Item in Results],'RecordedGroups':Groups}
for Name in ['windows-bindings-get-api','linux-salvage/followup/bindings-get-api']:
 File=Followup/Name/'binding-investigation.json'
 Value=json.loads(File.read_text());Record[Name]={'GodotSHA256':Value['GodotSHA256'],'ProbeSHA256':Value['ProbeSHA256'],'Results':[{K:Item[K] for K in ['Mode','Exit','TimedOut','BindingsInstalled','BindingsFreed','LifecyclePASS']} for Item in Value['Results']]}
Record['SharedDriverRestored']=hashlib.sha256(Path('C:/Sandbox/Codex/Workspaces/GodotLuau/tests/runtime/ExecutionDomainTests.cpp').read_bytes()).hexdigest()==hashlib.sha256((Followup/'windows-candidate-build/prior-ExecutionDomainTests.cpp').read_bytes()).hexdigest()
(Followup/'review.json').write_text(json.dumps(Record,indent=2));print(json.dumps(Record),flush=True)
