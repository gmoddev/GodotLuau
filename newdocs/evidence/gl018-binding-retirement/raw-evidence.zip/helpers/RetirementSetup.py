import json, shutil, subprocess, time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
Output=Root/'retirement'; Output.mkdir(exist_ok=True)
def Run(Command,Timeout=40):
 Result=subprocess.run(Command,capture_output=True,text=True,timeout=Timeout)
 print(json.dumps({'Command':Command,'Exit':Result.returncode,'Out':Result.stdout[-6000:],'Err':Result.stderr[-1000:]}),flush=True)
 return Result
Capacity={Drive:shutil.disk_usage(Drive)._asdict() for Drive in ['C:/','E:/']}
(Output/'capacity-before.json').write_text(json.dumps(Capacity,indent=2))
assert Capacity['C:/']['free']>5*1024**3 and Capacity['E:/']['free']>20*1024**3
Run(['docker','ps','-a','--format','{{.Names}} {{.Status}}'])
assert Run(['docker','run','--detach','--name','codex-gl018-retirement','--label','codex.task=gl018-retirement','--cpus','2','--memory','10g','--pids-limit','512','--tmpfs','/work:rw,exec,size=6g','--mount','type=bind,source='+str(Root)+',target=/retained,readonly','--mount','type=bind,source='+str(Output)+',target=/evidence','sha256:4eeae307153445eff9e085c872580bc65ee05b43d80c9561ddd3e9a20d269f2d','sleep','21600']).returncode==0
assert Run(['docker','exec','codex-gl018-retirement','tar','-xzf','/retained/LinuxWork/linux-build-cache.tar.gz','-C','/work'],240).returncode==0
Run(['docker','exec','codex-gl018-retirement','bash','-lc','df -h /work /evidence; file /work/godot-host/bin/*; ls -lh /work/godot-host/bin; command -v gdb; rg -n "strip|debug_symbols" /work/godot-host/platform/linuxbsd/detect.py /work/godot-host/SConstruct | head -30; ls /work/fresh-asan | head -15'])
(Output/'capacity-after-setup.json').write_text(json.dumps({Drive:shutil.disk_usage(Drive)._asdict() for Drive in ['C:/','E:/']},indent=2))
