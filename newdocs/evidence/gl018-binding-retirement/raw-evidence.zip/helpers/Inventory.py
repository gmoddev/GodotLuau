import json,subprocess
from pathlib import Path
Commands=[['hostname'],['docker','inspect','codex-character-linux'],['powershell.exe','-NoProfile','-Command',"Get-CimInstance Win32_Processor | Select-Object Name,NumberOfLogicalProcessors,LoadPercentage | ConvertTo-Json -Compress"],['powershell.exe','-NoProfile','-Command',"Get-CimInstance Win32_OperatingSystem | Select-Object TotalVisibleMemorySize,FreePhysicalMemory | ConvertTo-Json -Compress"]]
for Command in Commands:
 Result=subprocess.run(Command,capture_output=True,text=True,timeout=30)
 if Command[:2]==['docker','inspect'] and Result.returncode==0:
  Info=json.loads(Result.stdout)[0]
  print(json.dumps({'Container':Info['Name'],'State':Info['State']['Status'],'Resources':{Key:Info['HostConfig'][Key] for Key in ['NanoCpus','Memory','PidsLimit']},'Mounts':[{'Name':Item.get('Name'),'Destination':Item['Destination']} for Item in Info['Mounts']]}),flush=True)
 else: print(json.dumps({'Command':Command,'Exit':Result.returncode,'Output':Result.stdout.strip(),'Error':Result.stderr.strip()}),flush=True)
for Folder in ['C:/Sandbox/Codex/Tools','C:/Sandbox/Codex/Builds','C:/Sandbox/Codex/Workspaces']:
 Root=Path(Folder)
 print(json.dumps({'Root':Folder,'Entries':[Item.name for Item in Root.iterdir()]}),flush=True)
 for Item in Root.iterdir():
  if Item.is_dir() and ('godot' in Item.name.lower() or 'llvm' in Item.name.lower()): print(json.dumps({'Directory':str(Item),'Children':[Child.name for Child in Item.iterdir()]}),flush=True)
