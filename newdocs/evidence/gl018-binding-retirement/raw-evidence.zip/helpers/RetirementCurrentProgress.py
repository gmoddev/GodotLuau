from pathlib import Path
import shutil
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement')
for Name in ['windows-o1/configure.log','windows-o1/build.log','windows-o1/core.log','windows-o1/http.log','windows-o1/httpservice.log','windows-o1/datastore.log','full-linux-binary.log']:
 P=Root/Name
 if P.exists():print(Name+'\n'+'\n'.join(P.read_text(errors='replace').splitlines()[-4:]),flush=True)
print('Capacity',[(Drive,shutil.disk_usage(Drive).free) for Drive in ['C:/','E:/']],flush=True)
