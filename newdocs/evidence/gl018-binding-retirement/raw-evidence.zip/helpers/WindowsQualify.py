import argparse,hashlib,json,os,re,subprocess,sys
from pathlib import Path
Parser=argparse.ArgumentParser(); Parser.add_argument('--attempt',required=True); Parser.add_argument('--controls-only',action='store_true'); Parser.add_argument('--revision',required=True); Args=Parser.parse_args()
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); Build=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan')
Compiler=Path(re.search(r'CMAKE_CXX_COMPILER:FILEPATH=(.+)',(Build/'CMakeCache.txt').read_text())[1])
Batch=Root/'QualificationEnvironment.cmd'; Batch.write_text('@echo off\ncall "'+str(Compiler.parents[6]/'Auxiliary/Build/vcvars64.bat')+'" >nul\nset\n')
for Line in subprocess.check_output(['cmd','/d','/c',str(Batch)],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Name,Value=Line.split('=',1); os.environ[Name]=Value
CRT=sorted((Compiler.parents[6]/'Redist/MSVC').glob('*/debug_nonredist/x64/Microsoft.VC*.DebugCRT'))[-1]
os.environ['PATH']=str(Compiler.parent)+os.pathsep+str(CRT)+os.pathsep+'C:/Sandbox/Codex/Tools/cmake-3.31.10/cmake-3.31.10-windows-x86_64/bin'+os.pathsep+os.environ['PATH']
if not Args.controls_only:
 import shutil
 shutil.copy2(Build/'compile_commands.json',Root/'products/windows-asan/compilation-before-c-flags.json')
 with (Root/'products/windows-asan/configure-c-flags.log').open('w') as Log:
  subprocess.run(['cmake','-S','C:/Sandbox/Codex/Workspaces/GodotLuau/tests/runtime','-B',str(Build),'-DCMAKE_C_FLAGS=/fsanitize=address','-DCMAKE_C_FLAGS_DEBUG=/Zi /Od'],stdout=Log,stderr=subprocess.STDOUT,check=True,timeout=120)
Identity=json.loads((Root/'products/windows-asan/identity.json').read_text())
Identity['PriorIdentitySHA256']=hashlib.sha256((Root/'products/windows-asan/identity.json').read_bytes()).hexdigest()
Identity['CompilerSHA256']=hashlib.sha256(Compiler.read_bytes()).hexdigest()
Identity['CompilerHashCorrection']='Prior helper normalized newlines for every file, including compiler PE. This manifest records raw compiler bytes; product hashes and production inputs unchanged.'
Identity['CompileCommandsSHA256']=hashlib.sha256((Build/'compile_commands.json').read_bytes()).hexdigest()
Manifest=Root/'products/windows-asan/current-build-identity.json'; Manifest.write_text(json.dumps(Identity,indent=2))
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
Command=[sys.executable,str(Root/'source/tests/runtime/RunNativeSanitizers.py'),'--godot',Host['Executable'],'--probe',str(Root/'probes-instrumented-loader/NativeSanitizerProbe.dll'),'--loader',str(Root/'probes-instrumented-loader/NativeSanitizerLoader.exe'),'--revision',Args.revision,'--output',str(Root/Args.attempt)]
if Args.controls_only: Command+=['--controls-only']
else: Command+=['--host-manifest',str(Root/'godot-host/sanitizer-host.json'),'--extension',str(Build/'godot_luau.dll'),'--build',str(Build),'--build-identity',str(Manifest),'--asset-godot',str(Root/'asset-editor/Godot_v4.7.1-stable_win64.exe'),'--asset-provenance',str(Root/'asset-editor/provenance.json')]
subprocess.run(Command,check=True,timeout=2400)
