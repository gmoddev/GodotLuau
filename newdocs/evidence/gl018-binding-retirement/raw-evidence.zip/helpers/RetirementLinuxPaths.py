import json
from pathlib import Path
Root=Path('/work/fresh-asan')
Lines=(Root/'CMakeCache.txt').read_text().splitlines()
print('\n'.join(Line for Line in Lines if any(Term in Line for Term in ['GL_SOURCE','CMAKE_HOME','GodotLuau','SOURCE_DIR'])))
Commands=json.loads((Root/'compile_commands.json').read_text())
for Record in [Commands[0],next(R for R in Commands if R['file'].endswith('register_types.cpp'))]:print(Record)
print('source',[(str(P),P.is_symlink(),str(P.resolve())) for P in Path('/work/source').iterdir() if P.name in ['godot-cpp','luau']])
