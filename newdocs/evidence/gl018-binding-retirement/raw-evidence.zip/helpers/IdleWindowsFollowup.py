import json,os,subprocess,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Runtime=Root/'source/tests/runtime'
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
Output=Root/'followup/windows-idle-followup';Output.mkdir(exist_ok=False)
Deadline=time.monotonic()+1800
while not (Root/'followup/windows-candidate-full/sanitizer-summary.json').exists():
 if time.monotonic()>Deadline: raise TimeoutError('Candidate full attempt still active; idle trials not started')
 time.sleep(5)
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
Environment=dict(os.environ,ASAN_OPTIONS='halt_on_error=1:log_path="'+(Output/'asan-report').as_posix()+'"')
Results=[]
try:
 for Name,Flags in [('regression',['--teardown','--coordinated-close']),('animation',['--animation']),('http',['--http']),('datastore',['--datastore'])]:
  Command=[sys.executable,str(Runtime/'RunQualification.py'),'--godot',Host['Executable'],'--extension','C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/godot_luau.dll','--output',str(Output/Name),'--timeout','60',*Flags]
  with (Output/(Name+'.log')).open('w') as Log:
   Child=StartProcess(Command,Log,subprocess.STDOUT,Environment)
   try: Code=Child.wait(timeout=360)
   finally: StopProcess(Child)
  Results.append({'Group':Name,'Exit':Code,'Command':Command})
  (Output/'results.json').write_text(json.dumps(Results,indent=2))
  print('[Runtime:IdleSanitizers]',Name,'exit=',Code,flush=True)
finally:StopAll()
