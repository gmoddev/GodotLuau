from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/godot-host')
for Name,Terms in [('core/object/object.cpp',['void Object::free_instance_binding','void Object::set_instance_binding']),('scene/resources/compressed_texture.cpp',['get_recognized_extensions','ctex','load_image_from_file']),('modules/register_module_types.gen.cpp',['initialize_'])]:
 Lines=(Root/Name).read_text().splitlines()
 for Index,Line in enumerate(Lines):
  if any(Term in Line for Term in Terms): print(Name+':'+str(Index+1)+'\n'+'\n'.join(Lines[max(0,Index-2):Index+35]))
