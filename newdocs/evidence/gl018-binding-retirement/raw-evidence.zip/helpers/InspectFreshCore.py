import hashlib,json,sys,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');sys.path.insert(0,str(Root/'source/tests/runtime'))
from CheckCoreCI import CheckDiscovery,CheckReport
Records=[]
for Item in json.loads((Root/'followup/fresh-core-artifacts.json').read_text()):
 File=Root/('followup/fresh-'+str(Item['id'])+'.zip'); Digest=hashlib.sha256(File.read_bytes()).hexdigest();assert Item['digest']=='sha256:'+Digest
 assert Item['workflow_run']['head_sha']=='246601599e581bd1c34cc403adcafcc404f89ae7'
 Directory=Root/'followup/hosted-core'/Item['name'];Directory.mkdir(parents=True,exist_ok=False)
 with zipfile.ZipFile(File) as Zip:
  for Suffix in ['discovery.json','core-results.xml']:
   Name=next(Name for Name in Zip.namelist() if Name.endswith('/'+Suffix) or Name==Suffix)
   (Directory/Suffix).write_bytes(Zip.read(Name))
 CheckDiscovery(Directory/'discovery.json');CheckReport(Directory/'core-results.xml')
 Records.append({'ArtifactID':Item['id'],'Name':Item['name'],'SHA256':Digest,'Revision':Item['workflow_run']['head_sha'],'Cases':80,'CompleteReportVerified':True})
(Root/'followup/fresh-core-verified.json').write_text(json.dumps(Records,indent=2));print(json.dumps(Records),flush=True)
