import json, subprocess
from pathlib import Path
for Command in [['docker','desktop','status'],['wsl','--list','--verbose'],['powershell.exe','-NoProfile','-Command',"Get-Process *docker*,*wsl* -ErrorAction SilentlyContinue | Select-Object Name,Id,SessionId | ConvertTo-Json -Compress"]]:
 Result=subprocess.run(Command,capture_output=True,timeout=30)
 print({'Command':Command,'Exit':Result.returncode,'Output':Result.stdout.decode('utf-16' if b'\x00' in Result.stdout[:100] else 'utf8',errors='replace')[-3000:],'Error':Result.stderr.decode(errors='replace')[-500:]},flush=True)
Log=Path.home()/'AppData/Local/Docker/log/host'
for Pattern in ['com.docker.backend.exe.log','Docker Desktop.exe.log']:
 Files=list(Log.glob(Pattern+'*'))
 if Files:
  File=max(Files,key=lambda P:P.stat().st_mtime)
  Lines=File.read_text(errors='replace').splitlines()
  print(File.name+'\n'+'\n'.join([Line for Line in Lines[-400:] if any(Term in Line.lower() for Term in ['error','fatal','failed','stopping','starting'])][-15:]))
