import hashlib,json,subprocess,tarfile,time,urllib.request
from pathlib import Path
Root=Path('C:/Sandbox/Codex/NativeSanitizers')
Root.mkdir(exist_ok=False)
Revision='a13da4feb8d8aefc283c3763d33a2f170a18d541'
Archive=Root/'godot-source.tar.gz'
Started=time.monotonic()
with urllib.request.urlopen('https://codeload.github.com/godotengine/godot/tar.gz/'+Revision,timeout=30) as Response, Archive.open('wb') as File:
 Count=0
 while Block:=Response.read(1024*1024):
  File.write(Block); Count+=len(Block)
  if Count%(16*1024*1024)==0: print('[Qualification:Host] Downloaded '+str(Count//1024//1024)+' MiB',flush=True)
  assert time.monotonic()-Started<240
Digest=hashlib.sha256(Archive.read_bytes()).hexdigest()
with tarfile.open(Archive) as Tar:
 assert all(Item.name.startswith('godot-'+Revision+'/') or Item.name=='godot-'+Revision for Item in Tar.getmembers())
 Tar.extractall(Root,filter='data')
Source=Root/('godot-'+Revision)
Source.rename(Root/'godot-host')
Identity={'Revision':Revision,'ArchiveSHA256':Digest,'Bytes':Archive.stat().st_size,'URL':'https://codeload.github.com/godotengine/godot/tar.gz/'+Revision}
(Root/'engine-source.json').write_text(json.dumps(Identity,indent=2))
print(json.dumps(Identity),flush=True)
Info=json.loads(subprocess.check_output(['docker','inspect','codex-character-linux'],timeout=30))[0]
assert Info['HostConfig']['NanoCpus']==2000000000 and Info['HostConfig']['Memory']==6*1024**3
assert any(Item.get('Name')=='codex-character-qualification-linux-v1' for Item in Info['Mounts'])
assert not Info['State']['Running']
subprocess.run(['docker','start','codex-character-linux'],check=True,timeout=30)
subprocess.run(['docker','cp',str(Archive),'codex-character-linux:/work/gl018-godot-source.tar.gz'],check=True,timeout=180)
Code="import sys,subprocess,json; from pathlib import Path; print(subprocess.check_output(['clang++-19','--version']).decode().splitlines()[0]); print(subprocess.check_output(['scons','--version']).decode().splitlines()[0]); print(subprocess.check_output(['df','-h','/work']).decode()); print([str(P) for P in Path('/work').glob('*godot*')]); print([str(P) for P in Path('/usr/bin').glob('*lld*')])"
subprocess.run(['docker','exec','codex-character-linux','python3','-c',Code],check=True,timeout=30)
