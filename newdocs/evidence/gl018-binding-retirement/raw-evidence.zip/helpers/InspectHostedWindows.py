import json,re,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement')
for Identity in [13120149350,13121584607]:
 with zipfile.ZipFile(Root/('ci-'+str(Identity)+'.zip')) as Zip:
  print(Identity)
  for Name in Zip.namelist():
   if Name.endswith('stderr.log') and any('/suite-'+G+'/' in Name for G in ['animation','datastore']):
    Text=Zip.read(Name).decode(errors='replace');print(Name,[Line for Line in Text.splitlines() if 'RuntimeError:' in Line or 'FAIL' in Line or 'retry limit' in Line])
  Inputs=json.loads(Zip.read(next(N for N in Zip.namelist() if N.endswith('/inputs.json'))));print('Host',Inputs['GodotSHA256'],'Instrumented',Inputs['InstrumentedFiles'])
  Summary=json.loads(Zip.read(next(N for N in Zip.namelist() if N.endswith('sanitizer-summary.json'))));print('PassingGates',[R['Label'] for R in Summary['Results'] if R['Passed']])
