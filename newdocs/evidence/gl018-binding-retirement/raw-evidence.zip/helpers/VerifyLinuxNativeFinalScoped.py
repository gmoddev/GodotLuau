import hashlib,json,re,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement');Directory=Root/'full-linux-binary/native';Summary=json.loads((Directory/'summary.json').read_text())
with zipfile.ZipFile(Root/'harness-final.zip') as Zip:
 Harness={N.removeprefix('tests/runtime/'):hashlib.sha256(Zip.read(N).replace(b'\r\n',b'\n')).hexdigest() for N in Zip.namelist() if not N.endswith('/')}
for Name,Digest in Summary['HarnessHashes'].items():assert Harness[Name.replace('\\','/')]==Digest,Name
for Name,Digest in Summary['LogHashes'].items():assert hashlib.sha256((Directory/Name).read_bytes()).hexdigest()==Digest,Name
Findings=[]
for File in Directory.rglob('*.log'):
 Text=File.read_text(errors='replace')
 if re.search(r'ObjectDB instances (?:were )?leaked|resources still in use|SCRIPT ERROR:|LeakSanitizer|AddressSanitizer:DEADLYSIGNAL|SUMMARY: .*Sanitizer',Text):Findings.append(str(File.relative_to(Directory)))
Record={'Revision':Summary['Revision'],'NativeSource':Summary['NativeSource'],'NativeActors':Summary['Processes'],'VerifiedHarnessInputs':len(Summary['HarnessHashes']),'VerifiedLogHashes':len(Summary['LogHashes']),'UnexpectedLeaksSanitizersOrScriptErrors':Findings,'ExtensionSHA256':Summary['ExtensionSHA256'],'WorkerSHA256':Summary['DataStoreWorkerSHA256'],'DiagnosticsScope':'The earlier broad ERROR audit also matched intentional RPC/ServerStorage/TLS rejection, teardown peer queries and unavailable fontconfig in official preprocessing. Full messages retained in linux-diagnostics-review.json and original logs; no checker or diagnostics were suppressed.'}
(Root/'linux-native-final-verified.json').write_text(json.dumps(Record,indent=2));assert not Findings,Findings
print(Record,flush=True)
