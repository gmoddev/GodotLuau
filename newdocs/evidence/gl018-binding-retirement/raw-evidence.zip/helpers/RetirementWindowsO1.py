import ctypes,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Runtime=Root/'source/tests/runtime';Output=Root/'retirement/windows-o1-2';Output.mkdir(exist_ok=False)
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
from SourceFingerprint import GetFingerprint
ctypes.windll.kernel32.SetErrorMode(0x8003)
for Line in subprocess.check_output(['cmd','/d','/c',str(Root/'QualificationEnvironment.cmd')],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Key,Value=Line.split('=',1);os.environ[Key]=Value
os.environ['PATH']='C:/Sandbox/Codex/Tools/cmake-3.31.10/cmake-3.31.10-windows-x86_64/bin'+os.pathsep+os.environ['PATH']
os.environ['ASAN_OPTIONS']='halt_on_error=1'
for Name in ['LSAN_OPTIONS','LD_PRELOAD']:os.environ.pop(Name,None)
Driver=Path('C:/Sandbox/Codex/Workspaces/GodotLuau');Dependencies={}
for Name,Expected in [('godot-cpp','d5cc777a89d899665fb61f1650ef0dc0cf6488c4'),('luau','9e2984fd0334414a2ef62ceede0c06dab7574d55')]:
 Actual=subprocess.check_output(['git','-C',str(Driver/Name),'rev-parse','HEAD'],text=True,timeout=20).strip();assert Actual==Expected
 assert not subprocess.check_output(['git','-C',str(Driver/Name),'status','--porcelain','--untracked-files=no'],text=True,timeout=20).strip()
 Dependencies[Name]=Actual
 Link=Root/'source'/Name
 if not Link.exists():
  subprocess.run(['powershell.exe','-NoProfile','-Command',"New-Item -ItemType Junction -Path '"+str(Link)+"' -Target '"+str(Driver/Name)+"' | Out-Null"],check=True,timeout=30)
Compiler=Path(shutil.which('cl'));Identity={'Scope':'Investigative Debug ASan /O1; _DEBUG and assertions retained, no NDEBUG; source unchanged','Source':GetFingerprint(Root/'source'),'CompilerSHA256':hashlib.sha256(Compiler.read_bytes()).hexdigest(),'Dependencies':Dependencies,'Commands':[]}
def Run(Command,Name,Timeout):
 with (Output/(Name+'.log')).open('w') as Log:
  Child=StartProcess([str(X) for X in Command],Log,subprocess.STDOUT,dict(os.environ))
  ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(int(Child._handle)),0x4000)
  try:Code=Child.wait(timeout=Timeout)
  finally:StopProcess(Child)
 Identity['Commands'].append({'Command':[str(X) for X in Command],'Exit':Code})
 (Output/'identity.json').write_text(json.dumps(Identity,indent=2));print(Name,Code,flush=True)
 if Code:print((Output/(Name+'.log')).read_text(errors='replace')[-4000:],flush=True)
 return Code
try:
 assert Run(['cmake','-S',Runtime,'-B',Output/'native','-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DPython3_EXECUTABLE='+sys.executable,'-DGL_BUILD_GODOT_ADAPTER=ON','-DCMAKE_CXX_FLAGS=/fsanitize=address','-DCMAKE_C_FLAGS=/fsanitize=address','-DCMAKE_CXX_FLAGS_DEBUG=/Zi /O1','-DCMAKE_C_FLAGS_DEBUG=/Zi /O1','-DCMAKE_EXE_LINKER_FLAGS=/INCREMENTAL:NO','-DCMAKE_SHARED_LINKER_FLAGS=/INCREMENTAL:NO'],'configure',180)==0
 assert Run(['cmake','--build',Output/'native','--target','GodotLuauAdapter','ExecutionDomainTests','DatastoreBackendProbe','--parallel','2'],'build',1800)==0
 Commands=json.loads((Output/'native/compile_commands.json').read_text());assert len(Commands)>100
 assert all('/fsanitize=address' in X['command'] and '/O1' in X['command'] and '/Od' not in X['command'] and '/RTC' not in X['command'] and 'NDEBUG' not in X['command'] for X in Commands)
 Identity['Products']={Name:hashlib.sha256((Output/'native'/Name).read_bytes()).hexdigest() for Name in ['godot_luau.dll','godot_luau_store_worker.exe','ExecutionDomainTests.exe','DatastoreBackendProbe.exe']}
 Identity['CompileCommandsSHA256']=hashlib.sha256((Output/'native/compile_commands.json').read_bytes()).hexdigest()
 Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
 assert Identity['CompilerSHA256']==Host['CompilerSHA256']
 for File in Path(Host['Executable']).parent.glob('*.dll'):shutil.copy2(File,Output/'native'/File.name)
 (Output/'identity.json').write_text(json.dumps(Identity,indent=2))
 assert Run([sys.executable,Runtime/'RunCoreQualification.py','--build',Output/'native','--output',Output/'core'],'core',150)==0
 for Group,Flag in [('http','--http'),('httpservice','--httpservice'),('datastore','--datastore')]:
  Run([sys.executable,Runtime/'RunQualification.py','--godot',Host['Executable'],'--extension',Output/'native/godot_luau.dll','--output',Output/Group,'--timeout','60',Flag],Group,360)
finally:StopAll()
