import hashlib,json,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement');Records=[]
with zipfile.ZipFile(Root/'harness011.zip') as Source:
 Harness={Name.removeprefix('tests/runtime/'):hashlib.sha256(Source.read(Name).replace(b'\r\n',b'\n')).hexdigest() for Name in Source.namelist() if not Name.endswith('/')}
for File in sorted(Root.glob('native011-*.zip')):
 Identity=int(File.stem.split('-')[-1]);Digest=hashlib.sha256(File.read_bytes()).hexdigest()
 with zipfile.ZipFile(File) as Zip:
  Names={Name.replace('\\','/'):Name for Name in Zip.namelist()}
  Name=next(Name for Name in Names if Name.endswith('native-ci/summary.json'));Prefix=Name.removesuffix('summary.json')
  Summary=json.loads(Zip.read(Names[Name]));assert Summary['Revision']=='0119017696b60901a7f0af981387446d82833230'
  assert Summary['NativeSource']['SHA256']=='2706e1685bdf0207e55eacc2f877e4578a3164603ea5861c183009348c7d1bc8'
  assert Summary['Processes']==110 and sum(len(Value) for Value in Summary['Groups'].values())==110
  assert all(Actor['Exit']==0 for Group in Summary['Groups'].values() for Actor in Group)
  for Relative,Hash in Summary['LogHashes'].items(): assert hashlib.sha256(Zip.read(Names[Prefix+Relative.replace('\\','/')])).hexdigest()==Hash
  for Name,Hash in Summary['HarnessHashes'].items(): assert Harness[Name.replace('\\','/')]==Hash,Name
  Actors=Summary['AnimationAuthority'];assert len(Actors)==10 and all(Actor['Complete'] and Actor['Result']=='PASS' and all(Assertion['Passed'] for Assertion in Actor['Assertions']) for Actor in Actors)
  Cases=sum(len(Actor['Cases']) for Actor in Actors);assert Cases==510
  Records.append({'ArtifactID':Identity,'SHA256':Digest,'Revision':Summary['Revision'],'Actors':110,'AnimationActors':10,'AuthorityCases':Cases,'AnimationAssertions':sum(len(Actor['Assertions']) for Actor in Actors),'VerifiedLogHashes':len(Summary['LogHashes']),'VerifiedHarnessInputs':len(Summary['HarnessHashes']),'NativeSource':Summary['NativeSource'],'ReportedExtensionSHA256':Summary['ExtensionSHA256'],'ReportedCompanionSHA256':Summary['DataStoreWorkerSHA256']})
(Root/'native-ci-verified.json').write_text(json.dumps(Records,indent=2));print(Records,flush=True)
