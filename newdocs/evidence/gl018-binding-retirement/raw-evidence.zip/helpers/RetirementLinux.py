import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
Runtime=Path('/work/source/tests/runtime'); Output=Path('/evidence/linux-classes'); Output.mkdir(exist_ok=False)
for Name in ['InvestigateProductionBindings.py','DiagnoseSanitizerUnload.py']:
 shutil.copy2(Path('/retained/source/tests/runtime')/Name,Runtime/Name)
shutil.copytree('/retained/source/tests/runtime/sanitizers',Runtime/'sanitizers',dirs_exist_ok=True)
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
def Run(Command,Name,Timeout=180,Environment=None):
 with (Output/(Name+'.log')).open('w') as Log:
  Child=StartProcess([str(X) for X in Command],Log,subprocess.STDOUT,Environment or dict(os.environ))
  try: Code=Child.wait(timeout=Timeout)
  finally: StopProcess(Child)
 print(Name,Code,flush=True)
 print((Output/(Name+'.log')).read_text(errors='replace')[-2500:],flush=True)
 return Code
try:
 print('tools',[(Tool,shutil.which(Tool)) for Tool in ['clang++-19','gdb','llvm-ar-19','ar','nm','cmake','ninja']],flush=True)
 Header=Path('/evidence/headers')
 print('header',Header,Header.exists(),flush=True)
 assert Run(['cmake','-S',Runtime/'sanitizers','-B','/work/retirement-probes','-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_COMPILER=clang++-19','-DGL_GDEXTENSION_HEADER_ROOT='+str(Header)],'configure')==0
 assert Run(['cmake','--build','/work/retirement-probes','--parallel','2'],'build')==0
 Host=json.loads(Path('/work/godot-host/sanitizer-host.json').read_text())
 assert Run([sys.executable,Runtime/'InvestigateProductionBindings.py','--godot',Host['Executable'],'--extension','/work/fresh-asan/godot_luau.so','--trace','/work/retirement-probes/NativeBindingTrace.so','--output',Output/'production'],'production',420)==0
 print('engine identities',Host,flush=True)
 print('wheels',list(Path('/retained').rglob('scons*.whl')),flush=True)
 print('archives',list(Path('/work/godot-host/bin/obj').rglob('*core*'))[:20],flush=True)
finally: StopAll()
