import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
Root=Path('/work/source'); Runtime=Root/'tests/runtime'; Build=Path('/work/fresh-asan'); Output=Path('/evidence/linux-candidate-build');Output.mkdir(exist_ok=False)
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
from SourceFingerprint import GetFingerprint
def Hash(File):return hashlib.sha256(Path(File).read_bytes()).hexdigest()
def Run(Command,Name,Timeout):
 with (Output/(Name+'.log')).open('w') as Log:
  Child=StartProcess([str(X) for X in Command],Log,subprocess.STDOUT,dict(os.environ))
  try:Code=Child.wait(timeout=Timeout)
  finally:StopProcess(Child)
 print(Name,Code,flush=True)
 print((Output/(Name+'.log')).read_text(errors='replace')[-2400:],flush=True)
 return Code
try:
 assert Run(['apt-get','update'],'apt-update',180)==0
 assert Run(['apt-get','install','--no-install-recommends','-y','libclang-rt-19-dev','git'],'apt-runtime',180)==0
 for Name in ['godot_luau.so','ExecutionDomainTests','godot_luau_store_worker','DatastoreBackendProbe']:
  shutil.copy2(Build/Name,Output/('baseline-'+Name))
 shutil.copy2('/retained/source/src/core/luau_stdlib.h',Root/'src/core/luau_stdlib.h')
 assert GetFingerprint(Root)['SHA256']=='2706e1685bdf0207e55eacc2f877e4578a3164603ea5861c183009348c7d1bc8'
 assert Run(['cmake','-S','/cache/source/tests/runtime','-B',Build,'-DGL_SOURCE_ROOT='+str(Root),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],'configure',180)==0
 assert Run(['cmake','--build',Build,'--target','GodotLuauAdapter','ExecutionDomainTests','DatastoreBackendProbe','--parallel','2'],'build',1800)==0
 Host=json.loads(Path('/work/godot-host/sanitizer-host.json').read_text())
 Identity={'Revision':'0119017696b60901a7f0af981387446d82833230','Source':GetFingerprint(Root),'CompilerSHA256':Hash('/usr/bin/clang++-19'),'CompileCommandsSHA256':Hash(Build/'compile_commands.json'),'Products':{Name:Hash(Build/Name) for Name in ['godot_luau.so','ExecutionDomainTests','godot_luau_store_worker','DatastoreBackendProbe']}}
 assert Identity['CompilerSHA256']==Host['CompilerSHA256']
 (Output/'build-identity.json').write_text(json.dumps(Identity,indent=2))
 print(Identity,flush=True)
 os.environ['GL_QUALIFICATION_PROFILE_ROOT']='/profiles'
 Asset=Path('/cache/godot/Godot_v4.7.1-stable_linux.x86_64')
 Provenance=Path('/cache/godot/provenance.json');assert Asset.is_file() and Provenance.is_file()
 Command=[sys.executable,Runtime/'RunNativeSanitizers.py','--godot',Host['Executable'],'--host-manifest','/work/godot-host/sanitizer-host.json','--extension',Build/'godot_luau.so','--build',Build,'--build-identity',Output/'build-identity.json','--probe','/work/retirement-probes/NativeSanitizerProbe.so','--loader','/work/retirement-probes/NativeSanitizerLoader','--asset-godot',Asset,'--asset-provenance',Provenance,'--revision','0119017696b60901a7f0af981387446d82833230','--output','/evidence/full-linux']
 Run(Command,'qualification',2400)
finally:StopAll()
