import ctypes,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Output=Root/'retirement/asset-binary-control';Output.mkdir(exist_ok=False)
sys.path.insert(0,str(Root/'source/tests/runtime'))
from FixtureProcesses import StartProcess,StopProcess,StopAll
ctypes.windll.kernel32.SetErrorMode(0x8003)
Import=Output/'asset-import';shutil.copytree(Root/'retirement/full-windows/native/presentation/asset-import',Import)
shutil.copy2(Import/'bundled-assets.json',Import/'bundled-assets-text.json')
Script=Import/'BundleCharacterAssets.gd'
Script.write_text(Script.read_text().replace('Name + ".tres"','Name + ".res"'))
for File in (Import/'GodotLuau/assets/avatars/r6').glob('*.remap'):
 assert File.resolve().is_relative_to(Import.resolve());File.unlink()
shutil.copy2(Root/'retirement/InspectBundledAssets.gd',Import/'InspectBundledAssets.gd')
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text());Environment=dict(os.environ,ASAN_OPTIONS='halt_on_error=1',GODOT_SILENCE_ROOT_WARNING='1')
Results=[]
try:
 for Name,Godot,Code,Timeout in [('bundle',Root/'asset-editor/Godot_v4.7.1-stable_win64.exe','BundleCharacterAssets.gd',120),('load-control',Path(Host['Executable']),'InspectBundledAssets.gd',180)]:
  Command=[str(Godot),'--headless','--disable-crash-handler','--path',str(Import),'--script','res://'+Code]
  Started=time.monotonic()
  with (Output/(Name+'.stdout.log')).open('w') as Out,(Output/(Name+'.stderr.log')).open('w') as Err:
   Child=StartProcess(Command,Out,Err,Environment)
   try:Result=Child.wait(timeout=Timeout)
   finally:StopProcess(Child)
  Results.append({'Name':Name,'Exit':Result,'Command':Command,'Seconds':time.monotonic()-Started})
  print(Name,Result,flush=True)
  assert Result==0
 Old=json.loads((Import/'bundled-assets-text.json').read_text());New=json.loads((Import/'bundled-assets.json').read_text())
 assert Old.keys()==New.keys() and all(Old[Name]['Identity']==New[Name]['Identity'] for Name in Old)
 for Name,Record in New.items():
  File=Import/Name.removeprefix('res://');File.with_suffix(File.suffix+'.remap').write_text('[remap]\npath='+json.dumps(Record['Path'])+'\n')
 (Output/'results.json').write_text(json.dumps({'GodotSHA256':hashlib.sha256(Path(Host['Executable']).read_bytes()).hexdigest(),'Results':Results,'IdentityPreserved':True},indent=2))
finally:StopAll()
