import hashlib,json,os,shlex,shutil,subprocess,sys,time
from pathlib import Path
Root=Path('/work/godot-host'); Output=Path('/evidence/symbols-3'); Output.mkdir(exist_ok=False)
Runtime=Path('/work/source/tests/runtime'); sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
def Run(Command,Name,Timeout=180,Cwd=None,Environment=None):
 with (Output/(Name+'.log')).open('w') as Log:
  Child=StartProcess([str(X) for X in Command],Log,subprocess.STDOUT,Environment or dict(os.environ))
  try: Code=Child.wait(timeout=Timeout)
  finally: StopProcess(Child)
 print(Name,Code,flush=True)
 if Code: print((Output/(Name+'.log')).read_text(errors='replace')[-2500:],flush=True)
 return Code
try:
 assert Run(['apt-get','install','--no-install-recommends','-y','gdb','pkg-config','lld-19'],'apt-gdb')==0
 Wheels=list(Path('/retained/LinuxWork').glob('*.whl'))+list(Path('/retained').glob('*.whl'))
 print('wheels',Wheels,flush=True)
 Environment=dict(os.environ)
 Wheel=next(P for P in Wheels if P.name.lower().startswith('scons'))
 assert hashlib.sha256(Wheel.read_bytes()).hexdigest()=='df6f86828035a5c03abce64d4cf2f9c5cbd0051b58af498016bc58bfc05559b0'
 Environment['PYTHONPATH']=str(Wheel)
 Host=json.loads((Root/'sanitizer-host.json').read_text())
 Original=Path(Host['Executable']); Backup=Output/'original-host'
 shutil.copy2(Original,Backup)
 # Generate a link command from the existing cache, retain function symbols by
 # removing only the linker's -s. No engine source or compile flags change.
 Original.unlink()
 Previous=Path.cwd(); os.chdir(Root)
 try:
  assert Run([*Host['Command'],'--dry-run','verbose=yes'],'dry-link',180,Environment=Environment)==0
  Lines=(Output/'dry-link.log').read_text().splitlines()
  Link=next(Line for Line in reversed(Lines) if 'clang++-19 ' in Line and ' -o bin/godot.' in Line)
  Command=shlex.split(Link)
  Command=[Part for Part in Command if Part!='-s']
  (Output/'link-command.json').write_text(json.dumps(Command,indent=2))
  assert Run(Command,'link-symbols',180)==0
  Symbolized=Output/'godot-symbols'; shutil.copy2(Original,Symbolized)
 finally:
  shutil.copy2(Backup,Original);os.chdir(Previous)
 assert Run([sys.executable,Runtime/'DiagnoseSanitizerUnload.py','--godot',Symbolized,'--project','/evidence/linux-2/production/production','--output',Output/'production-gdb'],'production-gdb',120)==0
 (Output/'identity.json').write_text(json.dumps({'Scope':'Diagnostic relink preserving symbol table; same existing objects and ASan/LSan, no engine source edits','OriginalHostSHA256':hashlib.sha256(Backup.read_bytes()).hexdigest(),'DiagnosticHostSHA256':hashlib.sha256(Symbolized.read_bytes()).hexdigest(),'LinkCommand':Command,'CompilerSHA256':Host['CompilerSHA256']},indent=2))
finally: StopAll()
