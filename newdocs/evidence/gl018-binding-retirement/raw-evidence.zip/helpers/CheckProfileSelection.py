import importlib.util,json,os
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement/profile-selection');Root.mkdir(exist_ok=False)
Spec=importlib.util.spec_from_file_location('CandidateProfiles',Root.parent/'CandidateFixtureProcesses.py');Module=importlib.util.module_from_spec(Spec);Spec.loader.exec_module(Module)
os.environ.pop('GL_QUALIFICATION_PROFILE_ROOT',None)
Default=Module.GetProfileFolder(Root/'Default','APPDATA');assert Default==Root/'Default/profile/APPDATA'
def Reject(Project):
 try: Module.GetProfileFolder(Project,'APPDATA')
 except FileExistsError:return True
 raise AssertionError('Stale profile was admitted')
assert Reject(Root/'Default')
Selected=Root/'Selected';os.environ['GL_QUALIFICATION_PROFILE_ROOT']=str(Selected)
A=Module.GetProfileFolder(Root/'A','APPDATA');B=Module.GetProfileFolder(Root/'B','APPDATA')
assert A!=B and A.is_relative_to(Selected) and B.is_relative_to(Selected)
assert Reject(Root/'A')
Module.GetProfileFolder(Root/'A','');Module.GetProfileFolder(Root/'A','')
Record={'DefaultLayoutPreserved':True,'IndependentProjectsIsolated':True,'StaleNamedProfilesRejected':True,'EmptyBaseLookupIdempotent':True,'Scope':'Harness directory controls only; filesystem authority remains native'}
(Root/'results.json').write_text(json.dumps(Record,indent=2));print(Record,flush=True)
