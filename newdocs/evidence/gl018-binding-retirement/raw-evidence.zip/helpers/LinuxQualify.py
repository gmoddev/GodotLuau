import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
Root=Path('/work'); Runtime=Root/'source/tests/runtime'
for File in Path('/evidence/current-runtime').iterdir(): shutil.copy2(File,Runtime/File.name)
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess
def Hash(File): return hashlib.sha256(Path(File).read_bytes()).hexdigest()
Environment=dict(os.environ,PYTHONPATH='/evidence/scons')
LogRoot=Path('/evidence/linux-host-finalize'); LogRoot.mkdir(exist_ok=False)
def Run(Command,Name,Timeout):
 with (LogRoot/(Name+'.log')).open('w') as Log:
  Child=StartProcess([str(Value) for Value in Command],Log,subprocess.STDOUT,Environment)
  try: Code=Child.wait(timeout=Timeout)
  finally: StopProcess(Child)
 print('[Runtime:SanitizerSetup] '+Name+' exit='+str(Code),flush=True)
 if Code: print((LogRoot/(Name+'.log')).read_text(errors='replace')[-6000:],flush=True)
 assert Code==0
Run([sys.executable,Runtime/'BuildSanitizedGodot.py','--output',Root/'godot-host','--archive','/evidence/godot-source.tar.gz','--jobs','2'],'manifest',7400)
# Preserve reusable exact binaries/compilation evidence without writing the shared cache.
Build=Root/'build-asan'; Build.mkdir(exist_ok=False)
Identity=json.loads(Path('/work/products/linux-asan/identity.json').read_text())
for Name,Digest in Identity['Products'].items():
 File=Path('/cache/build-asan')/Name
 assert Hash(File)==Digest
 shutil.copy2(File,Build/Name)
for Name in ['CMakeCache.txt','compile_commands.json','CTestTestfile.cmake']:
 shutil.copy2(Path('/cache/build-asan')/Name,Build/Name)
Identity['CompilerSHA256']=Hash(shutil.which('clang++-19'))
Identity['CompileCommandsSHA256']=Hash(Build/'compile_commands.json')
Identity['Reuse']='Exact current main C651 native products from GL-020 Clang19 full instrumented build; every binary rehashed against preserved original source/product manifest. No fresh extension compilation claimed.'
IdentityFile=Build/'build-identity.json'; IdentityFile.write_text(json.dumps(Identity,indent=2))
Run(['cmake','-S','/evidence/probe-source','-B',Root/'probes','-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_COMPILER=clang++-19','-DGL_GDEXTENSION_HEADER_ROOT=/cache/source/godot-cpp/gdextension'],'configure-probes',120)
Run(['cmake','--build',Root/'probes','--parallel','2'],'build-probes',180)
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
Run([sys.executable,Runtime/'RunNativeSanitizers.py','--godot',Host['Executable'],'--host-manifest',Root/'godot-host/sanitizer-host.json','--extension',Build/'godot_luau.so','--build',Build,'--build-identity',IdentityFile,'--probe',Root/'probes/NativeSanitizerProbe.so','--loader',Root/'probes/NativeSanitizerLoader','--asset-godot','/cache/godot/Godot_v4.7.1-stable_linux.x86_64','--asset-provenance','/cache/godot/provenance.json','--revision','a8245bffa77cd835360502a559bea740ecc42edf','--output','/evidence/linux-full-first'],'qualification',2400)
