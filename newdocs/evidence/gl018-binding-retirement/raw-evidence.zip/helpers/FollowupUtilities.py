import json, os, shutil, subprocess, sys
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); Runtime=Root/'source/tests/runtime'
sys.path.insert(0,str(Runtime))
from RunQualification import Prepare
from FixtureProcesses import StartProcess, StopProcess
Output=Root/'followup/windows-utilities-loaded'; Prepare(Output,Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/godot_luau.dll'))
shutil.copy2(Runtime/'InspectHttpUtilities.gd',Output/'InspectHttpUtilities.gd')
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
Environment=dict(os.environ,ASAN_OPTIONS='halt_on_error=1:log_path="'+(Output/'asan-report').as_posix()+'"')
with (Output/'stdout.log').open('w') as Out, (Output/'stderr.log').open('w') as Err:
 Child=StartProcess([Host['Executable'],'--headless','--disable-crash-handler','--single-threaded-scene','--path',str(Output),'--script','res://InspectHttpUtilities.gd'],Out,Err,Environment)
 try: Code=Child.wait(timeout=30)
 finally: StopProcess(Child)
print('exit='+str(Code)); print((Output/'stdout.log').read_text())
