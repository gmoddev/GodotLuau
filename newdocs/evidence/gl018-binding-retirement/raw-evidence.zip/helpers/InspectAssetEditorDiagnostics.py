from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement/full-linux-binary/native')
for Name in ['presentation/asset-import/stderr.log','performance/asset-import/stderr.log']:
 File=Root/Name
 print(Name+'\n'+File.read_text(errors='replace')[-2000:],flush=True)
