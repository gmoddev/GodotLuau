import json,shutil,subprocess
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
Work=Root/'LinuxWork'
Work.mkdir(exist_ok=False)
shutil.copy2(Root/'godot-source.tar.gz',Work/'godot-source.tar.gz')
shutil.copy2('C:/Sandbox/Codex/GL018StartingSource.zip',Work/'starting-source.zip')
shutil.copytree(Root/'scons-4.10.0',Work/'scons')
Image=json.loads((Root/'tooling-identity.json').read_text())['ExistingContainerImage']
subprocess.run(['docker','stop','--timeout','15','codex-character-linux'],check=True,timeout=30)
Command=['docker','create','--name','codex-gl018-linux','--cpus','2','--memory','6g','--pids-limit','512','--label','codex.project=godotluau','--label','codex.task=gl018','--mount','type=bind,src='+str(Work)+',dst=/work','--mount','type=volume,src=codex-character-qualification-linux-v1,dst=/cache,readonly',Image,'/bin/sh','-c','exec sleep 21600']
subprocess.run(Command,check=True,timeout=30)
subprocess.run(['docker','start','codex-gl018-linux'],check=True,timeout=30)
Probe="import json,shutil; from pathlib import Path; print(json.dumps({'Tools':{Name:shutil.which(Name) for Name in ['clang++-19','pkg-config','ld.lld-19']},'FreeGiB':shutil.disk_usage('/work').free//1024**3,'CachedASanProducts':[P.name for P in Path('/cache/animation-security/products-candidate-1/asan').iterdir()]}))"
subprocess.run(['docker','exec','codex-gl018-linux','python3','-c',Probe],check=True,timeout=30)
(Root/'linux-container-identity.json').write_text(json.dumps({'Image':Image,'Container':'codex-gl018-linux','Work':str(Work),'CpuLimit':2,'MemoryGiB':6,'CacheReadOnly':True,'OriginalContainerRestoredStopped':True},indent=2))
