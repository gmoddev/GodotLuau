import os,re,subprocess,sys
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
Compiler=Path(re.search(r'CMAKE_CXX_COMPILER:FILEPATH=(.+)',Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/CMakeCache.txt').read_text())[1])
Batch=Root/'FinalizeEnvironment.cmd'; Batch.write_text('@echo off\ncall "'+str(Compiler.parents[6]/'Auxiliary/Build/vcvars64.bat')+'" >nul\nset\n')
for Line in subprocess.check_output(['cmd','/d','/c',str(Batch)],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Name,Value=Line.split('=',1); os.environ[Name]=Value
os.environ['PYTHONPATH']=str(Root/'scons-4.10.0')
subprocess.run([sys.executable,str(Root/'source/tests/runtime/BuildSanitizedGodot.py'),'--output',str(Root/'godot-host'),'--archive',str(Root/'godot-source.tar.gz'),'--jobs','2'],check=True,timeout=7400)
