import hashlib,json,os,subprocess,sys
from pathlib import Path
sys.path.insert(0,'/work/source/tests/runtime')
from FixtureProcesses import StartProcess,StopProcess
Root=Path('/evidence/linux-stock-loader-first'); Root.mkdir(exist_ok=False)
Engine=Path('/cache/godot/Godot_v4.7.1-stable_linux.x86_64')
Library=Path('/work/products/linux-asan/godot_luau.so')
ASan=Path(subprocess.check_output(['clang++-19','-print-file-name=libclang_rt.asan-x86_64.so'],text=True,timeout=15).strip())
assert ASan.is_file()
Environment=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:log_path='+str(Root/'asan-report'))
Command=[sys.executable,'/work/source/tests/runtime/RunQualification.py','--godot',str(Engine),'--extension',str(Library),'--output',str(Root/'load'),'--load-only','--asan-runtime',str(ASan),'--timeout','30']
with (Root/'runner.log').open('w') as Log:
 Child=StartProcess(Command,Log,subprocess.STDOUT,Environment)
 try: Code=Child.wait(timeout=60)
 finally: StopProcess(Child)
Reports='\n'.join(File.read_text(errors='replace') for File in Root.rglob('*') if File.is_file() and File.name.startswith('asan-report'))
Result={'Exit':Code,'RTLD_DEEPBIND_Reproduced':Code!=0 and 'RTLD_DEEPBIND' in Reports,'EngineSHA256':hashlib.sha256(Engine.read_bytes()).hexdigest(),'ExtensionSHA256':hashlib.sha256(Library.read_bytes()).hexdigest(),'Runtime':str(ASan),'RuntimeSHA256':hashlib.sha256(ASan.read_bytes()).hexdigest(),'Command':Command,'ASAN_OPTIONS':Environment['ASAN_OPTIONS']}
(Root/'result.json').write_text(json.dumps(Result,indent=2)); print(json.dumps(Result),flush=True)
