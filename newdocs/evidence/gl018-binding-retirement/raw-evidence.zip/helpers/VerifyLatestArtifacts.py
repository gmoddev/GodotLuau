import hashlib,json,sys,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Output=Root/'retirement';sys.path.insert(0,str(Root/'source/tests/runtime'))
from CheckCoreCI import CheckDiscovery,CheckReport
Metadata=json.loads((Output/'LatestArtifactMetadata.json').read_text());Records=[]
def Digest(Data):return hashlib.sha256(Data).hexdigest()
for Meta in Metadata:
 File=Output/('ci-'+str(Meta['ArtifactID'])+'.zip');assert Digest(File.read_bytes())==Meta['SHA256']
 with zipfile.ZipFile(File) as Zip:
  Names={Name.replace('\\','/'):Name for Name in Zip.namelist()}
  def Read(Name):return Zip.read(Names[Name.replace('\\','/')])
  Record=dict(Meta)
  if Meta['Name'].startswith('runtime-core-'):
   Directory=Output/('verified-'+str(Meta['ArtifactID']));Directory.mkdir(exist_ok=True)
   for Suffix in ['discovery.json','core-results.xml']:
    Name=next(Name for Name in Names if Name.endswith('/'+Suffix) or Name==Suffix);(Directory/Suffix).write_bytes(Read(Name))
   CheckDiscovery(Directory/'discovery.json');CheckReport(Directory/'core-results.xml');Record.update(CoreCases=80,CompleteReportVerified=True)
  else:
   Sanitized='sanitizers' in Meta['Name']
   if Sanitized:
    Name=next(Name for Name in Names if Name.endswith('sanitizer-summary.json'));Prefix=Name.removesuffix('sanitizer-summary.json');Summary=json.loads(Read(Name))
    for Relative,Hash in Summary['Files'].items():assert Digest(Read(Prefix+Relative))==Hash,Relative
    Inputs=json.loads(Read(Prefix+'inputs.json'));assert Inputs['Revision']==Meta['Revision'];assert Inputs['NativeSource']['SHA256']=='2706e1685bdf0207e55eacc2f877e4578a3164603ea5861c183009348c7d1bc8'
    Host=Inputs['Host'];assert Host['QualificationPatch']['SHA256LF']=='adfde942eb64b8f99e5a4dab4075678e201693cf3069a01675697c64b49b3fa1'
    CommandName=next(N for N in Names if N.endswith('native/compile_commands.json'))
    Commands=json.loads(Read(CommandName));assert len(Commands)==Inputs['InstrumentedFiles'] and all('fsanitize=address' in C.get('command',' '.join(C.get('arguments',[]))) for C in Commands)
    Build=json.loads(Read(next(N for N in Names if N.endswith('build-identity.json'))));assert Build['CompilerSHA256']==Host['CompilerSHA256'] and Build['Source']==Inputs['NativeSource'] and Build['CompileCommandsSHA256']==Digest(Read(CommandName))
    HarnessZip='harness011.zip' if Meta['Revision'].startswith('0119017') else 'harness-final.zip'
    CheckoutConversions=[]
    with zipfile.ZipFile(Output/HarnessZip) as Source:
     for Name,Hash in Inputs['Harness'].items():
      Data=Source.read('tests/runtime/'+Name.replace('\\','/')).replace(b'\r\n',b'\n')
      if Digest(Data)!=Hash:
       assert 'Windows' in Meta['Name'] and Digest(Data.replace(b'\n',b'\r\n'))==Hash,Name
       CheckoutConversions.append(Name)
    Record.update(Result=Summary['Result'],FullQualification=Summary['FullQualification'],VerifiedReportHashes=len(Summary['Files']),UnexpectedReports=Summary['UnexpectedReports'],FailedGates=[R['Label'] for R in Summary['Results'] if not R['Passed']],HostSHA256=Inputs['GodotSHA256'],ReportedExtensionSHA256=Inputs['ExtensionSHA256'],InstrumentedFiles=Inputs['InstrumentedFiles'],WindowsCRLFCheckoutInputs=CheckoutConversions,Controls=[R for R in Summary['Results'] if R['Label'] in ['host-uaf','host-leak','minimal-reload','production-registration','production-vm-reload']])
    AnimationNames=[N for N in Names if N.startswith(Prefix+'native/animation/') and '/animation-authority-' in N and N.endswith('.json')]
    Animation=[json.loads(Read(N)) for N in AnimationNames]
    Record['AnimationEvidence']={'Actors':len(Animation),'CompletePassingActors':sum(A['Complete'] and A['Result']=='PASS' and all(X['Passed'] for X in A['Assertions']) for A in Animation),'Cases':sum(len(A['Cases']) for A in Animation),'Assertions':sum(len(A['Assertions']) for A in Animation)}
    if Meta['Revision'].startswith('92659b'):
     assert len(Animation)==10 and Record['AnimationEvidence']['CompletePassingActors']==10 and Record['AnimationEvidence']['Cases']==510
    if Summary['FullQualification']:
     Directory=Output/('verified-'+str(Meta['ArtifactID']));Directory.mkdir(exist_ok=True)
     for Suffix in ['discovery.json','core-results.xml']:(Directory/Suffix).write_bytes(Read(Prefix+'core/'+Suffix))
     CheckDiscovery(Directory/'discovery.json');CheckReport(Directory/'core-results.xml');Record['CoreCases']=80
    Candidates=[N for N in Names if N==Prefix+'native/summary.json']
   else:Candidates=[N for N in Names if N.endswith('native-ci/summary.json')]
   if Candidates:
    Name=Candidates[0];Prefix=Name.removesuffix('summary.json');Native=json.loads(Read(Name));assert Native['Revision']==Meta['Revision'] and Native['Processes']==110
    assert Native['NativeSource']['SHA256']=='2706e1685bdf0207e55eacc2f877e4578a3164603ea5861c183009348c7d1bc8'
    assert sum(len(V) for V in Native['Groups'].values())==110 and all(A['Exit']==0 for G in Native['Groups'].values() for A in G)
    for Relative,Hash in Native['LogHashes'].items():assert Digest(Read(Prefix+Relative))==Hash
    HarnessZip='harness011.zip' if Meta['Revision'].startswith('0119017') else 'harness-final.zip'
    with zipfile.ZipFile(Output/HarnessZip) as Source:
     Harness={N.removeprefix('tests/runtime/'):Digest(Source.read(N).replace(b'\r\n',b'\n')) for N in Source.namelist() if not N.endswith('/')}
    for Name,Hash in Native['HarnessHashes'].items():assert Harness[Name.replace('\\','/')]==Hash,Name
    Actors=Native['AnimationAuthority'];assert len(Actors)==10 and all(A['Complete'] and A['Result']=='PASS' and all(X['Passed'] for X in A['Assertions']) for A in Actors)
    Cases=sum(len(A['Cases']) for A in Actors);assert Cases==510
    Record.update(NativeActors=110,AnimationActors=10,AuthorityCases=Cases,AnimationAssertions=sum(len(A['Assertions']) for A in Actors),VerifiedNativeLogHashes=len(Native['LogHashes']),VerifiedHarnessInputs=len(Native['HarnessHashes']),ReportedExtensionSHA256=Native['ExtensionSHA256'],ReportedCompanionSHA256=Native['DataStoreWorkerSHA256'])
  Records.append(Record)
(Output/'latest-ci-verified.json').write_text(json.dumps(Records,indent=2))
for R in Records:print(R['ArtifactID'],R['Name'],R.get('Result','PASS'),R.get('CoreCases'),R.get('NativeActors'),R.get('FailedGates'))
