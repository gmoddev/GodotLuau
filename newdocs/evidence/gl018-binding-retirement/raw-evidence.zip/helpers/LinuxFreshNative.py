import hashlib,json,os,subprocess,sys,time
from pathlib import Path
Root=Path('/work'); Source=Root/'source'; Driver=Path('/cache/source')
sys.path.insert(0,str(Source/'tests/runtime'))
from FixtureProcesses import StartProcess,StopProcess
from SourceFingerprint import GetFingerprint
Logs=Path('/evidence/linux-native-fresh'); Logs.mkdir(exist_ok=False)
Build=Root/'fresh-asan'
def Hash(File): return hashlib.sha256(Path(File).read_bytes()).hexdigest()
def Normal(File): return hashlib.sha256(Path(File).read_bytes().replace(b'\r\n',b'\n')).hexdigest()
for Name in ['tests/runtime/CMakeLists.txt','tests/runtime/ExecutionDomainTests.cpp','tests/runtime/DatastoreBackendProbe.cpp','src/persistence/worker_main.cpp']:
 assert Normal(Driver/Name)==Normal(Source/Name),Name
Identity={'Source':GetFingerprint(Source),'CompilerSHA256':Hash('/usr/bin/clang++-19'),'DriverInputsMatchFrozenSource':True,'Commands':[]}
def Run(Command,Name,Timeout):
 Code=None
 with (Logs/(Name+'.log')).open('w') as Log:
  Child=StartProcess([str(Value) for Value in Command],Log,subprocess.STDOUT,dict(os.environ))
  try: Code=Child.wait(timeout=Timeout)
  finally: StopProcess(Child)
 Identity['Commands'].append({'Command':[str(Value) for Value in Command],'Exit':Code,'LogSHA256':Hash(Logs/(Name+'.log'))})
 (Logs/'identity.json').write_text(json.dumps(Identity,indent=2))
 print('[Runtime:NativeBuild] '+Name+' exit='+str(Code),flush=True)
 if Code: print((Logs/(Name+'.log')).read_text(errors='replace')[-6000:],flush=True)
 assert Code==0
Run(['cmake','-S',Driver/'tests/runtime','-B',Build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DGL_SOURCE_ROOT='+str(Source),'-DGL_BUILD_GODOT_ADAPTER=ON','-DCMAKE_CXX_COMPILER=clang++-19','-DCMAKE_C_COMPILER=clang-19','-DCMAKE_CXX_FLAGS=-fsanitize=address -fno-omit-frame-pointer','-DCMAKE_C_FLAGS=-fsanitize=address -fno-omit-frame-pointer','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address','-DCMAKE_SHARED_LINKER_FLAGS=-fsanitize=address','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],'configure',300)
Run(['cmake','--build',Build,'--target','GodotLuauAdapter','ExecutionDomainTests','DatastoreBackendProbe','--parallel','2'],'build',3600)
Identity['Products']={Name:Hash(Build/Name) for Name in ['godot_luau.so','godot_luau_store_worker','ExecutionDomainTests','DatastoreBackendProbe']}
Identity['CompileCommandsSHA256']=Hash(Build/'compile_commands.json')
(Build/'build-identity.json').write_text(json.dumps(Identity,indent=2))
Path('/evidence/linux-native-products').mkdir(exist_ok=False)
import shutil
for Name in [*Identity['Products'],'build-identity.json','compile_commands.json','CMakeCache.txt']:
 shutil.copy2(Build/Name,Path('/evidence/linux-native-products')/Name)
