import hashlib,json,re,shutil,struct,subprocess,tarfile
from pathlib import Path
Output=Path('/evidence/historical-leak-symbols-v3');Output.mkdir(exist_ok=False)
def Hash(File):
 with Path(File).open('rb') as Data:return hashlib.file_digest(Data,'sha256').hexdigest()
Candidates=list(Path('/evidence/symbols-3').glob('st*'))
Recovered=next(P for P in Candidates if Hash(P)=='d02ad8a32227f82d54c7713d66f26863f0cd34afe26436e815c54dca59bfe187')
Symbols=Output/'godot-symbols-recovered';shutil.copy2(Recovered,Symbols)
Original=Path('/evidence/symbols-3/original-host')
if Hash(Original)!='bbfe7aabcd410ea9493eb9dec7ce9ffe74bf26803926be9072f0ef3d89692409':
 Original=Output/'original-host'
 with tarfile.open('/retained/LinuxWork/linux-build-cache.tar.gz') as Tar:
  Member=next(M for M in Tar if M.name.endswith('/bin/godot.linuxbsd.template_debug.dev.x86_64.llvm.san'))
  with Tar.extractfile(Member) as Source,Original.open('wb') as Target:shutil.copyfileobj(Source,Target)
assert Hash(Original)=='bbfe7aabcd410ea9493eb9dec7ce9ffe74bf26803926be9072f0ef3d89692409'
def TextSection(File):
 with File.open('rb') as Data:
  Header=struct.unpack('<16sHHIQQQIHHHHHH',Data.read(64));assert Header[0][:6]==b'\x7fELF\x02\x01'
  Data.seek(Header[6]);Sections=[struct.unpack('<IIQQQQIIQQ',Data.read(Header[11])) for _ in range(Header[12])]
  Names=Sections[Header[13]];Data.seek(Names[4]);Names=Data.read(Names[5])
  Text=next(S for S in Sections if Names[S[0]:].split(b'\0',1)[0]==b'.text')
  Data.seek(Text[4]);Remaining=Text[5];Digest=hashlib.sha256()
  while Remaining:
   Block=Data.read(min(Remaining,1024*1024));assert Block;Digest.update(Block);Remaining-=len(Block)
  return {'Address':Text[3],'Bytes':Text[5],'SHA256':Digest.hexdigest()}
Sections={Name:TextSection(File) for Name,File in [('Original',Original),('Symbols',Symbols)]};assert Sections['Original']==Sections['Symbols']
Report=Path('/retained/LinuxWork/linux-full-fresh/suite-performance/asan-report.5926').read_text()
Offsets=list(dict.fromkeys(re.findall(r'godot\.linuxbsd[^\n]*?\+(0x[0-9a-f]+)\)',Report)))
Result=subprocess.run(['addr2line','-C','-f','-e',str(Symbols),*Offsets],capture_output=True,text=True,timeout=30);assert Result.returncode==0,Result.stderr
(Output/'host-symbols.txt').write_text(Result.stdout)
(Output/'verification.json').write_text(json.dumps({'OriginalSHA256':Hash(Original),'SymbolizedSHA256':Hash(Symbols),'MatchingTextSections':Sections,'Offsets':Offsets,'Scope':'Function-only symbolization of retained report, not a fresh reproduction. Prior objcopy timed out and damaged the diagnostic copy; exact original symbol binary recovered from its retained temporary backup. Read-only ELF section parsing used here.'},indent=2))
print(Result.stdout[:6500],flush=True)
