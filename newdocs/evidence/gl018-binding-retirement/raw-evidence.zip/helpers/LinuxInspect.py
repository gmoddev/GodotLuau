import json,shutil,subprocess
from pathlib import Path
Cache=Path('/cache/build-asan')
for Line in (Cache/'CMakeCache.txt').read_text().splitlines():
 if any(Line.startswith(Prefix) for Prefix in ['CMAKE_CXX_COMPILER:','GL_SOURCE_ROOT:','CMAKE_HOME_DIRECTORY:','CMAKE_CXX_FLAGS:','GL_BUILD_GODOT_ADAPTER:']): print(Line)
print((Cache/'CTestTestfile.cmake').read_text())
print(Path('/work/products/linux-asan/identity.json').read_text())
print(json.dumps({'CompileCommands':len(json.loads((Cache/'compile_commands.json').read_text())),'Rg':shutil.which('rg')}))
Engine=Path('/work/godot-host')
if shutil.which('rg'):
 print(subprocess.check_output(['rg','-n','-B','4','-A','4','RTLD_DEEPBIND',str(Engine)],text=True,timeout=20))
else:
 for File in Engine.rglob('*.cpp'):
  Text=File.read_text(errors='replace')
  if 'RTLD_DEEPBIND' in Text:
   Lines=Text.splitlines()
   for Index,Line in enumerate(Lines):
    if 'RTLD_DEEPBIND' in Line: print(str(File)+'\n'+'\n'.join(Lines[max(0,Index-5):Index+5]))
