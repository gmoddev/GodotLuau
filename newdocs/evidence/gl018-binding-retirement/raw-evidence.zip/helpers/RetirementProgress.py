import json,shutil,subprocess
from pathlib import Path
Command=['powershell.exe','-NoProfile','-Command','Get-Process link,cl,python -ErrorAction SilentlyContinue | Select-Object Name,Id,CPU,WorkingSet64 | ConvertTo-Json -Compress']
print(subprocess.run(Command,capture_output=True,text=True,timeout=20).stdout,flush=True)
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
for File in ['retirement/host-windows-resume/build.log','retirement/host-windows-resume/result.json']:
 P=Root/File
 if P.exists():print(File+'\n'+'\n'.join(P.read_text(errors='replace').splitlines()[-8:]),flush=True)
print('Capacity',[(Drive,shutil.disk_usage(Drive).free) for Drive in ['C:/','E:/']],flush=True)
Command=['powershell.exe','-NoProfile','-Command',"Get-CimInstance Win32_Process -Filter \"Name = 'python.exe'\" | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"]
print(subprocess.run(Command,capture_output=True,text=True,timeout=20).stdout,flush=True)
for File in ['retirement/verified-host-windows.log','retirement/full-windows.log','godot-host/sanitizer-host.json']:
 P=Root/File
 if P.exists():print(File,P.stat().st_size,P.stat().st_mtime,flush=True)
