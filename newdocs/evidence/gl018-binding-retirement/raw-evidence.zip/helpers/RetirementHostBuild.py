import ctypes,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
Windows=os.name=='nt'
Base=Path('E:/Sandbox/Codex/NativeSanitizers') if Windows else Path('/retained')
Root=Base/'godot-host' if Windows else Path('/work/godot-host')
Output=(Base/'retirement' if Windows else Path('/evidence'))/('host-windows' if Windows else 'host-linux-2')
Output.mkdir(exist_ok=False)
Runtime=Base/'source/tests/runtime' if Windows else Path('/work/source/tests/runtime')
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
def Hash(File): return hashlib.sha256(Path(File).read_bytes()).hexdigest()
if Windows:
 ctypes.windll.kernel32.SetErrorMode(0x8003)
 for Line in subprocess.check_output(['cmd','/d','/c',str(Base/'QualificationEnvironment.cmd')],text=True,timeout=30).splitlines():
  if '=' in Line and not Line.startswith('='):
   Key,Value=Line.split('=',1); os.environ[Key]=Value
else: os.environ['PYTHONPATH']=str(Base/'scons-4.10.0-py3-none-any.whl')
Patch=Base/'retirement/GodotBindingRetirement.patch' if Windows else Path('/evidence/GodotBindingRetirement.patch')
Host=json.loads((Root/'sanitizer-host.json').read_text())
Source=Root/'core/extension/gdextension.cpp'; Binary=Path(Host['Executable'])
assert Hash(Source)=='a7f2f64bd1b05461f430ab499a5d2e4d87913179b2cbca223b9aa90a9c7a1d8b'
shutil.copy2(Source,Output/'original-gdextension.cpp')
shutil.copy2(Binary,Output/Binary.name)
shutil.copy2(Root/'sanitizer-host.json',Output/'original-host.json')
if Windows:
 for File in Binary.parent.glob('*.pdb'): shutil.copy2(File,Output/File.name)
Record={'OriginalSourceSHA256':Hash(Source),'OriginalHostSHA256':Hash(Binary),'PatchSHA256':Hash(Patch),'Commands':[]}
Previous=Path.cwd();os.chdir(Root)
try:
 for Name,Command,Timeout in [('check-patch',['git','apply','--check',str(Patch)],30),('apply-patch',['git','apply',str(Patch)],30),('build',[sys.executable,*Host['Command'][1:]],1800)]:
  with (Output/(Name+'.log')).open('w') as Log:
   Child=StartProcess(Command,Log,subprocess.STDOUT,dict(os.environ))
   if Windows: ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(int(Child._handle)),0x4000)
   try: Code=Child.wait(timeout=Timeout)
   finally: StopProcess(Child)
  Record['Commands'].append({'Command':Command,'Exit':Code,'LogSHA256':Hash(Output/(Name+'.log'))})
  (Output/'result.json').write_text(json.dumps(Record,indent=2))
  print(Name,Code,flush=True)
  if Code: print((Output/(Name+'.log')).read_text(errors='replace')[-4000:],flush=True);sys.exit(Code)
 Record.update(PatchedSourceSHA256=Hash(Source),PatchedHostSHA256=Hash(Binary))
 (Output/'result.json').write_text(json.dumps(Record,indent=2))
 print('PATCHED',Record['PatchedSourceSHA256'],Record['PatchedHostSHA256'],flush=True)
finally: os.chdir(Previous);StopAll()
