import ctypes,json,os,subprocess,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Runtime=Root/'source/tests/runtime';Output=Root/'retirement/increment-attempts';Output.mkdir(exist_ok=False)
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StopAll
import RunQualification as Runner
ctypes.windll.kernel32.SetErrorMode(0x8003)
for Line in subprocess.check_output(['cmd','/d','/c',str(Root/'QualificationEnvironment.cmd')],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Key,Value=Line.split('=',1);os.environ[Key]=Value
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text());Extension=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/godot_luau.dll')
Project=Output/'project';Runner.Prepare(Project,Extension)
Source=(Runtime/'DatastoreTransactions.gd').read_text()
Original="for I=1,20 do Store:IncrementAsync('Counter') end; game:SetAttribute('Done',true)"
Wrapped="""local Update=Store.UpdateAsync; Store.UpdateAsync=function(Self,Key,Transform)
local Calls=0; local OK,Value=pcall(Update,Self,Key,function(Old)
Calls+=1; print('[Persistence:Attempt] ROLE attempt='..Calls..' old='..tostring(Old)); return Transform(Old) end)
print('[Persistence:Attempt] ROLE complete='..tostring(OK)..' attempts='..Calls..' value='..tostring(Value))
if not OK then error(Value) end; return Value end; for I=1,20 do Store:IncrementAsync('Counter') end; game:SetAttribute('Done',true)""".replace('\n',' ')
assert Original in Source
Environment=dict(os.environ,ASAN_OPTIONS='halt_on_error=1')
Environment['PATH']=str(Path(Host['Executable']).parent)+os.pathsep+Environment['PATH']
try:
 # Same original production increment method and transaction limits. The sole
 # intervention wraps transform calls with diagnostic output; timing is altered.
 for Role in ['seed','A','B','verify']:
  Text=Source if Role in ['seed','verify'] else Source.replace(Original,Wrapped.replace('ROLE',Role))
  (Project/('Trace-'+Role+'.gd')).write_text(Text)
 for Name in ['APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME']:
  Folder=Output/'profile'/Name;Folder.mkdir(parents=True);Environment[Name]=str(Folder)
 def Start(Mode,Role):return Runner.Start(Host['Executable'],Project,'Trace-'+Role+'.gd',Role,['--mode',Mode,'--role',Role,'--expected','40'],Environment)
 Runner.Check(Start('seed','seed'),time.monotonic()+60,Project,'seed','[Persistence:Transactions] PASS seed')
 Entries=[(Role,Start('increment',Role)) for Role in ['A','B']];Results=[]
 for Role,Child in Entries:
  try:Result=Runner.Check(Child,time.monotonic()+60,Project,Role,'[Persistence:Transactions] PASS increment');Results.append(Result)
  except Exception as Error:Results.append({'Role':Role,'Error':str(Error)})
 try:Results.append(Runner.Check(Start('verify','verify'),time.monotonic()+60,Project,'verify','[Persistence:Transactions] PASS verify'))
 except Exception as Error:Results.append({'Role':'verify','Error':str(Error)})
 (Output/'results.json').write_text(json.dumps(Results,indent=2));print(json.dumps(Results),flush=True)
finally:StopAll()
