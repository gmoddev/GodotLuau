import subprocess
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
subprocess.run(['docker','volume','create','--label','codex.task=gl018','codex-gl018-followup-evidence'],check=True,timeout=20)
subprocess.run(['docker','run','--detach','--name','codex-gl018-followup','--cpus','2','--memory','8g','--pids-limit','512','--label','codex.task=gl018','--tmpfs','/work:rw,exec,size=5g','--mount','type=volume,source=codex-gl018-followup-evidence,target=/qualification','--mount','type=bind,source='+str(Root)+',target=/retained,readonly','--mount','type=volume,source=codex-character-qualification-linux-v1,target=/cache,readonly','sha256:4eeae307153445eff9e085c872580bc65ee05b43d80c9561ddd3e9a20d269f2d','sleep','21600'],check=True,timeout=40)
subprocess.run(['docker','exec','codex-gl018-followup','stat','-f','-c','%T %t','/qualification'],check=True,timeout=20)
subprocess.run(['docker','exec','codex-gl018-followup','tar','-xzf','/retained/LinuxWork/linux-build-cache.tar.gz','-C','/work'],check=True,timeout=180)
subprocess.run(['docker','exec','codex-gl018-followup','ls','/work'],check=True,timeout=20)
