"""Retain Docker without retaining the task's SSH kill-on-close dependency."""
import ctypes,json,os,subprocess,sys
from ctypes import wintypes
from pathlib import Path
ctypes.windll.kernel32.SetErrorMode(0x8003)
Kernel=ctypes.WinDLL('kernel32',use_last_error=True);Native=ctypes.WinDLL('ntdll')
Kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];Kernel.OpenProcess.restype=wintypes.HANDLE
Kernel.GetCurrentProcess.restype=wintypes.HANDLE
Kernel.DuplicateHandle.argtypes=[wintypes.HANDLE,wintypes.HANDLE,wintypes.HANDLE,ctypes.POINTER(wintypes.HANDLE),wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
Kernel.QueryInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD,ctypes.c_void_p]
Kernel.SetInformationJobObject.argtypes=Kernel.QueryInformationJobObject.argtypes[:4]
Kernel.CloseHandle.argtypes=[wintypes.HANDLE]
Native.NtQueryInformationProcess.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.ULONG,ctypes.POINTER(wintypes.ULONG)]
class Entry(ctypes.Structure):
 _fields_=[('Handle',ctypes.c_size_t),('Handles',ctypes.c_size_t),('Pointers',ctypes.c_size_t),('Access',wintypes.ULONG),('Type',wintypes.ULONG),('Flags',wintypes.ULONG),('Reserved',wintypes.ULONG)]
class Pids(ctypes.Structure):
 _fields_=[('Assigned',wintypes.DWORD),('Count',wintypes.DWORD),('Values',ctypes.c_size_t*1024)]
Processes=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command','Get-CimInstance Win32_Process | Select-Object Name,ProcessId,ParentProcessId | ConvertTo-Json -Compress'],text=True,timeout=30))
ById={P['ProcessId']:P for P in Processes};Ancestors=[];Parent=os.getppid()
while Parent in ById and ById[Parent]['Name'].lower()!='sshd.exe':
 Ancestors.append(Parent);Parent=ById[Parent]['ParentProcessId']
Current=Pids();assert Kernel.QueryInformationJobObject(None,3,ctypes.byref(Current),ctypes.sizeof(Current),None)
Expected=set(Current.Values[:Current.Count]);assert os.getpid() in Expected
Docker=[P['ProcessId'] for P in Processes if P['Name']=='com.docker.backend.exe' and P['ProcessId'] in Expected];assert Docker
Records=[];Applied=False
for Parent in Ancestors:
 Process=Kernel.OpenProcess(0x440,False,Parent)
 if not Process:continue
 try:
  Buffer=ctypes.create_string_buffer(1024*1024);Size=wintypes.ULONG()
  Status=Native.NtQueryInformationProcess(Process,51,Buffer,len(Buffer),ctypes.byref(Size));assert Status==0,Status
  Count=ctypes.c_size_t.from_buffer(Buffer).value;assert 16+Count*ctypes.sizeof(Entry)<=len(Buffer)
  for Index in range(Count):
   Handle=Entry.from_buffer(Buffer,16+Index*ctypes.sizeof(Entry)).Handle;Copy=wintypes.HANDLE()
   if not Kernel.DuplicateHandle(Process,Handle,Kernel.GetCurrentProcess(),ctypes.byref(Copy),0,False,2):continue
   try:
    Members=Pids()
    if not Kernel.QueryInformationJobObject(Copy,3,ctypes.byref(Members),ctypes.sizeof(Members),None):continue
    if set(Members.Values[:Members.Count])!=Expected:continue
    Limits=ctypes.create_string_buffer(144);assert Kernel.QueryInformationJobObject(Copy,9,Limits,len(Limits),None)
    Before=bytes(Limits);Flags=wintypes.DWORD.from_buffer(Limits,16);Original=Flags.value
    if '--apply' in sys.argv and not Applied:
     Flags.value=Original & ~0x2000
     assert Kernel.SetInformationJobObject(Copy,9,Limits,len(Limits)),ctypes.get_last_error()
     After=ctypes.create_string_buffer(144);assert Kernel.QueryInformationJobObject(Copy,9,After,len(After),None)
     assert wintypes.DWORD.from_buffer(After,16).value==Flags.value
     Applied=True
    Records.append({'OwnerPID':Parent,'JobMemberPIDs':sorted(Expected),'DockerBackendPIDs':Docker,'BeforeFlags':Original,'AfterFlags':Flags.value,'Applied':Applied})
   finally:Kernel.CloseHandle(Copy)
 finally:Kernel.CloseHandle(Process)
assert Records,'No matching task SSH job handle found'
Output=Path('E:/Sandbox/Codex/NativeSanitizers/retirement')/('docker-job-lifetime-applied.json' if '--apply' in sys.argv else 'docker-job-lifetime-control.json')
Output.write_text(json.dumps(Records,indent=2));print(json.dumps(Records),flush=True)
