import json,shutil,subprocess
from pathlib import Path
for Root in [Path('/evidence/symbols-3'),Path('/work/leak-symbol-check'),Path('/work/leak-symbol-check-v2')]:
 print(str(Root),[(P.name,P.stat().st_size) for P in Root.iterdir() if P.is_file()],flush=True)
print(shutil.disk_usage('/work'),flush=True)
for File in [Path('/evidence/symbols-3/original-host'),Path('/evidence/symbols-3/godot-symbols')]:
 Result=subprocess.run(['readelf','-h',str(File)],capture_output=True,text=True,timeout=15)
 print(File.name,Result.returncode,Result.stdout[:600],Result.stderr[:600],flush=True)
