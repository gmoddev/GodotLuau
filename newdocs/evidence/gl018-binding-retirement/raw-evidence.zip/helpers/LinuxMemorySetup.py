import json,subprocess,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/LinuxWork')
Old=json.loads(subprocess.check_output(['docker','inspect','codex-gl018-linux'],timeout=15))[0]
assert Old['Config']['Labels']['codex.task']=='gl018'
assert Old['State']['Running']
(Root/'linux-host-first/interrupted.json').write_text(json.dumps({'Reason':'Interrupted task-owned source extraction on slow Windows bind mount; no compiler or native test had started','TimeUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'Replacement':'codex-gl018-ram: /work tmpfs 5GiB; memory cap8GiB; CPU2; preserved bind evidence'},indent=2))
subprocess.run(['docker','stop','-t','3','codex-gl018-linux'],check=True,timeout=15)
Image='sha256:4eeae307153445eff9e085c872580bc65ee05b43d80c9561ddd3e9a20d269f2d'
Command=['docker','run','--detach','--name','codex-gl018-ram','--cpus','2','--memory','8g','--pids-limit','512','--label','codex.project=godotluau','--label','codex.task=gl018','--tmpfs','/work:rw,exec,size=5g','--mount','type=bind,source='+str(Root)+',target=/evidence','--mount','type=volume,source=codex-character-qualification-linux-v1,target=/cache,readonly',Image,'sleep','21600']
subprocess.run(Command,check=True,timeout=30)
subprocess.run(['docker','cp',str(Root/'scons'),'codex-gl018-ram:/work/scons'],check=True,timeout=30)
subprocess.run(['docker','cp','C:/Sandbox/Codex/GL018LinuxHost.py','codex-gl018-ram:/work/LinuxHost.py'],check=True,timeout=30)
