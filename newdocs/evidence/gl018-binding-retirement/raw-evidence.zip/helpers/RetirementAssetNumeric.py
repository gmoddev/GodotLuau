import ctypes,json,os,subprocess,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Output=Root/'retirement/asset-binary-control';sys.path.insert(0,str(Root/'source/tests/runtime'))
from FixtureProcesses import StartProcess,StopProcess,StopAll
ctypes.windll.kernel32.SetErrorMode(0x8003)
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text());Command=[Host['Executable'],'--headless','--disable-crash-handler','--path',str(Output/'asset-import'),'--script','res://InspectBundledAssetsNumeric.gd']
Started=time.monotonic()
try:
 with (Output/'numeric.stdout.log').open('w') as Out,(Output/'numeric.stderr.log').open('w') as Err:
  Child=StartProcess(Command,Out,Err,dict(os.environ,ASAN_OPTIONS='halt_on_error=1'))
  try:Code=Child.wait(timeout=180)
  finally:StopProcess(Child)
 Record={'Exit':Code,'Seconds':time.monotonic()-Started,'Command':Command}
 (Output/'numeric-result.json').write_text(json.dumps(Record,indent=2));print(Record,flush=True)
 assert Code==0
 Old=json.loads((Output/'asset-import/bundled-assets-text.json').read_text());New=json.loads((Output/'asset-import/bundled-assets.json').read_text());assert all(Old[N]['Identity']==New[N]['Identity'] for N in Old)
 for Name,Record in New.items():
  File=Output/'asset-import'/Name.removeprefix('res://');File.with_suffix(File.suffix+'.remap').write_text('[remap]\npath='+json.dumps(Record['Path'])+'\n')
finally:StopAll()
