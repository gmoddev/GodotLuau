from pathlib import Path
import shutil, subprocess
Root=Path('E:/Sandbox/Codex/NativeSanitizers/godot-host')
for Name,Terms in [
 ('core/extension/gdextension_manager.cpp',['Error GDExtensionManager::unload_extension','_unload_extension_internal','clear_instance_bindings']),
 ('core/extension/gdextension.cpp',['track_instance_binding','untrack_instance_binding','clear_instance_bindings','close_library']),
 ('core/extension/gdextension.h',['instance_bindings','track_instance_binding','clear_instance_bindings']),
 ('core/object/object.cpp',['void *Object::get_instance_binding','void Object::free_instance_binding','Object::~Object']),
 ('core/extension/gdextension_interface.cpp',['gdextension_object_get_instance_binding','gdextension_object_free_instance_binding'])]:
 Lines=(Root/Name).read_text().splitlines()
 for Index,Line in enumerate(Lines):
  if any(Term in Line for Term in Terms):
   print(Name+':'+str(Index+1)+'\n'+'\n'.join(Lines[max(0,Index-5):Index+65]))
Cpp=Path('C:/Sandbox/Codex/Workspaces/GodotLuau/godot-cpp')
for Name,Terms in [('src/godot.cpp',['deinitialize_level']),('src/core/object.cpp',['get_object_instance_binding','instance_binding_callbacks','free_callback']),('include/godot_cpp/classes/wrapped.hpp',['_free_callback','_gde_binding'])]:
 File=Cpp/Name
 if not File.exists(): continue
 Lines=File.read_text().splitlines()
 for Index,Line in enumerate(Lines):
  if any(Term in Line for Term in Terms): print(Name+':'+str(Index+1)+'\n'+'\n'.join(Lines[max(0,Index-3):Index+45]))
print('Capacity',[(Name,shutil.disk_usage(Name).free) for Name in ['C:/','E:/']])
