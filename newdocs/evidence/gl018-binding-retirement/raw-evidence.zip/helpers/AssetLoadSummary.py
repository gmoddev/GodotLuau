import json,statistics
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement/asset-binary-control');Data=json.loads((Root/'asset-import/load-measurements-numeric.json').read_text())
Records={}
for Variant in ['Text','Binary']:
 Trials=[sum(R['Microseconds'] for R in Data if R['Trial']==Trial and R['Variant']==Variant)/1000 for Trial in range(3)]
 Records[Variant]={'TrialTotalMilliseconds':Trials,'MedianMilliseconds':statistics.median(Trials),'AssetBytes':sum(R['Bytes'] for R in Data if R['Trial']==0 and R['Variant']==Variant)}
Records['Scope']='Three interleaved pairs, six original meshes per trial; matching corrected ASan host, no extension; load only, identity hashing excluded'
(Root/'load-summary.json').write_text(json.dumps(Records,indent=2));print(Records,flush=True)
