import json, os, shutil, subprocess, sys
from pathlib import Path
Runtime=Path('/work/source/tests/runtime')
for Name in ['InvestigateSanitizerBindings.py','RunCharacterPresentation.py','RunCharacterPerformance.py']:
 shutil.copy2(Path('/retained/source/tests/runtime')/Name, Runtime/Name)
shutil.copytree('/retained/source/tests/runtime/sanitizers',Runtime/'sanitizers',dirs_exist_ok=True)
Output=Path('/qualification/followup'); Output.mkdir(exist_ok=True)
Environment=dict(os.environ, ASAN_OPTIONS='halt_on_error=1:detect_leaks=1', GODOT_SILENCE_ROOT_WARNING='1')
def Run(Command, Name, Timeout):
 with (Output/(Name+'.log')).open('w') as Log:
  Result=subprocess.run([str(X) for X in Command],stdout=Log,stderr=subprocess.STDOUT,env=Environment,timeout=Timeout)
 print(Name+' exit='+str(Result.returncode),flush=True)
 if Result.returncode: print((Output/(Name+'.log')).read_text(errors='replace')[-3000:],flush=True)
 return Result.returncode
Run(['cmake','-S',Runtime/'sanitizers','-B',Output/'probes','-G','Ninja','-DCMAKE_CXX_COMPILER=clang++-19','-DCMAKE_BUILD_TYPE=Debug','-DGL_GDEXTENSION_HEADER_ROOT=/cache/source/godot-cpp/gdextension'],'configure-probes',120)
assert Run(['cmake','--build',Output/'probes','--parallel','2'],'build-probes',120)==0
Host=json.loads(Path('/work/godot-host/sanitizer-host.json').read_text())
Run([sys.executable,Runtime/'InvestigateSanitizerBindings.py','--godot',Host['Executable'],'--probe',Output/'probes/NativeSanitizerProbe.so','--output',Output/'bindings'],'bindings',180)
Run([sys.executable,Runtime/'RunCharacterPresentation.py','--godot',Host['Executable'],'--asset-godot','/cache/godot/Godot_v4.7.1-stable_linux.x86_64','--extension','/work/fresh-asan/godot_luau.so','--output',Output/'presentation'],'presentation',360)
