from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement/windows-o1-2')
for File in [Root/'core/ctest.log',Root/'native/Testing/Temporary/LastTest.log']:
 if File.exists():print(str(File)+'\n'+'\n'.join(File.read_text(errors='replace').splitlines()[-45:]),flush=True)
for File in (Root/'core').rglob('*.log'):
 if File.name=='ctest.log':continue
 Text=File.read_text(errors='replace')
 if 'FAIL' in Text or 'ERROR' in Text:print(str(File)+'\n'+Text[-3000:],flush=True)
