from pathlib import Path
Root=Path('/qualification/followup/presentation')
for Name in ['asset-import/GodotLuau/assets/avatars/r6/Rig1_diff.png.import','asset-import/runtime-remaps.json']:
 print(Name+'\n'+(Root/Name).read_text())
print('Imported '+str([F.name for F in (Root/'r6/.godot/imported').iterdir()]))
File=Path('/work/godot-host/scene/resources/compressed_texture.cpp')
Lines=File.read_text().splitlines()
for Index,Line in enumerate(Lines):
 if 'get_recognized_extensions' in Line or 'handles_type' in Line: print('\n'.join(Lines[Index:Index+16]))
print((Root/'r6/presentation-r6-single0.stderr.log').read_text()[:4000])
