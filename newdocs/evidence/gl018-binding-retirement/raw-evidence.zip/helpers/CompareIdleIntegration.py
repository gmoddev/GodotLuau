import hashlib,json,os,shutil,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Runtime=Root/'source/tests/runtime';sys.path.insert(0,str(Runtime))
from RunQualification import Prepare,Start,Check
from FixtureProcesses import StopAll
Output=Root/'followup/idle-integration-comparison';Output.mkdir(exist_ok=False)
Deadline=time.monotonic()+900
while True:
 File=Root/'followup/windows-idle-followup/results.json'
 if File.exists() and len(json.loads(File.read_text()))==4: break
 if time.monotonic()>Deadline: raise TimeoutError('Idle groups not complete; comparison not started')
 time.sleep(5)
Baseline=Output/'baseline-product';Baseline.mkdir()
for Name in ['godot_luau.dll','godot_luau_store_worker.exe']:
 shutil.copy2(Root/'followup/windows-candidate-build'/('baseline-'+Name),Baseline/Name)
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
Results=[]
try:
 for Index,Variant in enumerate(['Baseline','Candidate','Candidate','Baseline']):
  Directory=Output/(str(Index)+'-'+Variant)
  Extension=Baseline/'godot_luau.dll' if Variant=='Baseline' else Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/godot_luau.dll')
  Prepare(Directory,Extension)
  Environment=dict(os.environ,ASAN_OPTIONS='halt_on_error=1:log_path="'+(Directory/'asan-report').as_posix()+'"')
  for Name in ['APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME']:
   Profile=Directory/'profile'/Name;Profile.mkdir(parents=True);Environment[Name]=str(Profile)
  Actor=Start(Path(Host['Executable']),Directory,'Integration.gd','integration',[],Environment)
  Started=time.monotonic();Error=None
  try: Check(Actor,time.monotonic()+60,Directory,'integration','[Runtime:Integration] PASS')
  except RuntimeError as Failure: Error=str(Failure)
  Results.append({'Variant':Variant,'Trial':Index,'ExtensionSHA256':hashlib.sha256(Extension.read_bytes()).hexdigest(),'GodotSHA256':Host['ExecutableSHA256'],'Exit':Actor.returncode,'Passed':Error is None,'Seconds':time.monotonic()-Started,'Error':Error})
  (Output/'results.json').write_text(json.dumps(Results,indent=2))
  print('[Runtime:IntegrationComparison]',Variant,'exit=',Actor.returncode,flush=True)
finally:StopAll()
