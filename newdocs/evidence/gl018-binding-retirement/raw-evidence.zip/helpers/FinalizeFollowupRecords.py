import hashlib,json,shutil,sys,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Followup=Root/'followup';sys.path.insert(0,str(Root/'source/tests/runtime'))
from CheckCoreCI import CheckDiscovery,CheckReport
Core=Followup/'windows-candidate-full/core'
CheckDiscovery(Core/'discovery.json');CheckReport(Core/'core-results.xml')
Source=json.loads((Followup/'windows-candidate-build/build-identity.json').read_text())
Baseline=json.loads((Followup/'windows-full/inputs.json').read_text())
Comparison=json.loads((Followup/'idle-integration-comparison/results.json').read_text())
for Item in Comparison:
 assert Item['ExtensionSHA256']==(Baseline['ExtensionSHA256'] if Item['Variant']=='Baseline' else Source['Products']['godot_luau.dll'])
 assert Item['GodotSHA256']==Baseline['GodotSHA256']
assert len(Comparison)==4 and all(not Item['Passed'] and 'Resume deadline exceeded' in Item['Error'] for Item in Comparison)
Native=json.loads((Followup/'windows-candidate-full/sanitizer-summary.json').read_text())
Records={
 'Source':Source,'WindowsCandidateResult':Native['Result'],'WindowsCandidateCoreCases':80,'WindowsCandidateCoreComplete':True,
 'WindowsCandidateResults':[{K:Item[K] for K in ['Label','Exit','Passed','TimedOut','ElapsedSeconds']} for Item in Native['Results']],
 'UnexpectedReports':Native['UnexpectedReports'],'IdleFollowup':json.loads((Followup/'windows-idle-followup/results.json').read_text()),
 'Comparison':[{K:Item[K] for K in ['Variant','Trial','ExtensionSHA256','GodotSHA256','Exit','Passed','Seconds']} for Item in Comparison],
 'ComparisonFinding':'Both baseline and candidate reproduce the Identity resume-budget failure in two trials each; no candidate-exclusive cause established',
 'PresentationRecords':[],'FreeC':shutil.disk_usage('C:/').free}
for File in sorted((Followup/'windows-candidate-full/native/presentation').glob('*/evidence-*.json')):
 Value=json.loads(File.read_text());Records['PresentationRecords'].append({'File':str(File.relative_to(Followup)),'Result':Value['Result'],'Graphical':Value['Graphical'],'Checks':Value['Checks']})
Failed=Followup/'failed-native-13116608407.zip';Digest=hashlib.sha256(Failed.read_bytes()).hexdigest();assert Digest=='fe6cd9549a0b28fd6d80312aac352f0d0a5dee4627f7eb5113286e4e696647c0'
with zipfile.ZipFile(Failed) as Zip:
 Names={Name.replace('\\','/'):Name for Name in Zip.namelist()}
 Name=next(Name for Name in Names if Name.endswith('native-ci/regression/results.json'))
 Actors=json.loads(Zip.read(Names[Name]));assert len(Actors)==8 and all(Item['Exit']==0 for Item in Actors)
 Records['FailedNativeLinuxArtifact']={'ArtifactID':13116608407,'SHA256':Digest,'RecordedRegressionActors':8,'RequiredGateFailure':'security-Dedicated-server positive state delivery deadline','Complete110ActorEvidence':False}
(Followup/'final-local-results.json').write_text(json.dumps(Records,indent=2))
print(json.dumps({'WindowsCore':80,'FullResult':Native['Result'],'PresentationRecords':Records['PresentationRecords'],'Idle':[{K:Item[K] for K in ['Group','Exit']} for Item in Records['IdleFollowup']],'Comparison':Records['ComparisonFinding']}),flush=True)
