import json
from pathlib import Path
Commands=json.loads(Path('/work/build-asan/compile_commands.json').read_text())
Missing=[Item for Item in Commands if 'fsanitize=address' not in Item.get('command',' '.join(Item.get('arguments',[])))]
print(json.dumps({'Total':len(Commands),'Missing':len(Missing),'Examples':Missing[:3]},indent=2))
for Group in ['godot-cpp','luau','src/core','worker_main','ExecutionDomainTests']:
 Items=[Item for Item in Commands if Group in Item['file']]
 print(json.dumps({'Group':Group,'Total':len(Items),'Instrumented':sum('fsanitize=address' in Item.get('command','') for Item in Items),'Example':Items[:1]}))
