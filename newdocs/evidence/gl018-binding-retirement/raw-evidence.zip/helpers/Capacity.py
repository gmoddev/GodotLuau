import importlib.util,json,subprocess
from pathlib import Path
for Query in ["Get-CimInstance Win32_LogicalDisk | Select-Object DeviceID,DriveType,FileSystem,FreeSpace,Size | ConvertTo-Json -Compress","Get-ChildItem -LiteralPath C:/Users/host/AppData/Local/Docker/wsl -Recurse -Filter *.vhdx -ErrorAction SilentlyContinue | Select-Object FullName,Length | ConvertTo-Json -Compress"]:
 Result=subprocess.run(['powershell.exe','-NoProfile','-Command',Query],capture_output=True,text=True,timeout=30)
 print(Result.stdout.strip(),flush=True)
print('InstalledSCons:',importlib.util.find_spec('SCons'),flush=True)
Root=Path('C:/Sandbox/Codex')
print('RelevantRoots:',[Item.name for Item in Root.iterdir() if Item.is_dir() and any(Text in Item.name.lower() for Text in ['release','godot','qualification','native'])],flush=True)
