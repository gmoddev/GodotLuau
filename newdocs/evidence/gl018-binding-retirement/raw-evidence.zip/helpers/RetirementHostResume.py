import ctypes,hashlib,json,os,subprocess,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); HostRoot=Root/'godot-host'; Output=Root/'retirement/host-windows-resume';Output.mkdir(exist_ok=False)
sys.path.insert(0,str(Root/'source/tests/runtime'))
from FixtureProcesses import StartProcess,StopProcess,StopAll
ctypes.windll.kernel32.SetErrorMode(0x8003)
for Line in subprocess.check_output(['cmd','/d','/c',str(Root/'QualificationEnvironment.cmd')],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Key,Value=Line.split('=',1);os.environ[Key]=Value
os.environ['PYTHONPATH']=str(Root/'scons-4.10.0-py3-none-any.whl')
Host=json.loads((HostRoot/'sanitizer-host.json').read_text()); os.chdir(HostRoot)
def Hash(File):return hashlib.sha256(Path(File).read_bytes()).hexdigest()
print('PatchedSource',Hash(HostRoot/'core/extension/gdextension.cpp'),flush=True)
Command=[sys.executable,*Host['Command'][1:]]
try:
 with (Output/'build.log').open('w') as Log:
  Child=StartProcess(Command,Log,subprocess.STDOUT,dict(os.environ))
  ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(int(Child._handle)),0x4000)
  try:Code=Child.wait(timeout=1800)
  finally:StopProcess(Child)
 Record={'Exit':Code,'Command':Command,'PatchedSourceSHA256':Hash(HostRoot/'core/extension/gdextension.cpp'),'HostSHA256':Hash(Host['Executable']),'LogSHA256':Hash(Output/'build.log')}
 (Output/'result.json').write_text(json.dumps(Record,indent=2))
 print(Record,flush=True)
 if Code:print((Output/'build.log').read_text(errors='replace')[-5000:],flush=True)
finally:StopAll()
