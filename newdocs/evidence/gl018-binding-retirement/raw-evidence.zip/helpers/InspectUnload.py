from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/godot-host')
for Name,Terms in [('core/object/object.cpp',['Object::~Object()']),('core/extension/gdextension.cpp',['_track_instance_binding','_untrack_instance_binding','clear_instance_bindings']),('core/extension/gdextension_manager.cpp',['unload_extension(', 'clear_instance_bindings'])]:
 Lines=(Root/Name).read_text().splitlines()
 for Index,Line in enumerate(Lines):
  if any(Term in Line for Term in Terms):
   print(Name+':'+str(Index+1)+'\n'+'\n'.join(Lines[max(0,Index-2):Index+40]))
