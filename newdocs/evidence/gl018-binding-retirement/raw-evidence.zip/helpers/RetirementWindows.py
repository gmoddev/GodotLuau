import ctypes,json,os,subprocess,sys
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); Output=Root/'retirement/windows-classes'; Output.mkdir(exist_ok=False)
Runtime=Root/'source/tests/runtime'; sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
ctypes.windll.kernel32.SetErrorMode(0x8003)
for Line in subprocess.check_output(['cmd','/d','/c',str(Root/'QualificationEnvironment.cmd')],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Key,Value=Line.split('=',1); os.environ[Key]=Value
os.environ['PATH']='C:/Sandbox/Codex/Tools/cmake-3.31.10/cmake-3.31.10-windows-x86_64/bin'+os.pathsep+os.environ['PATH']
try:
 for Name,Command,Timeout in [
 ('configure',['cmake','-S',str(Runtime/'sanitizers'),'-B',str(Output/'probes'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DGL_GDEXTENSION_HEADER_ROOT=C:/Sandbox/Codex/Workspaces/GodotLuau/godot-cpp/gdextension'],120),
 ('build',['cmake','--build',str(Output/'probes'),'--parallel','2'],180)]:
  with (Output/(Name+'.log')).open('w') as Log:
   Child=StartProcess(Command,Log,subprocess.STDOUT,dict(os.environ))
   try: Code=Child.wait(timeout=Timeout)
   finally: StopProcess(Child)
  print(Name,Code,flush=True)
  if Code: print((Output/(Name+'.log')).read_text()[-4000:]);sys.exit(Code)
 Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
 Command=[sys.executable,str(Runtime/'InvestigateProductionBindings.py'),'--godot',Host['Executable'],'--extension','C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/godot_luau.dll','--trace',str(Output/'probes/NativeBindingTrace.dll'),'--output',str(Output/'production')]
 with (Output/'investigation.log').open('w') as Log:
  Child=StartProcess(Command,Log,subprocess.STDOUT,dict(os.environ))
  try: Code=Child.wait(timeout=420)
  finally: StopProcess(Child)
 print('investigation',Code,flush=True)
 print((Output/'investigation.log').read_text()[-3000:],flush=True)
finally: StopAll()
