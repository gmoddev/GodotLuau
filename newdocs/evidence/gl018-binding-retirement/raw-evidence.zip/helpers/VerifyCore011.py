import hashlib,json,sys,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); Output=Root/'retirement';sys.path.insert(0,str(Root/'source/tests/runtime'))
from CheckCoreCI import CheckDiscovery,CheckReport
Records=[]
for Identity,Digest in [(13119980192,'41c6935d83924d4853e217f544b2bcc44db7e88388cd1ea82891a2aed107002b'),(13119503414,'83c4109811799d95f5709f4223aa7f23955f8984436959c358205d68103edc55')]:
 File=Output/('core011-'+str(Identity)+'.zip'); assert hashlib.sha256(File.read_bytes()).hexdigest()==Digest
 Directory=Output/('core-'+str(Identity));Directory.mkdir(exist_ok=False)
 with zipfile.ZipFile(File) as Zip:
  for Suffix in ['discovery.json','core-results.xml']:
   Name=next(Name for Name in Zip.namelist() if Name.endswith('/'+Suffix) or Name==Suffix)
   (Directory/Suffix).write_bytes(Zip.read(Name))
 CheckDiscovery(Directory/'discovery.json');CheckReport(Directory/'core-results.xml')
 Records.append({'ArtifactID':Identity,'SHA256':Digest,'Revision':'0119017696b60901a7f0af981387446d82833230','Cases':80,'CompleteReportVerified':True})
(Output/'core-ci-verified.json').write_text(json.dumps(Records,indent=2));print(Records,flush=True)
