import json
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement');Records=json.loads((Root/'linux-diagnostics-review.json').read_text())
for Record in Records:
 Messages=[M for M in Record['Messages'] if not (('RPC ' in M and 'is not allowed' in M) or 'LocalScript no puede acceder' in M)]
 if Messages:print(Record['File'],sorted(set(Messages)),flush=True)
