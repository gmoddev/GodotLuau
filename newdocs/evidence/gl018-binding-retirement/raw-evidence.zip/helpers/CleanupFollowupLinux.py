import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/followup')
Verified=0
for Name,Suffix in [('windows-bindings-get-api','.dll'),('linux-salvage/followup/bindings-get-api','.so')]:
 Directory=Root/Name;Record=json.loads((Directory/'binding-investigation.json').read_text())
 for Relative,Digest in Record['Files'].items():
  assert hashlib.sha256((Directory/Relative).read_bytes()).hexdigest()==Digest,Relative;Verified+=1
 for Mode in ['clean','binding-clean','binding']:
  assert hashlib.sha256((Directory/Mode/('NativeSanitizerProbe'+Suffix)).read_bytes()).hexdigest()==Record['ProbeSHA256']
  Verified+=1
assert (Root/'linux-salvage/followup/gdb/production.log').is_file()
assert (Root/'linux-salvage/followup/gdb/binding.log').is_file()
Archive=json.loads((Root/'followup-partial.json').read_text())
assert hashlib.sha256(Path(Archive['Archive']).read_bytes()).hexdigest()==Archive['SHA256']
with zipfile.ZipFile(Archive['Archive']) as Zip:
 Manifest=json.loads(Zip.read('manifest.json'))
 for Name,Record in Manifest['Files'].items():
  if '/linux-salvage/' in Name: assert hashlib.sha256(Zip.read(Name)).hexdigest()==Record['SHA256']
Container='codex-gl018-followup';Volume='codex-gl018-followup-evidence'
Info=json.loads(subprocess.check_output(['docker','inspect',Container],timeout=20))[0]
assert Info['Id']=='d166b24e02b75fc33b759128cdf4cabfec1266aa98f7f345888826458fa2b071'
assert Info['Config']['Labels']['codex.task']=='gl018' and not Info['State']['Running']
VolumeInfo=json.loads(subprocess.check_output(['docker','volume','inspect',Volume],timeout=20))[0]
assert VolumeInfo['Labels']['codex.task']=='gl018'
subprocess.run(['docker','rm',Container],check=True,timeout=30)
subprocess.run(['docker','volume','rm',Volume],check=True,timeout=30)
Status=json.loads(subprocess.check_output(['docker','inspect','drycreek-bot','directus-db','codex-character-linux'],timeout=20))
Record={'ContainerRemoved':Container,'VolumeRemoved':Volume,'PreservedEvidence':str(Root/'linux-salvage'),'VerifiedBindingFilesAndProducts':Verified,'RecoveredArchiveSHA256':Archive['SHA256'],'PriorRunningContainers':{Item['Name']:Item['State']['Status'] for Item in Status},'FreeC':shutil.disk_usage('C:/').free,'CacheJunctionPreserved':Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/godot-cpp').is_junction()}
assert Record['PriorRunningContainers']['/drycreek-bot']=='running' and Record['PriorRunningContainers']['/directus-db']=='running' and Record['PriorRunningContainers']['/codex-character-linux']=='exited'
(Root/'linux-cleanup.json').write_text(json.dumps(Record,indent=2));print(json.dumps(Record),flush=True)
