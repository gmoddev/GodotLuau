import json, os, re, subprocess, sys
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
Build=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan')
Compiler=Path(re.search(r'CMAKE_CXX_COMPILER:FILEPATH=(.+)',(Build/'CMakeCache.txt').read_text())[1])
Batch=Root/'QualificationEnvironment.cmd'
for Line in subprocess.check_output(['cmd','/d','/c',str(Batch)],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Name,Value=Line.split('=',1); os.environ[Name]=Value
os.environ['PATH']='C:/Sandbox/Codex/Tools/cmake-3.31.10/cmake-3.31.10-windows-x86_64/bin'+os.pathsep+os.environ['PATH']
Output=Root/'followup'; Output.mkdir(exist_ok=True)
with (Output/'windows-probe-build.log').open('w') as Log:
 for Command in [['cmake','-S',str(Root/'source/tests/runtime/sanitizers'),'-B',str(Output/'windows-probes'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DGL_GDEXTENSION_HEADER_ROOT=C:/Sandbox/Codex/Workspaces/GodotLuau/godot-cpp/gdextension'],['cmake','--build',str(Output/'windows-probes'),'--parallel','2']]:
  subprocess.run(Command,stdout=Log,stderr=subprocess.STDOUT,check=True,timeout=180)
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
subprocess.run([sys.executable,str(Root/'source/tests/runtime/InvestigateSanitizerBindings.py'),'--godot',Host['Executable'],'--probe',str(Output/'windows-probes/NativeSanitizerProbe.dll'),'--output',str(Output/'windows-bindings')],check=True,timeout=180)
