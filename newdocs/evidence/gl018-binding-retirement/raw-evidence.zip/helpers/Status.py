import json,subprocess
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
for Name,LogName in [('windows-host-compatible-first','build.log')]:
 File=Root/Name/LogName
 if File.exists(): print(json.dumps({'Profile':Name,'Tail':File.read_text(errors='replace').splitlines()[-5:]}),flush=True)
for Name in ['build.log','tools-install.log','tools-update.log']:
 File=Root/'LinuxWork/linux-host-first'/Name
 if File.exists(): print(json.dumps({'Profile':'linux-host-first','Log':Name,'Tail':File.read_text(errors='replace').splitlines()[-4:]}),flush=True)
print(json.dumps({'FreeC_GiB':__import__('shutil').disk_usage('C:/').free//1024**3,'FreeE_GiB':__import__('shutil').disk_usage(Root).free//1024**3}),flush=True)
