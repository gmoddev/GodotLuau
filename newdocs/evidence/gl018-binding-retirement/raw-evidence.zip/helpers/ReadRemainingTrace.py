from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement')
for File in sorted((Root/'presentation-lifetime').glob('*.log')):
 Lines=File.read_text(errors='replace').splitlines()
 Relevant=[Line for Line in Lines if any(Term in Line for Term in ['LifetimeTrace','FAIL','ERROR','disconnected','connected','zero channels'])]
 if Relevant:print(File.name+'\n'+'\n'.join(Relevant[-18:]),flush=True)
for File in sorted((Root/'performance-trace').glob('*.log')):
 Lines=File.read_text(errors='replace').splitlines()
 print(File.name+'\n'+'\n'.join(Lines[-12:]),flush=True)
Log=Root/'linux-candidate-build/qualification.log'
if Log.exists():print('Linux full\n'+'\n'.join(Log.read_text(errors='replace').splitlines()[-10:]),flush=True)
