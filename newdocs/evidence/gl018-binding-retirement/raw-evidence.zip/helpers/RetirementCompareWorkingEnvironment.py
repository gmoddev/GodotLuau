import ctypes,json,os,subprocess,sys,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Output=Root/'retirement/working-comparison-env';Output.mkdir(exist_ok=False);Runtime=Root/'source/tests/runtime'
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
ctypes.windll.kernel32.SetErrorMode(0x8003)
for Line in subprocess.check_output(['cmd','/d','/c',str(Root/'QualificationEnvironment.cmd')],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Key,Value=Line.split('=',1);os.environ[Key]=Value
Environment=dict(os.environ,ASAN_OPTIONS='halt_on_error=1',GL_QUALIFICATION_PROFILE_ROOT='C:/Sandbox/Codex/Gl018Profiles',PYTHONPATH=str(Runtime))
def Run(Command,Name,Timeout):
 with (Output/(Name+'.stdout.log')).open('w') as Out,(Output/(Name+'.stderr.log')).open('w') as Err:
  Child=StartProcess([str(X) for X in Command],Out,Err,Environment)
  try:Code=Child.wait(timeout=Timeout)
  finally:StopProcess(Child)
 print(Name,Code,flush=True)
 return Code
try:
 Run([sys.executable,Root/'retirement/RunCoreTests-local-working.py','--binary',Root/'retirement/windows-o1-2/native/ExecutionDomainTests.exe','--output',Output/'core-o1'],'core-o1',120)
 Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
 for Variant,Extension in [('O0',Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan/godot_luau.dll')),('O1',Root/'retirement/windows-o1-2/native/godot_luau.dll')]:
  for Group,Flag in [('http','--http'),('httpservice','--httpservice'),('datastore','--datastore')]:
   Run([sys.executable,Runtime/'RunQualification.py','--godot',Host['Executable'],'--extension',Extension,'--output',Output/(Variant+'-'+Group),'--timeout','60',Flag],Variant+'-'+Group,360)
finally:StopAll()

