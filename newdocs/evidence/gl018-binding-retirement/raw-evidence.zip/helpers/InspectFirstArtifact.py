import hashlib,zipfile
from pathlib import Path
Archive=Path('E:/Sandbox/Codex/NativeSanitizers/first-linux-ci-failure.zip')
print('ArchiveSHA256 '+hashlib.sha256(Archive.read_bytes()).hexdigest())
with zipfile.ZipFile(Archive) as Zip:
 for Name in Zip.namelist():
  print(Name)
  if Name.endswith('build.log'): print(Zip.read(Name).decode(errors='replace')[-6000:])
