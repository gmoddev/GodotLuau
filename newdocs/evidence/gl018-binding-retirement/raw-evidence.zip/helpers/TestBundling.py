from pathlib import Path
import os, subprocess, sys
Runtime=Path('/work/source/tests/runtime')
# Separate fresh preparation; retain the full attempt's original editor-idle timeout.
sys.path.insert(0,str(Runtime))
from RunCharacterPresentation import Assets
Output=Path('/qualification/bundling-control'); Output.mkdir()
Assets(Path('/cache/godot/Godot_v4.7.1-stable_linux.x86_64'),Path('/work/source'),Output,dict(os.environ),RuntimeRemaps=True)
print('bundling preparation done',flush=True)
