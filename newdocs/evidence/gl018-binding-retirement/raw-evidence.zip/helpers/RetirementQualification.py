import ctypes,json,os,subprocess,sys,time
from pathlib import Path
Windows=os.name=='nt'; Root=Path('E:/Sandbox/Codex/NativeSanitizers') if Windows else Path('/retained')
Runtime=Root/'source/tests/runtime' if Windows else Path('/work/source/tests/runtime')
Output=Root/'retirement' if Windows else Path('/evidence')
HostRoot=Root/'godot-host' if Windows else Path('/work/godot-host')
sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess,StopProcess,StopAll
if Windows:
 ctypes.windll.kernel32.SetErrorMode(0x8003)
 for Line in subprocess.check_output(['cmd','/d','/c',str(Root/'QualificationEnvironment.cmd')],text=True,timeout=30).splitlines():
  if '=' in Line and not Line.startswith('='):
   Name,Value=Line.split('=',1);os.environ[Name]=Value
os.environ['PYTHONPATH']=str(Root/'scons-4.10.0-py3-none-any.whl')
def Run(Command,Name,Timeout):
 with (Output/(Name+'.log')).open('w') as Log:
  Child=StartProcess([str(X) for X in Command],Log,subprocess.STDOUT,dict(os.environ))
  if Windows:ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(int(Child._handle)),0x4000)
  try:Code=Child.wait(timeout=Timeout)
  finally:StopProcess(Child)
 print(Name,Code,flush=True)
 print((Output/(Name+'.log')).read_text(errors='replace')[-3000:],flush=True)
 return Code
try:
 Archive=Root/'godot-source.tar.gz'
 if not Archive.exists(): Archive=Root/'LinuxWork/godot-source.tar.gz'
 assert Run([sys.executable,Runtime/'BuildSanitizedGodot.py','--output',HostRoot,'--archive',Archive,'--timeout','1800'],'verified-host-'+('windows' if Windows else 'linux'),2000)==0
 Host=json.loads((HostRoot/'sanitizer-host.json').read_text())
 if Windows:
  Build=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan')
  Command=[sys.executable,Runtime/'RunNativeSanitizers.py','--godot',Host['Executable'],'--host-manifest',HostRoot/'sanitizer-host.json','--extension',Build/'godot_luau.dll','--build',Build,'--build-identity',Root/'followup/windows-candidate-build/build-identity.json','--probe',Root/'retirement/windows-classes/probes/NativeSanitizerProbe.dll','--loader',Root/'retirement/windows-classes/probes/NativeSanitizerLoader.exe','--asset-godot',Root/'asset-editor/Godot_v4.7.1-stable_win64.exe','--asset-provenance',Root/'asset-editor/provenance.json','--revision','0119017696b60901a7f0af981387446d82833230','--output',Output/'full-windows']
  Run(Command,'full-windows',2400)
 else:
  Run([sys.executable,Runtime/'RunNativeSanitizers.py','--godot',Host['Executable'],'--probe','/work/retirement-probes/NativeSanitizerProbe.so','--loader','/work/retirement-probes/NativeSanitizerLoader','--revision','0119017696b60901a7f0af981387446d82833230','--controls-only','--output',Output/'verified-linux-controls'],'verified-linux-controls',180)
finally:StopAll()
