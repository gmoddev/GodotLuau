import hashlib,json,shutil,time,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
Output=Root/'collected'; Output.mkdir(exist_ok=False)
def Hash(File): return hashlib.sha256(Path(File).read_bytes()).hexdigest()
Paths=[]
Prefixes=['windows-','godot-host-attempts','products','probe-source','helpers']
for Directory in Root.iterdir():
 if Directory.is_dir() and any(Directory.name.startswith(Prefix) for Prefix in Prefixes):
  Paths.extend(File for File in Directory.rglob('*') if File.is_file() and (File.suffix in ['.log','.json','.xml','.cpp','.py','.gd','.pem'] or File.name=='CMakeLists.txt' or File.name.startswith('asan-report')))
for Directory in (Root/'LinuxWork').iterdir():
 if Directory.is_dir() and (Directory.name.startswith('linux-') or Directory.name in ['current-runtime','probe-source']):
  Paths.extend(File for File in Directory.rglob('*') if File.is_file() and (File.suffix in ['.log','.json','.xml','.cpp','.py','.gd','.pem'] or File.name=='CMakeLists.txt' or File.name.startswith('asan-report')))
Paths.extend(File for File in Root.glob('*CILog.log'))
Paths.extend(Root/Name for Name in ['cleanup.json','hosted-artifact-check-failed.json','filesystem-profile.json'] if (Root/Name).exists())
Paths.extend([Root/'godot-host/sanitizer-host.json',Root/'asset-editor/provenance.json',Root/'hosted-artifact-check.json'])
Paths.extend(File for File in (Root/'source/tests/runtime').iterdir() if File.is_file() and File.suffix in ['.py','.gd','.cpp','.pem','.json'])
Paths=sorted(set(Paths))
Archive=Root/'qualification-raw-text.zip'
Files={}
with zipfile.ZipFile(Archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as Zip:
 for File in Paths:
  Name=File.relative_to(Root).as_posix()
  Data=File.read_bytes(); Files[Name]=hashlib.sha256(Data).hexdigest(); Zip.writestr(Name,Data)
 with zipfile.ZipFile(Root/'first-linux-ci-failure.zip') as Original:
  for OriginalName in Original.namelist():
   Data=Original.read(OriginalName); Name='first-hosted-linux-failure/'+OriginalName
   Files[Name]=hashlib.sha256(Data).hexdigest(); Zip.writestr(Name,Data)
Manifest={'Schema':1,'Issue':'GL-018','Classification':'PARTIALLY QUALIFIED','Closure':'OPEN','CollectedUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'StartingMain':'83cd0887968d73d61d050650718d8ada6e124579','ImplementationRevision':'055d8f07440cbe9035937a2e8b22dba476e7356b','NativeSource':{'SHA256':'c651c1ff730bb2de8c16da996c09d2567e26d45865dfa25118df812d1f51d91f','Files':89,'Newlines':'LF normalized'},'ExecutionMachine':'DockerPC','MainPCUsed':False,'OtherWorkersUsed':False,'PublicationEnabled':False,'RuntimeSourceChanged':False,'Archive':{'Path':str(Archive),'SHA256':Hash(Archive),'Bytes':Archive.stat().st_size,'Files':len(Files)},'Files':Files}
(Output/'manifest.json').write_text(json.dumps(Manifest,indent=2))
Local=[]
for Name,Directory in [('Windows',Root/'windows-full-first'),('Linux',Root/'LinuxWork/linux-full-fresh')]:
 Summary=json.loads((Directory/'sanitizer-summary.json').read_text())
 Groups=[]
 for Record in Summary['Results']:
  if Record['Label'].startswith('suite-') and Record['Passed'] and Record['Label']!='suite-core':
   Group=Record['Label'].removeprefix('suite-')
   Actors=json.loads((Directory/'native'/Group/'results.json').read_text())
   Groups.append({'Group':Group,'Actors':len(Actors),'AllExitZero':all(Item['Exit']==0 for Item in Actors)})
 Animation=[json.loads(File.read_text()) for File in (Directory/'native/animation').rglob('animation-authority-*.json')]
 Local.append({'Platform':Name,'FullQualification':Summary['FullQualification'],'ControlsPassed':Summary['ControlsPassed'],'PassedGroups':Groups,'FullyRecordedPassingNativeActors':sum(Item['Actors'] for Item in Groups),'Core':json.loads((Directory/'core/verified.json').read_text()),'FailedObservations':[Record for Record in Summary['Results'] if not Record['Passed']],'UnexpectedReports':Summary['UnexpectedReports'],'AnimationActors':len(Animation),'AnimationChecks':sum(len(Item['Cases']) for Item in Animation),'AnimationAssertions':sum(len(Item['Assertions']) for Item in Animation),'AnimationComplete':all(Item['Complete'] and Item['Result']=='PASS' for Item in Animation)})
 for Base in ['results.json','inputs.json','sanitizer-summary.json']:
  File=Directory/Base
  if File.exists(): shutil.copy2(File,Output/(Name+'-'+Base))
 if (Directory/'core/verified.json').exists():
  Core=Output/(Name+'-core'); Core.mkdir()
  for File in (Directory/'core').iterdir():
   if File.is_file(): shutil.copy2(File,Core/File.name)
(Output/'local-results.json').write_text(json.dumps(Local,indent=2))
for Name,File in [('Windows-host.json',Root/'godot-host/sanitizer-host.json'),('Linux-host.json',Root/'LinuxWork/linux-host-product/sanitizer-host.json'),('hosted-artifact-check.json',Root/'hosted-artifact-check.json')]:
 if File.exists(): shutil.copy2(File,Output/Name)
Evidence=Output/'original-failures'; Evidence.mkdir()
for Name,Directory in [('Windows-VM-reload',Root/'windows-full-first/production-vm-reload'),('Linux-VM-reload',Root/'LinuxWork/linux-full-fresh/production-vm-reload'),('Linux-stock-loader',Root/'LinuxWork/linux-stock-loader-first')]:
 Target=Evidence/Name; Target.mkdir()
 for File in Directory.iterdir():
  if File.is_file() and (File.suffix in ['.log','.json'] or File.name.startswith('asan-report')): shutil.copy2(File,Target/File.name)
print(json.dumps({Key:Value for Key,Value in Manifest.items() if Key!='Files'},indent=2),flush=True)
