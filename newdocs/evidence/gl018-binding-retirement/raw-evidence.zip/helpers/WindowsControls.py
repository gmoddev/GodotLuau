import argparse,ctypes,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
Parser=argparse.ArgumentParser()
Parser.add_argument('--engine',type=Path,default=Path('C:/Sandbox/Codex/Tools/Godot_v4.7.1-stable_win64.exe'))
Parser.add_argument('--attempt',default='stock-first')
Args=Parser.parse_args()
Root=Path('E:/Sandbox/Codex/NativeSanitizers')
Logs=Root/('windows-controls-'+Args.attempt)
Logs.mkdir(exist_ok=False)
ctypes.windll.kernel32.SetErrorMode(0x8003)
Cache=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan')
Compiler=Path(re.search(r'CMAKE_CXX_COMPILER:FILEPATH=(.+)',(Cache/'CMakeCache.txt').read_text())[1])
Batch=Root/'ControlsEnvironment.cmd'
Batch.write_text('@echo off\ncall "'+str(Compiler.parents[6]/'Auxiliary/Build/vcvars64.bat')+'" >nul\nif errorlevel 1 exit /b 1\nset\n')
for Line in subprocess.check_output(['cmd','/d','/c',str(Batch)],text=True,timeout=30).splitlines():
 if '=' in Line and not Line.startswith('='):
  Name,Value=Line.split('=',1); os.environ[Name]=Value
Runtimes=sorted((Compiler.parents[6]/'Redist/MSVC').glob('*/debug_nonredist/x64/Microsoft.VC*.DebugCRT'))
assert Runtimes
os.environ['PATH']=str(Runtimes[-1])+os.pathsep+os.environ['PATH']
os.environ['PATH']=str(Compiler.parent)+os.pathsep+os.environ['PATH']
os.chdir(Logs)
sys.path.insert(0,str(Root/'source/tests/runtime'))
from FixtureProcesses import StartProcess,StopProcess,StopAll
CMake=Path('C:/Sandbox/Codex/Tools/cmake-3.31.10/cmake-3.31.10-windows-x86_64/bin/cmake.exe')
Records=[]
def Hash(File): return hashlib.sha256(Path(File).read_bytes()).hexdigest()
def Observe(Command,Name,Timeout=30,Extra=None):
 Environment=dict(os.environ,GODOT_SILENCE_ROOT_WARNING='1',ASAN_OPTIONS='halt_on_error=1:log_path='+Name+'-asan')
 if Extra: Environment.update(Extra)
 Code=None; TimedOut=False
 Started=time.monotonic()
 with (Logs/(Name+'.stdout.log')).open('w') as Out,(Logs/(Name+'.stderr.log')).open('w') as Err:
  Child=StartProcess([str(Value) for Value in Command],Out,Err,Environment)
  try:
   try: Code=Child.wait(timeout=Timeout)
   except subprocess.TimeoutExpired: TimedOut=True
  finally: StopProcess(Child)
 Item={'Name':Name,'Command':[str(Value) for Value in Command],'Exit':Code,'TimedOut':TimedOut,'ElapsedSeconds':time.monotonic()-Started,'Environment':{Key:Environment[Key] for Key in ['ASAN_OPTIONS','GL_NATIVE_SANITIZER_CONTROL'] if Key in Environment},'StdoutSHA256':Hash(Logs/(Name+'.stdout.log')),'StderrSHA256':Hash(Logs/(Name+'.stderr.log'))}
 Records.append(Item); (Logs/'results.json').write_text(json.dumps(Records,indent=2))
 print(json.dumps({Key:Item[Key] for Key in ['Name','Exit','TimedOut','ElapsedSeconds']}),flush=True)
 return Item
try:
 for Sanitized in [False,True]:
  Label='instrumented-loader' if Sanitized else 'plain-loader'
  Build=Root/('probes-'+Label)
  Result=Observe([CMake,'-S',Root/'probe-source','-B',Build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DGL_SANITIZE_HOST='+('ON' if Sanitized else 'OFF'),'-DGL_GDEXTENSION_HEADER_ROOT=C:/Sandbox/Codex/Workspaces/GodotLuau/godot-cpp/gdextension'],'configure-'+Label,90)
  assert Result['Exit']==0
  Result=Observe([CMake,'--build',Build,'--parallel','1'],'build-'+Label,180)
  assert Result['Exit']==0
  for File in Compiler.parent.glob('clang_rt.asan*.dll'): shutil.copy2(File,Build/File.name)
  Observe([Build/'NativeSanitizerLoader.exe',Build/'NativeSanitizerProbe.dll'],Label+'-clean')
  Observe([Build/'NativeSanitizerLoader.exe',Build/'NativeSanitizerProbe.dll'],Label+'-uaf',Extra={'GL_NATIVE_SANITIZER_CONTROL':'use-after-free'})
 for Mode,Cycles in [('engine',1),('minimal',1),('minimal',5)]:
  Label=Mode+'-'+str(Cycles)
  Project=Logs/Label; Project.mkdir()
  shutil.copy2(Root/'SanitizerLifecycle.gd',Project/'SanitizerLifecycle.gd')
  (Project/'project.godot').write_text('config_version=5\n[application]\nconfig/name="NativeSanitizerControl"\n[threading]\nworker_pool/max_threads=2\n')
  if Mode!='engine':
   shutil.copy2(Root/'probes-instrumented-loader/NativeSanitizerProbe.dll',Project/'probe.dll')
   for File in [*Compiler.parent.glob('clang_rt.asan*.dll'),*Runtimes[-1].glob('*.dll')]: shutil.copy2(File,Project/File.name)
   (Project/'godot_luau.gdextension').write_text('[configuration]\nentry_symbol="SanitizerProbeInit"\ncompatibility_minimum="4.3"\n[libraries]\nwindows.debug.x86_64="res://probe.dll"\nwindows.release.x86_64="res://probe.dll"\n')
  Observe([Args.engine,'--headless','--disable-crash-handler','--single-threaded-scene','--path',Project,'--script','res://SanitizerLifecycle.gd','--','--mode',Mode,'--cycles',str(Cycles)],Label)
 (Logs/'identity.json').write_text(json.dumps({'Compiler':str(Compiler),'CompilerSHA256':Hash(Compiler),'EngineSHA256':Hash(Args.engine),'ProbeInputs':{File.name:Hash(File) for File in (Root/'probe-source').iterdir() if File.is_file()},'LifecycleSHA256':Hash(Root/'SanitizerLifecycle.gd'),'Results':Records},indent=2))
finally: StopAll()
