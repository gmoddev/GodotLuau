import json,re
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement/full-linux-binary/native')
Records=[]
for File in Root.rglob('*.stderr.log'):
 Lines=File.read_text(errors='replace').splitlines()
 Matches=[Line for Line in Lines if re.search(r'leaked|still in use|ERROR:|SCRIPT ERROR:|SUMMARY:|LeakSanitizer|AddressSanitizer:DEADLYSIGNAL',Line)]
 if Matches:
  Records.append({'File':str(File.relative_to(Root)),'Messages':Matches})
print(json.dumps(Records),flush=True)
(Root.parent.parent/'linux-diagnostics-review.json').write_text(json.dumps(Records,indent=2))
