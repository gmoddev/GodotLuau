import hashlib,json,shutil,subprocess
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement');Name='codex-gl018-retirement'
def Run(Command):return subprocess.check_output(Command,encoding='utf-8',errors='strict',timeout=30).strip()
def Containers():return [dict(zip(['ID','Names','State'],Line.split('\t'))) for Line in Run(['docker','ps','--all','--format','{{.ID}}\t{{.Names}}\t{{.State}}']).splitlines()]
Before=Containers();Info=json.loads(Run(['docker','inspect',Name]))[0];assert Info['Config']['Labels']['codex.task']=='gl018-retirement'
Cache=json.loads((Root/'final-cache-identities.json').read_text())
for Record in Cache['Archives']:
 with (Root/Record['File']).open('rb') as Data:assert hashlib.file_digest(Data,'sha256').hexdigest()==Record['SHA256']
Volume=json.loads(Run(['docker','volume','inspect','codex-gl018-retirement-profiles']))[0];assert Volume['Labels']['codex.task']=='gl018-retirement'
Run(['docker','stop','--time','10',Name]);Run(['docker','rm',Name]);Run(['docker','volume','rm','codex-gl018-retirement-profiles'])
After=Containers();assert [(R['ID'],R['State']) for R in Before if R['Names']!=Name]==[(R['ID'],R['State']) for R in After]
Dependencies={}
for Folder,Expected in [('godot-cpp','d5cc777a89d899665fb61f1650ef0dc0cf6488c4'),('luau','9e2984fd0334414a2ef62ceede0c06dab7574d55')]:
 Directory='C:/Sandbox/Codex/Workspaces/GodotLuau/'+Folder;Revision=Run(['git','-C',Directory,'rev-parse','HEAD']);Status=Run(['git','-C',Directory,'status','--porcelain','--untracked-files=no']);assert Revision==Expected and not Status
 Dependencies[Folder]={'Revision':Revision,'CleanTrackedFiles':not Status}
Processes=json.loads(Run(['powershell.exe','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(godot.*\\.exe|ExecutionDomainTests.exe|DatastoreBackendProbe.exe|godot_luau_store_worker.exe|cl.exe|link.exe|ninja.exe)$' } | Select-Object Name,ProcessId,ExecutablePath) | ConvertTo-Json -Compress"]) or '[]')
if isinstance(Processes,dict):Processes=[Processes]
Owned=[P for P in Processes if P.get('ExecutablePath') and ('Sandbox\\Codex' in P['ExecutablePath'])];assert not Owned,Owned
Record={'TaskContainerRemoved':True,'TaskProfileVolumeRemoved':True,'CachesAndHistoricalEvidenceRetained':True,'CacheArchivesVerified':Cache['Archives'],'OtherContainersBefore':Before,'OtherContainersAfter':After,'TaskNativeBuildProcesses':Owned,'Dependencies':Dependencies,'CapacityAfter':{D:shutil.disk_usage(D)._asdict() for D in ['C:/','E:/']},'DockerLifetime':'The recovered backend inherited the task SSH job. Only that job kill-on-close flag was cleared after exact member/handle verification. Primary SSH then closed; Docker remains running. No persistent SSH/service/container policy or test process-job limit changed.'}
(Root/'cleanup.json').write_text(json.dumps(Record,indent=2));print(json.dumps(Record,indent=2),flush=True)
