exec(__import__('pathlib').Path('E:/Sandbox/Codex/NativeSanitizers/helpers/FollowupWindows.py').read_text().split('with (Output/')[0])
with (Output/'windows-get-binding-probe-build.log').open('w') as Log:
 subprocess.run(['cmake','--build',str(Output/'windows-probes'),'--parallel','2'],stdout=Log,stderr=subprocess.STDOUT,check=True,timeout=180)
Host=json.loads((Root/'godot-host/sanitizer-host.json').read_text())
subprocess.run([sys.executable,str(Root/'source/tests/runtime/InvestigateSanitizerBindings.py'),'--godot',Host['Executable'],'--probe',str(Output/'windows-probes/NativeSanitizerProbe.dll'),'--output',str(Output/'windows-bindings-get-api')],check=True,timeout=180)
