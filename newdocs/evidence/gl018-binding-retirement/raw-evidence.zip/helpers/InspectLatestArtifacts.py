import hashlib,json,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement')
for File in sorted(Root.glob('ci-*.zip')):
 with zipfile.ZipFile(File) as Zip:
  Summaries=[Name for Name in Zip.namelist() if Name.endswith('sanitizer-summary.json') or Name.endswith('native-ci/summary.json')]
  for Name in Summaries:
   Data=json.loads(Zip.read(Name));print(File.name,Name,flush=True)
   if 'Results' in Data:
    print(json.dumps({Key:Data[Key] for Key in ['Result','FullQualification','ControlsPassed','UnexpectedReports']},indent=2))
    print(json.dumps([{Key:R.get(Key) for Key in ['Label','Exit','TimedOut','Passed']} for R in Data['Results']],indent=2))
    for R in Data['Results']:
     if R['Passed']:continue
     Prefix=Name.removesuffix('sanitizer-summary.json')+R['Label']+'/'
     for Log in Zip.namelist():
      if Log in [Prefix+'stdout.log',Prefix+'stderr.log']:
       print(Log,Zip.read(Log).decode(errors='replace')[-3000:])
   else:print('Native',Data['Revision'],Data['Processes'],len(Data['LogHashes']))
