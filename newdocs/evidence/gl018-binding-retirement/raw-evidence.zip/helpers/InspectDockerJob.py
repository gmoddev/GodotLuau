import ctypes,json,os,subprocess
from ctypes import wintypes
class JobProcesses(ctypes.Structure):
 _fields_=[('Assigned',wintypes.DWORD),('Count',wintypes.DWORD),('Pids',ctypes.c_size_t*1024)]
Kernel=ctypes.WinDLL('kernel32',use_last_error=True);Kernel.QueryInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD,ctypes.c_void_p]
Data=JobProcesses();OK=Kernel.QueryInformationJobObject(None,3,ctypes.byref(Data),ctypes.sizeof(Data),None)
Records=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command',"Get-CimInstance Win32_Process | Select-Object Name,ProcessId,ParentProcessId | ConvertTo-Json -Compress"],text=True,timeout=30))
Selected=[R for R in Records if 'docker' in R['Name'].lower() or R['ProcessId'] in list(Data.Pids[:Data.Count]) or R['ProcessId'] in [os.getpid(),os.getppid()]]
print(json.dumps({'QueryOK':bool(OK),'Error':0 if OK else ctypes.get_last_error(),'Assigned':Data.Assigned,'Count':Data.Count,'Processes':Selected},indent=2),flush=True)
