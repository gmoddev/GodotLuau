import json, os, subprocess, sys, time
from pathlib import Path
Runtime=Path('/work/source/tests/runtime'); sys.path.insert(0,str(Runtime))
from FixtureProcesses import StartProcess, StopProcess
Output=Path('/qualification/followup/gdb'); Output.mkdir(exist_ok=False)
with (Output/'prerequisites.log').open('w') as Log:
 for Command in [['apt-get','update'],['apt-get','install','--no-install-recommends','-y','gdb']]:
  subprocess.run(Command,stdout=Log,stderr=subprocess.STDOUT,check=True,timeout=180)
Host=json.loads(Path('/work/godot-host/sanitizer-host.json').read_text())
Results=[]
for Name,Project,Mode in [('binding',Path('/qualification/followup/bindings-get-api/binding'),'minimal'),('production',Path('/qualification/full-followup/production-vm-reload/project'),'vm-cycles')]:
 Command=['gdb','--batch','-ex','set pagination off','-ex','set environment ASAN_OPTIONS halt_on_error=1:detect_leaks=1:handle_segv=0','-ex','run','-ex','thread apply all bt 16','--args',Host['Executable'],'--headless','--disable-crash-handler','--single-threaded-scene','--path',str(Project),'--script','res://SanitizerLifecycle.gd','--','--mode',Mode,'--cycles','5']
 Environment=dict(os.environ,GODOT_SILENCE_ROOT_WARNING='1')
 if Name=='binding': Environment['GL_NATIVE_SANITIZER_CONTROL']='binding'
 Started=time.monotonic()
 with (Output/(Name+'.log')).open('w') as Log:
  Child=StartProcess(Command,Log,subprocess.STDOUT,Environment)
  try: Code=Child.wait(timeout=90)
  finally: StopProcess(Child)
 Results.append({'Name':Name,'Command':Command,'GdbExit':Code,'Seconds':time.monotonic()-Started,'Scope':'Diagnostic child debugger only; not a sanitizer-clean qualification; LSan unsupported under ptrace'})
 print((Output/(Name+'.log')).read_text(errors='replace')[-6500:],flush=True)
(Output/'investigation.json').write_text(json.dumps(Results,indent=2))
