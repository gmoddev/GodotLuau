import json, shutil, subprocess
for Name in ['C:/','E:/']: print(Name,shutil.disk_usage(Name),flush=True)
for Command in [['docker','inspect','codex-gl018-followup','--format','{{.State.Status}}'],['docker','exec','codex-gl018-followup','df','-h','/qualification','/work'],['docker','exec','codex-gl018-followup','tail','-12','/qualification/followup/full.log']]:
 Result=subprocess.run(Command,capture_output=True,text=True,timeout=20);print(json.dumps({'Command':Command,'Exit':Result.returncode,'Output':Result.stdout,'Error':Result.stderr}),flush=True)
