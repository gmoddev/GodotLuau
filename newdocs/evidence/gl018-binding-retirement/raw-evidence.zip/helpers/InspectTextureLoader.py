from pathlib import Path
Root=Path('/work/godot-host')
for File in (Root/'scene').rglob('*.cpp'):
 Text=File.read_text()
 if 'ResourceFormatLoaderCompressedTexture2D::' not in Text: continue
 Lines=Text.splitlines()
 for Index,Line in enumerate(Lines):
  if 'ResourceFormatLoaderCompressedTexture2D::' in Line: print(str(File)+':'+str(Index+1)+'\n'+'\n'.join(Lines[max(0,Index-3):Index+18]))
