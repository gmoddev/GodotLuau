from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/LinuxWork/linux-full-fresh')
for File in sorted(Root.rglob('*')):
 if File.is_file() and ('performance' in File.parts or File.parent.name=='suite-performance') and (File.name.endswith('.log') or File.name.startswith('asan-report')):
  Text=File.read_text(errors='replace');Lines=Text.splitlines();print(str(File),len(Text))
  if File.name.startswith('asan-report'):print('\n'.join(Lines[:35]));print('\n'.join(Line for Line in Lines if 'SUMMARY' in Line))
  else:print('\n'.join(Lines[-30:]))
