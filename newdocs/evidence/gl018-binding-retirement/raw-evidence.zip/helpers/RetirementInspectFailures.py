import json
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement/full-windows')
for Name in ['suite-http','suite-httpservice','suite-datastore','suite-presentation','suite-performance']:
 for Suffix in ['stdout.log','stderr.log']:
  P=Root/Name/Suffix
  if P.exists(): print(Name+'/'+Suffix+'\n'+'\n'.join(P.read_text(errors='replace').splitlines()[-10:]),flush=True)
for Group in ['http','httpservice','datastore','presentation']:
 Directory=Root/'native'/Group
 for File in Directory.rglob('*.log'):
  Lines=File.read_text(errors='replace').splitlines()
  Relevant=[Line for Line in Lines if any(Term in Line for Term in ['FAIL','SCRIPT ERROR','conflict','frame-progress','FrameProgress','Peak','previously freed'])]
  if Relevant: print(str(File.relative_to(Root))+'\n'+'\n'.join(Relevant[-7:]),flush=True)
