import hashlib,json,os,posixpath,re,subprocess,sys,zipfile
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers');Followup=Root/'followup';sys.path.insert(0,str(Root/'source/tests/runtime'))
from SourceFingerprint import GetFingerprint
def Hash(Bytes):return hashlib.sha256(Bytes).hexdigest()
Record={'RuntimeTestsRunByThisCheck':False,'NativeSource':GetFingerprint(Root/'source')}
assert Record['NativeSource']['SHA256']=='2706e1685bdf0207e55eacc2f877e4578a3164603ea5861c183009348c7d1bc8'
Inputs=json.loads((Followup/'windows-candidate-full/inputs.json').read_text())
Verified=0
with zipfile.ZipFile(Followup/'harness-246.zip') as Source:
 for Relative,Digest in Inputs['Harness'].items():
  File=Root/'source/tests/runtime'/Relative
  assert Hash(File.read_bytes())==Digest,Relative
  assert Hash(File.read_bytes().replace(b'\r\n',b'\n'))==Hash(Source.read('tests/runtime/'+Relative.replace('\\','/')).replace(b'\r\n',b'\n')),Relative
  Verified+=1
Record['VerifiedCandidateHarnessInputs']=Verified
Build=json.loads((Followup/'windows-candidate-build/build-identity.json').read_text())
Directory=Path('C:/Sandbox/Codex/Builds/GodotLuau/runtime-msvc-asan')
for Name,Digest in Build['Products'].items():assert Hash((Directory/Name).read_bytes())==Digest
assert Hash((Directory/'compile_commands.json').read_bytes())==Build['CompileCommandsSHA256']
assert Hash(Path('C:/Sandbox/Codex/Workspaces/GodotLuau/tests/runtime/ExecutionDomainTests.cpp').read_bytes())==Hash((Followup/'windows-candidate-build/prior-ExecutionDomainTests.cpp').read_bytes())
Archive=json.loads((Followup/'followup-final.json').read_text());assert Hash(Path(Archive['Archive']).read_bytes())==Archive['SHA256']
with zipfile.ZipFile(Archive['Archive']) as Zip:
 Manifest=json.loads(Zip.read('manifest.json'))
 for Name,Item in Manifest['Files'].items():assert Hash(Zip.read(Name))==Item['SHA256'],Name
 assert Manifest['Count']==6573 and not Manifest['ReadFailures']
Record['VerifiedArchiveFiles']=6573
Paths=set(json.loads((Followup/'followup-repository-files.json').read_text(encoding='utf-8-sig')))
Parsed=0;Links=0
with zipfile.ZipFile(Followup/'followup-review.zip') as Zip:
 for Name in Zip.namelist():
  if Name.endswith('.json'):json.loads(Zip.read(Name));Parsed+=1
  if not Name.endswith('.md'):continue
  Text=Zip.read(Name).decode()
  for Target in re.findall(r'\]\(([^)]+)\)',Text):
   if '://' in Target or Target.startswith('#'):continue
   Target=Target.split('#')[0].strip('<>')
   Resolved=posixpath.normpath(posixpath.join(posixpath.dirname(Name),Target))
   assert Resolved in Paths,(Name,Resolved)
   Links+=1
Record.update(ParsedJSON=Parsed,ResolvedLinks=Links)
Command=['powershell.exe','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(godot|godot_luau_store_worker|cl|link|ninja|cmake|ExecutionDomainTests)' -and ($_.CommandLine -like '*NativeSanitizers*' -or $_.CommandLine -like '*runtime-msvc-asan*') } | Select-Object ProcessId,Name | ConvertTo-Json -Compress"]
Processes=subprocess.check_output(Command,text=True,timeout=20).strip();assert Processes in ['', '[]'],Processes
Record['RemainingTaskRuntimeOrCompilerProcesses']=0
(Followup/'evidence-review.json').write_text(json.dumps(Record,indent=2));print(json.dumps(Record),flush=True)
