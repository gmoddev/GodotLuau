import json,subprocess
for Command in [['docker','ps','--all','--format','{{json .}}'],['docker','version','--format','{{json .Server}}']]:
 Result=subprocess.run(Command,capture_output=True,encoding='utf-8',errors='replace',timeout=30)
 print('Exit',Result.returncode,'stdout',Result.stdout[:2000],'stderr',Result.stderr[:1200],flush=True)
print(subprocess.check_output(['powershell.exe','-NoProfile','-Command',"Get-Process 'com.docker.backend','Docker Desktop' -ErrorAction SilentlyContinue | Select-Object ProcessName,Id | ConvertTo-Json -Compress"],encoding='utf-8',errors='replace',timeout=30),flush=True)
