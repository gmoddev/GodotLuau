import hashlib,json,re,subprocess
from pathlib import Path
Output=Path('/evidence/historical-leak-symbols');Output.mkdir(exist_ok=False)
Original=Path('/evidence/symbols-3/original-host');Symbols=Path('/evidence/symbols-3/godot-symbols')
Work=Path('/work/leak-symbol-check');Work.mkdir(exist_ok=False)
for Name,File in [('original',Original),('symbols',Symbols)]:
 subprocess.run(['objcopy','--dump-section','.text='+str(Work/(Name+'.text')),str(File)],capture_output=True,check=True,timeout=60)
TextHashes={Name:hashlib.sha256((Work/(Name+'.text')).read_bytes()).hexdigest() for Name in ['original','symbols']}
assert TextHashes['original']==TextHashes['symbols']
Report=Path('/retained/LinuxWork/linux-full-fresh/suite-performance/asan-report.5926').read_text()
Offsets=list(dict.fromkeys(re.findall(r'godot\.linuxbsd[^\n]*?\+(0x[0-9a-f]+)\)',Report)))
Result=subprocess.run(['addr2line','-C','-f','-e',str(Symbols),*Offsets],capture_output=True,text=True,check=True,timeout=30)
(Output/'host-symbols.txt').write_text(Result.stdout)
(Output/'verification.json').write_text(json.dumps({'OriginalSHA256':hashlib.sha256(Original.read_bytes()).hexdigest(),'SymbolizedSHA256':hashlib.sha256(Symbols.read_bytes()).hexdigest(),'TextSectionSHA256':TextHashes,'Offsets':Offsets,'Scope':'Exact matching engine text; function-only symbolization of retained historical report, not a fresh leak reproduction'},indent=2))
print(Result.stdout[:7000],flush=True)
for File in Work.iterdir():assert File.resolve().is_relative_to(Work.resolve());File.unlink()
Work.rmdir()
