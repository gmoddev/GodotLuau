import hashlib,json,os,shutil,subprocess,sys,tarfile,zipfile
from pathlib import Path
Root=Path('/work')
Logs=Path('/evidence/linux-host-ram-first')
Logs.mkdir(exist_ok=False)
Environment=dict(os.environ,PYTHONPATH='/evidence/scons',TMPDIR='/work/tmp',GODOT_SILENCE_ROOT_WARNING='1')
(Root/'tmp').mkdir(exist_ok=True)
Commands=[]
SourceArchive=Path('/evidence/starting-source.zip')
assert hashlib.sha256(SourceArchive.read_bytes()).hexdigest()=='3a83935af350ef51082fcabdc4bf1d74b160810a13f716a785873a8e5fddd2dd'
with zipfile.ZipFile(SourceArchive) as Zip: Zip.extractall(Root/'source')
sys.path.insert(0,str(Root/'source/tests/runtime'))
from FixtureProcesses import StartProcess,StopProcess,StopAll
def Run(Command,Name,Timeout,Cwd=None):
 print('[Qualification:Host] Linux '+Name,flush=True)
 with (Logs/(Name+'.log')).open('w') as Log:
  Previous=Path.cwd()
  if Cwd: os.chdir(Cwd)
  Code=None
  try:
   Child=StartProcess(Command,Log,subprocess.STDOUT,Environment)
   try: Code=Child.wait(timeout=Timeout)
   finally: StopProcess(Child)
  finally:
   os.chdir(Previous)
   Commands.append({'Command':Command,'Cwd':str(Cwd),'Timeout':Timeout,'Exit':Code,'LogSHA256':hashlib.sha256((Logs/(Name+'.log')).read_bytes()).hexdigest()})
 (Logs/'commands.json').write_text(json.dumps(Commands,indent=2))
 if Code: print((Logs/(Name+'.log')).read_text(errors='replace')[-6000:],flush=True)
 assert Code==0,Name
Run(['apt-get','update'],'tools-update',300)
Run(['apt-get','install','-y','--no-install-recommends','pkg-config','lld-19'],'tools-install',300)
Archive=Path('/evidence/godot-source.tar.gz')
assert hashlib.sha256(Archive.read_bytes()).hexdigest()=='98c5c1c101d15d43de5e3dca81cfb57ef3698495d67eeaf5e34db739b751bbb9'
with tarfile.open(Archive) as Tar: Tar.extractall(Root,filter='data')
Engine=Root/('godot-a13da4feb8d8aefc283c3763d33a2f170a18d541')
Engine.rename(Root/'godot-host'); Engine=Root/'godot-host'
from SourceFingerprint import GetFingerprint
Identity=json.loads(Path('/cache/animation-security/products-candidate-1/asan/identity.json').read_text())
assert Identity['Source']==GetFingerprint(Root/'source')
Products=Root/'products/linux-asan'
Products.mkdir(parents=True)
for Name,Digest in Identity['Products'].items():
 File=Path('/cache/animation-security/products-candidate-1/asan')/Name
 assert hashlib.sha256(File.read_bytes()).hexdigest()==Digest
 shutil.copy2(File,Products/Name)
(Products/'identity.json').write_text(json.dumps(Identity,indent=2))
Args=['platform=linuxbsd','target=template_debug','arch=x86_64','use_asan=yes','use_lsan=yes','use_llvm=yes','CC=clang-19','CXX=clang++-19','LINK=clang++-19','linker=lld','use_static_cpp=no','dev_build=yes','debug_symbols=no','optimize=none','lto=none','ccflags=-fno-omit-frame-pointer','disable_path_overrides=no','x11=no','wayland=no','vulkan=no','opengl3=no','accesskit=no','alsa=no','pulseaudio=no','dbus=no','speechd=no','fontconfig=no','udev=no','sdl=no','modules_enabled_by_default=no',*['module_'+Name+'_enabled=yes' for Name in ['gdscript','multiplayer','enet','mbedtls','godot_physics_2d','godot_physics_3d','freetype','text_server_fb']],'-j2']
Run([sys.executable,'-m','SCons',*Args],'build',7200,Engine)
(Logs/'products.json').write_text(json.dumps({File.name:hashlib.sha256(File.read_bytes()).hexdigest() for File in (Engine/'bin').iterdir() if File.is_file()},indent=2))
