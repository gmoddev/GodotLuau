import hashlib,json,shutil,subprocess,time
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement');Name='codex-gl018-retirement'
Info=json.loads(subprocess.check_output(['docker','inspect',Name],timeout=20))[0];assert Info['Config']['Labels']['codex.task']=='gl018-retirement'
Records={'CapacityBefore':{D:shutil.disk_usage(D)._asdict() for D in ['C:/','E:/']},'Archives':[]}
assert Records['CapacityBefore']['C:/']['free']>2*1024**3
for File,Directory,Entries in [('linux-retirement-final-cache.tar.gz','/work',['fresh-asan','godot-host','godot-host-attempts','probes','retirement-probes','source']),('linux-profile-data.tar.gz','/profiles',['.'])]:
 Command=['docker','exec',Name,'tar','--use-compress-program=gzip -1','-cf','/evidence/'+File,'-C',Directory,*Entries]
 with (Root/(File+'.log')).open('w') as Log:Result=subprocess.run(Command,stdout=Log,stderr=subprocess.STDOUT,timeout=300)
 assert Result.returncode==0
 PathName=Root/File
 with PathName.open('rb') as Data:Digest=hashlib.file_digest(Data,'sha256').hexdigest()
 Records['Archives'].append({'File':File,'SHA256':Digest,'Bytes':PathName.stat().st_size,'Command':Command})
 (Root/'final-cache-identities.json').write_text(json.dumps(Records,indent=2));print(File,PathName.stat().st_size,Digest,flush=True)
