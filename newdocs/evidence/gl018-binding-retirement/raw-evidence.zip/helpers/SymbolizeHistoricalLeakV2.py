import hashlib,json,re,shutil,subprocess
from pathlib import Path
Output=Path('/evidence/historical-leak-symbols-v2');Output.mkdir(exist_ok=False)
Work=Path('/work/leak-symbol-check-v2');Work.mkdir(exist_ok=False)
Inputs={'original':Path('/evidence/symbols-3/original-host'),'symbols':Path('/evidence/symbols-3/godot-symbols')}
Hashes={}
for Name,File in Inputs.items():
 Target=Work/Name;shutil.copy2(File,Target);Hashes[Name]=hashlib.sha256(Target.read_bytes()).hexdigest()
 subprocess.run(['objcopy','--dump-section','.text='+str(Work/(Name+'.text')),str(Target),str(Work/(Name+'-copy'))],capture_output=True,check=True,timeout=30)
TextHashes={Name:hashlib.sha256((Work/(Name+'.text')).read_bytes()).hexdigest() for Name in Inputs}
assert TextHashes['original']==TextHashes['symbols']
Report=Path('/retained/LinuxWork/linux-full-fresh/suite-performance/asan-report.5926').read_text()
Offsets=list(dict.fromkeys(re.findall(r'godot\.linuxbsd[^\n]*?\+(0x[0-9a-f]+)\)',Report)))
Result=subprocess.run(['addr2line','-C','-f','-e',str(Work/'symbols'),*Offsets],capture_output=True,text=True,check=True,timeout=30)
(Output/'host-symbols.txt').write_text(Result.stdout)
(Output/'verification.json').write_text(json.dumps({'InputSHA256':Hashes,'TextSectionSHA256':TextHashes,'Offsets':Offsets,'Scope':'Matching engine text, function-only historical report symbolization, no new leak reproduction. Prior E: objcopy operation timed out; this attempt copies inputs to tmpfs and never rewrites original inputs.'},indent=2))
print(Result.stdout[:6500],flush=True)
for File in Work.iterdir():assert File.resolve().is_relative_to(Work.resolve());File.unlink()
Work.rmdir()
