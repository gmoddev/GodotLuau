import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); Runtime=Root/'source/tests/runtime';Output=Root/'retirement/rejection-controls';Output.mkdir(exist_ok=False)
Records=[]
for Name,Field,Message in [('changed-patch','SHA256LF','Qualification host patch hash mismatch'),('changed-patched-source','PatchedSHA256','Unrecognized qualification host source')]:
 Directory=Output/Name;Directory.mkdir();(Directory/'sanitizers').mkdir()
 for File in ['BuildSanitizedGodot.py','FixtureProcesses.py']:shutil.copy2(Runtime/File,Directory/File)
 Policy=json.loads((Runtime/'SanitizerHosts.json').read_text());Policy['QualificationPatch'][Field]='f'*64
 (Directory/'SanitizerHosts.json').write_text(json.dumps(Policy))
 shutil.copy2(Runtime/'sanitizers/GodotBindingRetirement.patch',Directory/'sanitizers/GodotBindingRetirement.patch')
 Command=[sys.executable,str(Directory/'BuildSanitizedGodot.py'),'--output',str(Root/'godot-host'),'--archive',str(Root/'godot-source.tar.gz'),'--timeout','1']
 Result=subprocess.run(Command,capture_output=True,text=True,timeout=1000)
 (Directory/'stdout.log').write_text(Result.stdout);(Directory/'stderr.log').write_text(Result.stderr)
 assert Result.returncode!=0 and Message in Result.stderr
 Records.append({'Case':Name,'Exit':Result.returncode,'ExpectedError':Message,'Rejected':True})
 print(Name,'REJECTED',flush=True)
(Output/'results.json').write_text(json.dumps(Records,indent=2))
