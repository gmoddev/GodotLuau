import hashlib,json,sys
from pathlib import Path
Root=Path('E:/Sandbox/Codex/NativeSanitizers/retirement');Records=[]
for Name in ['full-windows','full-linux','full-linux-binary']:
 Directory=Root/Name;File=Directory/'sanitizer-summary.json'
 if not File.exists():continue
 Data=json.loads(File.read_text());Inputs=json.loads((Directory/'inputs.json').read_text())
 for Relative,Digest in Data['Files'].items():assert hashlib.sha256((Directory/Relative).read_bytes()).hexdigest()==Digest,Relative
 Record={'Profile':Name,'Result':Data['Result'],'FullQualification':Data['FullQualification'],'ControlsPassed':Data['ControlsPassed'],'UnexpectedReports':Data['UnexpectedReports'],'VerifiedFileHashes':len(Data['Files']),'NativeSource':Inputs['NativeSource'],'GodotSHA256':Inputs['GodotSHA256'],'ExtensionSHA256':Inputs.get('ExtensionSHA256'),'Revision':Inputs['Revision'],'PassedGates':[R['Label'] for R in Data['Results'] if R['Passed']],'FailedGates':[R['Label'] for R in Data['Results'] if not R['Passed']]}
 Summary=Directory/'native/summary.json'
 if Summary.exists():
  Native=json.loads(Summary.read_text());Record.update(NativeActors=Native['Processes'],AnimationActors=len(Native['AnimationAuthority']),AnimationCases=sum(len(A['Cases']) for A in Native['AnimationAuthority']),AnimationAssertions=sum(len(A['Assertions']) for A in Native['AnimationAuthority']))
  assert Record['NativeActors']==110 and Record['AnimationCases']==510
 Record['AnimationRecords']=[]
 for F in sorted((Directory/'native/animation').rglob('animation-authority-*.json')):
  A=json.loads(F.read_text());assert A['Complete'] and A['Result']=='PASS' and all(C['Passed'] for C in A['Cases']+A['Assertions'])
  Record['AnimationRecords'].append({'File':str(F.relative_to(Directory)),'Cases':len(A['Cases']),'Assertions':len(A['Assertions'])})
 Records.append(Record)
(Root/'local-profile-verification.json').write_text(json.dumps(Records,indent=2));print(json.dumps(Records),flush=True)
