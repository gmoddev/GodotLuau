import argparse, hashlib, json, os, time, zipfile
from pathlib import Path
Parser=argparse.ArgumentParser(); Parser.add_argument('--name',required=True);Args=Parser.parse_args()
Root=Path('E:/Sandbox/Codex/NativeSanitizers'); Followup=Root/'followup'
def Hash(File): return hashlib.sha256(File.read_bytes()).hexdigest()
Selected={}
for Current,Dirs,Files in os.walk(Followup):
 Dirs[:]=[Name for Name in Dirs if Name not in ['relocated-godot-cpp-cache','windows-probes','current-runtime','archive','__pycache__']]
 for Name in Files:
  File=Path(Current)/Name
  if File.suffix in ['.log','.json','.xml','.gd','.py','.h','.tres'] or Name.startswith('asan-report'):
   if Name.startswith(Args.name):continue
   Selected[File.relative_to(Root).as_posix()]=File
for File in (Root/'helpers').glob('*.py'): Selected[File.relative_to(Root).as_posix()]=File
for File in (Root/'source/tests/runtime').rglob('*'):
 if File.is_file() and File.suffix in ['.py','.gd','.cpp','.json','.pem'] and '__pycache__' not in File.parts:
  Selected['source/tests/runtime/'+File.relative_to(Root/'source/tests/runtime').as_posix()]=File
Selected['source/src/core/luau_stdlib.h']=Root/'source/src/core/luau_stdlib.h'
Manifest={'TimeUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'Files':{},'ReadFailures':[]}
Archive=Followup/(Args.name+'.zip')
with zipfile.ZipFile(Archive,'x',zipfile.ZIP_DEFLATED) as Zip:
 for Name,File in sorted(Selected.items()):
  try: Data=File.read_bytes()
  except OSError as Error:
   Manifest['ReadFailures'].append({'File':Name,'Error':str(Error)});continue
  Manifest['Files'][Name]={'SHA256':hashlib.sha256(Data).hexdigest(),'Bytes':len(Data)}
  Zip.writestr(Name,Data)
 Manifest['Count']=len(Manifest['Files'])
 Zip.writestr('manifest.json',json.dumps(Manifest,indent=2))
with zipfile.ZipFile(Archive) as Zip:
 for Name,Record in Manifest['Files'].items(): assert hashlib.sha256(Zip.read(Name)).hexdigest()==Record['SHA256'],Name
Record={'Archive':str(Archive),'SHA256':Hash(Archive),'Bytes':Archive.stat().st_size,'Files':Manifest['Count'],'ReadFailures':Manifest['ReadFailures']}
(Followup/(Args.name+'.json')).write_text(json.dumps(Record,indent=2))
print(json.dumps(Record),flush=True)
for Name in ['windows-full','windows-candidate-full','linux-salvage/full-followup']:
 Directory=Followup/Name
 File=Directory/'sanitizer-summary.json'
 if File.is_file():
  Value=json.loads(File.read_text());print(json.dumps({'Attempt':Name,'Result':Value['Result'],'Results':[{K:Item[K] for K in ['Label','Exit','Passed','TimedOut']} for Item in Value['Results']]}),flush=True)
 elif (Directory/'results.json').is_file(): print(json.dumps({'Attempt':Name,'IncompleteResults':json.loads((Directory/'results.json').read_text())}),flush=True)
